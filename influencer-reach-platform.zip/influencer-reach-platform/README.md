# InfluencerMatch - Frontend

An influencer marketing platform that connects brands with content creators through direct chat communication.

## Features

- **Direct Chat System**: Firebase-powered realtime messaging between brands and influencers
- **Campaign Management**: Brands can create and manage influencer marketing campaigns
- **Profile Management**: Detailed profiles for both brands and influencers
- **Real-time Communication**: Instant messaging with chat history and notifications

## Firebase Setup

This application uses Firebase Realtime Database for the chat functionality. To set up Firebase:

1. Create a new Firebase project at [Firebase Console](https://console.firebase.google.com/)
2. Enable Realtime Database
3. Copy your Firebase configuration
4. Create a `.env` file based on `.env.example`:

```bash
cp .env.example .env
```

5. Update the Firebase configuration in `.env`:

```env
VITE_FIREBASE_API_KEY=your-api-key-here
VITE_FIREBASE_AUTH_DOMAIN=your-project.firebaseapp.com
VITE_FIREBASE_DATABASE_URL=https://your-project-default-rtdb.firebaseio.com/
VITE_FIREBASE_PROJECT_ID=your-project-id
VITE_FIREBASE_STORAGE_BUCKET=your-project.appspot.com
VITE_FIREBASE_MESSAGING_SENDER_ID=123456789
VITE_FIREBASE_APP_ID=your-app-id
```

## Installation & Development

**Requirements**: Node.js & npm - [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating)

```sh
# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build
```

## Key Changes Made

### Removed Application System

- Removed all application submission logic
- Deleted application forms and related UI components
- Removed application status tracking

### Added Firebase Chat System

- **Firebase Realtime Database**: For instant messaging
- **Chat Component**: Real-time chat interface with message history
- **ChatList Component**: Overview of all conversations
- **Messages Page**: Dedicated page for managing conversations
- **Firebase Service**: Handles all chat operations

### Updated User Flow

1. **Influencers**: Can browse campaigns and start direct conversations with brands
2. **Brands**: Receive chat requests from interested influencers
3. **Communication**: All collaboration discussions happen through chat instead of formal applications

## Project Structure

```
src/
├── components/
│   ├── Chat.tsx              # Real-time chat component
│   ├── ChatList.tsx          # List of conversations
│   └── ...
├── pages/
│   ├── Messages.tsx          # Main messages page
│   ├── CampaignDetail.tsx    # Updated to use chat instead of applications
│   └── ...
├── services/
│   ├── firebaseChatService.ts # Firebase chat operations
│   └── ...
├── lib/
│   ├── firebase.ts           # Firebase configuration
│   └── ...
```

- Edit files directly within the Codespace and commit and push your changes once you're done.

## What technologies are used for this project?

This project is built with:

- Vite
- TypeScript
- React
- shadcn-ui
- Tailwind CSS

## How can I deploy this project?

Simply open [Lovable](https://lovable.dev/projects/2eceb66d-7f5d-468d-aa6c-ec786940bf40) and click on Share -> Publish.

## Can I connect a custom domain to my Lovable project?

Yes, you can!

To connect a domain, navigate to Project > Settings > Domains and click Connect Domain.

Read more here: [Setting up a custom domain](https://docs.lovable.dev/tips-tricks/custom-domain#step-by-step-guide)
