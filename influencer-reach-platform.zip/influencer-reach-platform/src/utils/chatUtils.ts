import { firebaseChatService } from "@/services/firebaseChatService";

export interface UserInfo {
  id: string;
  name: string;
  role: "influencer" | "brand" | "superadmin";
}

export interface CampaignInfo {
  id: string;
  title: string;
}

/**
 * Utility function to initiate a conversation between two users
 * @param currentUser - The current user initiating the conversation
 * @param targetUser - The user to start a conversation with
 * @returns Promise<string> - The conversation ID
 */
export async function initiateUserConversation(
  currentUser: UserInfo,
  targetUser: UserInfo
): Promise<string> {
  try {
    console.log("🚀 Initiating conversation between users:", {
      currentUser,
      targetUser,
    });

    const conversationId = await firebaseChatService.createOrGetConversation(
      currentUser.id,
      currentUser.name,
      currentUser.role,
      targetUser.id,
      targetUser.name,
      targetUser.role
    );

    console.log("✅ Conversation initiated successfully:", conversationId);
    return conversationId;
  } catch (error) {
    console.error("❌ Failed to initiate conversation:", error);
    throw error;
  }
}

/**
 * Utility function to initiate a campaign-specific conversation between two users
 * @param currentUser - The current user initiating the conversation
 * @param targetUser - The user to start a conversation with
 * @param campaign - The campaign context for this conversation
 * @returns Promise<string> - The conversation ID
 */
export async function initiateCampaignConversation(
  currentUser: UserInfo,
  targetUser: UserInfo,
  campaign: CampaignInfo
): Promise<string> {
  try {
    console.log("🚀 Initiating campaign conversation between users:", {
      currentUser,
      targetUser,
      campaign,
    });

    const conversationId = await firebaseChatService.createOrGetConversation(
      currentUser.id,
      currentUser.name,
      currentUser.role,
      targetUser.id,
      targetUser.name,
      targetUser.role,
      campaign.id,
      campaign.title
    );

    console.log(
      "✅ Campaign conversation initiated successfully:",
      conversationId
    );
    return conversationId;
  } catch (error) {
    console.error("❌ Failed to initiate campaign conversation:", error);
    throw error;
  }
}

/**
 * Utility function to send a message directly to a user (creates conversation if needed)
 * @param currentUser - The current user sending the message
 * @param targetUser - The user to send the message to
 * @param message - The message text to send
 * @returns Promise<void>
 */
export async function sendDirectMessage(
  currentUser: UserInfo,
  targetUser: UserInfo,
  message: string
): Promise<void> {
  try {
    console.log("💬 Sending direct message:", {
      from: currentUser.name,
      to: targetUser.name,
      message: message.substring(0, 50) + "...",
    });

    // First, create or get the conversation
    const conversationId = await initiateUserConversation(
      currentUser,
      targetUser
    );

    // Then send the message
    await firebaseChatService.sendMessage(
      conversationId,
      currentUser.id,
      currentUser.name,
      currentUser.role,
      message
    );

    console.log("✅ Direct message sent successfully");
  } catch (error) {
    console.error("❌ Failed to send direct message:", error);
    throw error;
  }
}

/**
 * Helper function to extract user info from different user objects
 * @param user - User object with various possible structures
 * @returns UserInfo - Standardized user info
 */
export function extractUserInfo(user: any): UserInfo {
  return {
    id: user.id || user._id,
    name:
      user.name || user.username || `${user.firstName} ${user.lastName}`.trim(),
    role: user.role || "brand", // Default to brand if role is not specified
  };
}

/**
 * Navigate to messages page with a pre-selected conversation
 * @param navigate - React Router navigate function
 * @param conversationId - The conversation ID to select
 * @param otherParticipant - The other participant info
 */
export function navigateToConversation(
  navigate: (path: string, options?: any) => void,
  conversationId: string,
  otherParticipant: UserInfo
) {
  navigate("/messages", {
    state: {
      selectedConversation: {
        conversationId,
        otherParticipant,
      },
    },
  });
}
