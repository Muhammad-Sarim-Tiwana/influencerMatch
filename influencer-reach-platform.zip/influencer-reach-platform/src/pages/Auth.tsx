import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useAuthStore, UserRole } from "@/store/authStore";
import { toast } from "@/hooks/use-toast";
import { useDashboardRedirect } from "@/hooks/useDashboardRedirect";
import { Building, Users, Crown, Eye, EyeOff, Mail } from "lucide-react";

const Auth = () => {
  const navigate = useNavigate();
  const { login, signup, isLoading, error, clearError } = useAuthStore();
  const { redirectToDashboard } = useDashboardRedirect();
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  const [loginData, setLoginData] = useState({
    email: "",
    password: "",
  });

  const [signupData, setSignupData] = useState({
    email: "",
    password: "",
    confirmPassword: "",
    name: "",
    role: "brand" as UserRole,
    company: "",
    bio: "",
    socialPlatforms: [
      {
        platform: "instagram" as const,
        username: "",
        followerCount: 0,
        engagementRate: 0,
        profileUrl: "",
      },
    ],
    categories: [] as string[],
    location: {
      country: "",
      city: "",
    },
    tags: [] as string[],
    demographics: {
      ageGroup: "",
      gender: "",
      primaryAudience: {
        ageGroup: "",
        gender: "",
        locations: [] as string[],
        interests: [] as string[],
        languages: [] as string[],
      },
    },
    languages: [] as string[],
    contentTypes: [] as string[],
    collaborationTypes: [] as string[],
    pricing: {
      postPrice: 0,
      storyPrice: 0,
      videoPrice: 0,
      reelPrice: 0,
      currency: "USD",
      negotiable: true,
    },
    availability: {
      status: "available" as const,
      nextAvailable: "",
    },
    contentStyle: {
      visualAesthetic: "",
      toneOfVoice: "",
      contentFrequency: "",
    },
  });

  const ageGroups = [
    "13-17",
    "18-24",
    "25-34",
    "35-44",
    "45-54",
    "55-64",
    "65+",
  ];

  const genders = ["male", "female", "non-binary", "prefer-not-to-say"];
  const audienceGenders = ["male", "female", "mixed", "other"];

  const languages = [
    "English",
    "Spanish",
    "French",
    "German",
    "Italian",
    "Portuguese",
    "Chinese",
    "Japanese",
    "Korean",
    "Arabic",
    "Hindi",
    "Russian",
  ];

  const validateLoginForm = () => {
    if (!loginData.email.trim()) {
      toast({
        title: "Validation Error",
        description: "Email address is required.",
        variant: "destructive",
      });
      return false;
    }

    // Email format validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(loginData.email)) {
      toast({
        title: "Validation Error",
        description: "Please enter a valid email address.",
        variant: "destructive",
      });
      return false;
    }

    if (!loginData.password) {
      toast({
        title: "Validation Error",
        description: "Password is required.",
        variant: "destructive",
      });
      return false;
    }

    return true;
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    clearError();

    // Validate login form
    if (!validateLoginForm()) {
      return;
    }

    try {
      const result = await login(loginData.email, loginData.password);
      if (result.success && result.user) {
        // Handle different account statuses
        if (result.status === "pending_approval") {
          toast({
            title: "Account Pending Approval",
            description:
              result.message ||
              "Your account is pending admin approval. You can browse the platform but cannot access all features until approved.",
            duration: 8000,
          });
        } else if (result.status === "deactivated") {
          toast({
            title: "Account Deactivated",
            description:
              result.message ||
              "Your account has been deactivated. Please contact support.",
            variant: "destructive",
            duration: 8000,
          });
        } else {
          toast({
            title: "Welcome back!",
            description: "Successfully logged in.",
          });
        }

        // Redirect to appropriate dashboard based on user role
        redirectToDashboard(result.user.role);
      } else {
        toast({
          title: "Login failed",
          description: error || "Invalid credentials.",
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Something went wrong. Please try again.",
        variant: "destructive",
      });
    }
  };

  const validateForm = () => {
    // Basic field validation
    if (!signupData.name.trim()) {
      toast({
        title: "Validation Error",
        description: "Full name is required.",
        variant: "destructive",
      });
      return false;
    }

    if (!signupData.email.trim()) {
      toast({
        title: "Validation Error",
        description: "Email address is required.",
        variant: "destructive",
      });
      return false;
    }

    // Email format validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(signupData.email)) {
      toast({
        title: "Validation Error",
        description: "Please enter a valid email address.",
        variant: "destructive",
      });
      return false;
    }

    if (!signupData.password) {
      toast({
        title: "Validation Error",
        description: "Password is required.",
        variant: "destructive",
      });
      return false;
    }

    if (signupData.password.length < 8) {
      toast({
        title: "Validation Error",
        description: "Password must be at least 8 characters long.",
        variant: "destructive",
      });
      return false;
    }

    if (signupData.password !== signupData.confirmPassword) {
      toast({
        title: "Validation Error",
        description: "Passwords do not match.",
        variant: "destructive",
      });
      return false;
    }

    if (!signupData.role) {
      toast({
        title: "Validation Error",
        description: "Please select your role.",
        variant: "destructive",
      });
      return false;
    }

    // Brand-specific validation
    if (signupData.role === "brand") {
      if (!signupData.company.trim()) {
        toast({
          title: "Validation Error",
          description: "Company name is required for brand accounts.",
          variant: "destructive",
        });
        return false;
      }
    }

    // Influencer-specific validation
    if (signupData.role === "influencer") {
      if (!signupData.bio.trim()) {
        toast({
          title: "Validation Error",
          description: "Bio is required for influencer accounts.",
          variant: "destructive",
        });
        return false;
      }

      // Validate social platforms
      const validPlatforms = signupData.socialPlatforms.filter(
        (platform) => platform.username && platform.followerCount > 0
      );

      if (validPlatforms.length === 0) {
        toast({
          title: "Social platform required",
          description:
            "Please add at least one social media platform with your follower count.",
          variant: "destructive",
        });
        return false;
      }

      // Validate follower count requirement
      const totalFollowers = signupData.socialPlatforms.reduce(
        (total, platform) => total + (platform.followerCount || 0),
        0
      );

      if (totalFollowers < 10000) {
        toast({
          title: "Minimum follower requirement",
          description: `Influencers need a minimum of 10,000 total followers. You currently have ${totalFollowers.toLocaleString()} followers.`,
          variant: "destructive",
        });
        return false;
      }

      // Validate social platform data completeness
      for (const platform of validPlatforms) {
        if (!platform.username.trim()) {
          toast({
            title: "Validation Error",
            description: `Username is required for ${platform.platform}.`,
            variant: "destructive",
          });
          return false;
        }

        if (platform.followerCount <= 0) {
          toast({
            title: "Validation Error",
            description: `Follower count must be greater than 0 for ${platform.platform}.`,
            variant: "destructive",
          });
          return false;
        }

        if (platform.engagementRate < 0 || platform.engagementRate > 100) {
          toast({
            title: "Validation Error",
            description: `Engagement rate must be between 0 and 100 for ${platform.platform}.`,
            variant: "destructive",
          });
          return false;
        }
      }

      // Validate required influencer fields
      if (signupData.categories.length === 0) {
        toast({
          title: "Validation Error",
          description: "Please select at least one content category.",
          variant: "destructive",
        });
        return false;
      }

      if (!signupData.location.country.trim()) {
        toast({
          title: "Validation Error",
          description: "Country is required.",
          variant: "destructive",
        });
        return false;
      }

      if (!signupData.location.city.trim()) {
        toast({
          title: "Validation Error",
          description: "City is required.",
          variant: "destructive",
        });
        return false;
      }

      if (!signupData.demographics.ageGroup) {
        toast({
          title: "Validation Error",
          description: "Please select your age group.",
          variant: "destructive",
        });
        return false;
      }

      if (!signupData.demographics.gender) {
        toast({
          title: "Validation Error",
          description: "Please select your gender.",
          variant: "destructive",
        });
        return false;
      }

      if (!signupData.demographics.primaryAudience.ageGroup) {
        toast({
          title: "Validation Error",
          description: "Please select your primary audience age group.",
          variant: "destructive",
        });
        return false;
      }

      if (!signupData.demographics.primaryAudience.gender) {
        toast({
          title: "Validation Error",
          description: "Please select your primary audience gender.",
          variant: "destructive",
        });
        return false;
      }

      if (signupData.contentTypes.length === 0) {
        toast({
          title: "Validation Error",
          description: "Please select at least one content type you create.",
          variant: "destructive",
        });
        return false;
      }

      if (signupData.collaborationTypes.length === 0) {
        toast({
          title: "Validation Error",
          description:
            "Please select at least one collaboration type you offer.",
          variant: "destructive",
        });
        return false;
      }

      if (!signupData.contentStyle.visualAesthetic) {
        toast({
          title: "Validation Error",
          description: "Please select your visual aesthetic.",
          variant: "destructive",
        });
        return false;
      }

      if (!signupData.contentStyle.toneOfVoice) {
        toast({
          title: "Validation Error",
          description: "Please select your tone of voice.",
          variant: "destructive",
        });
        return false;
      }

      if (!signupData.contentStyle.contentFrequency) {
        toast({
          title: "Validation Error",
          description: "Please select your posting frequency.",
          variant: "destructive",
        });
        return false;
      }

      if (signupData.languages.length === 0) {
        toast({
          title: "Validation Error",
          description: "Please specify at least one language you speak.",
          variant: "destructive",
        });
        return false;
      }

      if (!signupData.availability.status) {
        toast({
          title: "Validation Error",
          description: "Please select your current availability status.",
          variant: "destructive",
        });
        return false;
      }
    }

    return true;
  };

  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    clearError();

    // Validate all form fields
    if (!validateForm()) {
      return;
    }

    console.log("signUpData", signupData);

    // return;

    try {
      const userData = {
        email: signupData.email,
        name: signupData.name,
        password: signupData.password,
        role: signupData.role,
        ...(signupData.role === "brand" && { company: signupData.company }),
        ...(signupData.role === "influencer" && {
          bio: signupData.bio,
          socialPlatforms: signupData.socialPlatforms.filter(
            (platform) => platform.username && platform.followerCount > 0
          ),
          categories: signupData.categories,
          location: signupData.location,
          tags: signupData.tags,
          demographics: signupData.demographics,
          languages: signupData.languages,
          contentTypes: signupData.contentTypes,
          collaborationTypes: signupData.collaborationTypes,
          pricing: signupData.pricing,
          availability: signupData.availability,
          contentStyle: signupData.contentStyle,
        }),
      };

      const result = await signup(userData);

      if (result.success) {
        if (result.message) {
          // For influencers pending approval
          toast({
            title: "Registration Successful!",
            description: result.message,
            duration: 8000,
          });
          // Reset form
          setSignupData({
            email: "",
            password: "",
            confirmPassword: "",
            name: "",
            role: "brand" as UserRole,
            company: "",
            bio: "",
            socialPlatforms: [
              {
                platform: "instagram" as const,
                username: "",
                followerCount: 0,
                engagementRate: 0,
                profileUrl: "",
              },
            ],
            categories: [],
            location: { country: "", city: "" },
            tags: [],
            demographics: {
              ageGroup: "",
              gender: "",
              primaryAudience: {
                ageGroup: "",
                gender: "",
                locations: [],
                interests: [],
                languages: [],
              },
            },
            languages: [],
            contentTypes: [],
            collaborationTypes: [],
            pricing: {
              postPrice: 0,
              storyPrice: 0,
              videoPrice: 0,
              reelPrice: 0,
              currency: "USD",
              negotiable: true,
            },
            availability: {
              status: "available" as const,
              nextAvailable: "",
            },
            contentStyle: {
              visualAesthetic: "",
              toneOfVoice: "",
              contentFrequency: "",
            },
          });
        } else if (result.user) {
          // For other users, redirect to dashboard
          toast({
            title: "Account created!",
            description: "Welcome to InfluencerMatch.",
          });
          redirectToDashboard(result.user.role);
        }
      } else {
        toast({
          title: "Signup failed",
          description:
            result.message ||
            error ||
            "Something went wrong. Please try again.",
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Signup failed",
        description: "Something went wrong. Please try again.",
        variant: "destructive",
      });
    }
  };

  const roleOptions = [
    {
      value: "brand",
      label: "Brand",
      icon: Building,
      description: "I want to find influencers for my brand",
    },
    {
      value: "influencer",
      label: "Influencer",
      icon: Users,
      description: "I want to partner with brands",
    },
  ];

  const handleLanguageChange = (language: string, checked: boolean) => {
    setSignupData((prev) => ({
      ...prev,
      languages: checked
        ? [...(prev.languages || []), language]
        : (prev.languages || []).filter((l) => l !== language),
    }));
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-lg">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
            Welcome to InfluencerMatch
          </CardTitle>
          <CardDescription>Connect with authentic partnerships</CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="login" className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="login">Sign In</TabsTrigger>
              <TabsTrigger value="signup">Sign Up</TabsTrigger>
            </TabsList>

            <TabsContent value="login">
              <form onSubmit={handleLogin} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="login-email">Email</Label>
                  <Input
                    id="login-email"
                    type="email"
                    placeholder="Enter your email"
                    value={loginData.email}
                    onChange={(e) =>
                      setLoginData({ ...loginData, email: e.target.value })
                    }
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="login-password">Password</Label>
                  <div className="relative">
                    <Input
                      id="login-password"
                      type={showPassword ? "text" : "password"}
                      placeholder="Enter your password"
                      value={loginData.password}
                      onChange={(e) =>
                        setLoginData({ ...loginData, password: e.target.value })
                      }
                      required
                    />
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                      onClick={() => setShowPassword(!showPassword)}
                    >
                      {showPassword ? (
                        <EyeOff className="h-4 w-4" />
                      ) : (
                        <Eye className="h-4 w-4" />
                      )}
                    </Button>
                  </div>
                </div>

                <Button
                  type="submit"
                  className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700"
                  disabled={isLoading}
                >
                  {isLoading ? "Signing in..." : "Sign In"}
                </Button>

                <div className="text-center">
                  <Link
                    to="/forgot-password"
                    className="text-sm text-indigo-600 hover:text-indigo-700 underline"
                  >
                    Forgot your password?
                  </Link>
                </div>

                {error && (
                  <div className="text-sm text-red-600 text-center">
                    {error}
                  </div>
                )}
              </form>
            </TabsContent>

            <TabsContent value="signup">
              <form onSubmit={handleSignup} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="signup-name">Full Name</Label>
                  <Input
                    id="signup-name"
                    placeholder="Enter your full name"
                    value={signupData.name}
                    onChange={(e) =>
                      setSignupData({ ...signupData, name: e.target.value })
                    }
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="signup-email">Email</Label>
                  <Input
                    id="signup-email"
                    type="email"
                    placeholder="Enter your email"
                    value={signupData.email}
                    onChange={(e) =>
                      setSignupData({ ...signupData, email: e.target.value })
                    }
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="signup-password">Password</Label>
                  <div className="relative">
                    <Input
                      id="signup-password"
                      type={showPassword ? "text" : "password"}
                      placeholder="Create a password (min 8 characters)"
                      value={signupData.password}
                      onChange={(e) =>
                        setSignupData({
                          ...signupData,
                          password: e.target.value,
                        })
                      }
                      required
                      minLength={8}
                    />
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                      onClick={() => setShowPassword(!showPassword)}
                    >
                      {showPassword ? (
                        <EyeOff className="h-4 w-4" />
                      ) : (
                        <Eye className="h-4 w-4" />
                      )}
                    </Button>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="confirm-password">Confirm Password</Label>
                  <div className="relative">
                    <Input
                      id="confirm-password"
                      type={showConfirmPassword ? "text" : "password"}
                      placeholder="Confirm your password"
                      value={signupData.confirmPassword}
                      onChange={(e) =>
                        setSignupData({
                          ...signupData,
                          confirmPassword: e.target.value,
                        })
                      }
                      required
                    />
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                      onClick={() =>
                        setShowConfirmPassword(!showConfirmPassword)
                      }
                    >
                      {showConfirmPassword ? (
                        <EyeOff className="h-4 w-4" />
                      ) : (
                        <Eye className="h-4 w-4" />
                      )}
                    </Button>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>I am a...</Label>
                  <Select
                    value={signupData.role}
                    onValueChange={(value: UserRole) =>
                      setSignupData({ ...signupData, role: value })
                    }
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-white">
                      {roleOptions.map((role) => (
                        <SelectItem key={role.value} value={role.value}>
                          <div className="flex flex-col">
                            <div className="flex items-center">
                              <role.icon className="mr-2 h-4 w-4" />
                              {role.label}
                            </div>
                            <span className="text-xs text-gray-500">
                              {role.description}
                            </span>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {signupData.role === "brand" && (
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="company">Company Name</Label>
                      <Input
                        id="company"
                        placeholder="Enter your company name"
                        value={signupData.company}
                        onChange={(e) =>
                          setSignupData({
                            ...signupData,
                            company: e.target.value,
                          })
                        }
                        required
                      />
                    </div>

                    <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                      <div className="flex items-start">
                        <Mail className="h-5 w-5 text-blue-600 mt-0.5 mr-3" />
                        <div>
                          <h4 className="text-sm font-medium text-blue-900">
                            Brand Account Activation Required
                          </h4>
                          <p className="text-sm text-blue-700 mt-1">
                            After registration, contact our admin team at{" "}
                            <span className="font-medium">
                              admin@influencermatch.com
                            </span>{" "}
                            to activate your brand profile.
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {signupData.role === "influencer" && (
                  <>
                    <div className="space-y-2">
                      <Label htmlFor="bio">Bio</Label>
                      <Input
                        id="bio"
                        placeholder="Tell us about yourself"
                        value={signupData.bio}
                        onChange={(e) =>
                          setSignupData({ ...signupData, bio: e.target.value })
                        }
                      />
                    </div>

                    <div className="space-y-4">
                      <Label>
                        Social Media Platforms (Minimum 10,000 total followers
                        required)
                      </Label>
                      {signupData.socialPlatforms.map((platform, index) => (
                        <div
                          key={index}
                          className="p-4 border rounded-lg space-y-3"
                        >
                          <div className="flex items-center justify-between">
                            <h4 className="font-medium">
                              Platform {index + 1}
                            </h4>
                            {signupData.socialPlatforms.length > 1 && (
                              <Button
                                type="button"
                                variant="outline"
                                size="sm"
                                onClick={() => {
                                  const newPlatforms =
                                    signupData.socialPlatforms.filter(
                                      (_, i) => i !== index
                                    );
                                  setSignupData({
                                    ...signupData,
                                    socialPlatforms: newPlatforms,
                                  });
                                }}
                              >
                                Remove
                              </Button>
                            )}
                          </div>

                          <div className="grid grid-cols-2 gap-3">
                            <div>
                              <Label>Platform</Label>
                              <select
                                className="w-full p-2 border rounded-md"
                                value={platform.platform}
                                onChange={(e) => {
                                  const newPlatforms = [
                                    ...signupData.socialPlatforms,
                                  ];
                                  newPlatforms[index].platform = e.target
                                    .value as any;
                                  setSignupData({
                                    ...signupData,
                                    socialPlatforms: newPlatforms,
                                  });
                                }}
                              >
                                <option value="instagram">Instagram</option>
                                <option value="tiktok">TikTok</option>
                                <option value="youtube">YouTube</option>
                                <option value="twitter">Twitter</option>
                                <option value="facebook">Facebook</option>
                                <option value="linkedin">LinkedIn</option>
                                <option value="twitch">Twitch</option>
                                <option value="snapchat">Snapchat</option>
                              </select>
                            </div>

                            <div>
                              <Label>Username</Label>
                              <Input
                                placeholder="@username"
                                value={platform.username}
                                onChange={(e) => {
                                  const newPlatforms = [
                                    ...signupData.socialPlatforms,
                                  ];
                                  newPlatforms[index].username = e.target.value;
                                  setSignupData({
                                    ...signupData,
                                    socialPlatforms: newPlatforms,
                                  });
                                }}
                              />
                            </div>

                            <div>
                              <Label>Follower Count</Label>
                              <Input
                                type="number"
                                placeholder="e.g., 15000"
                                value={platform.followerCount || ""}
                                onChange={(e) => {
                                  const newPlatforms = [
                                    ...signupData.socialPlatforms,
                                  ];
                                  newPlatforms[index].followerCount =
                                    parseInt(e.target.value) || 0;
                                  setSignupData({
                                    ...signupData,
                                    socialPlatforms: newPlatforms,
                                  });
                                }}
                              />
                            </div>

                            <div>
                              <Label>Engagement Rate (%)</Label>
                              <Input
                                type="number"
                                step="0.1"
                                placeholder="e.g., 3.5"
                                value={platform.engagementRate || ""}
                                onChange={(e) => {
                                  const newPlatforms = [
                                    ...signupData.socialPlatforms,
                                  ];
                                  newPlatforms[index].engagementRate =
                                    parseFloat(e.target.value) || 0;
                                  setSignupData({
                                    ...signupData,
                                    socialPlatforms: newPlatforms,
                                  });
                                }}
                              />
                            </div>
                          </div>

                          <div>
                            <Label>Profile URL (Optional)</Label>
                            <Input
                              placeholder="https://..."
                              type="url"
                              value={platform.profileUrl}
                              onChange={(e) => {
                                const newPlatforms = [
                                  ...signupData.socialPlatforms,
                                ];
                                newPlatforms[index].profileUrl = e.target.value;
                                setSignupData({
                                  ...signupData,
                                  socialPlatforms: newPlatforms,
                                });
                              }}
                            />
                          </div>
                        </div>
                      ))}

                      <Button
                        type="button"
                        variant="outline"
                        onClick={() => {
                          const newPlatforms = [
                            ...signupData.socialPlatforms,
                            {
                              platform: "instagram" as const,
                              username: "",
                              followerCount: 0,
                              engagementRate: 0,
                              profileUrl: "",
                            },
                          ];
                          setSignupData({
                            ...signupData,
                            socialPlatforms: newPlatforms,
                          });
                        }}
                      >
                        Add Another Platform
                      </Button>

                      {/* Show total followers */}
                      <div className="text-sm text-gray-600">
                        Total Followers:{" "}
                        {signupData.socialPlatforms
                          .reduce(
                            (total, platform) =>
                              total + (platform.followerCount || 0),
                            0
                          )
                          .toLocaleString()}
                        {signupData.socialPlatforms.reduce(
                          (total, platform) =>
                            total + (platform.followerCount || 0),
                          0
                        ) < 10000 && (
                          <span className="text-red-500 ml-2">
                            (Minimum 10,000 required)
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Categories */}
                    <div className="space-y-2">
                      <Label>Content Categories</Label>
                      <div className="grid grid-cols-2 gap-2 max-h-40 overflow-y-auto border rounded p-3">
                        {[
                          "fashion",
                          "beauty",
                          "fitness",
                          "food",
                          "travel",
                          "lifestyle",
                          "technology",
                          "gaming",
                          "music",
                          "art",
                          "education",
                          "health",
                          "parenting",
                          "pets",
                          "sports",
                          "entertainment",
                          "comedy",
                          "diy",
                          "automotive",
                          "home",
                          "finance",
                          "books",
                          "photography",
                          "other",
                        ].map((category) => (
                          <label
                            key={category}
                            className="flex items-center space-x-2"
                          >
                            <input
                              type="checkbox"
                              checked={signupData.categories.includes(category)}
                              onChange={(e) => {
                                const newCategories = e.target.checked
                                  ? [...signupData.categories, category]
                                  : signupData.categories.filter(
                                      (c) => c !== category
                                    );
                                setSignupData({
                                  ...signupData,
                                  categories: newCategories,
                                });
                              }}
                            />
                            <span className="text-sm capitalize">
                              {category}
                            </span>
                          </label>
                        ))}
                      </div>
                    </div>

                    {/* Location */}
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <Label>Country</Label>
                        <Input
                          placeholder="e.g., United States"
                          value={signupData.location.country}
                          onChange={(e) =>
                            setSignupData({
                              ...signupData,
                              location: {
                                ...signupData.location,
                                country: e.target.value,
                              },
                            })
                          }
                        />
                      </div>
                      <div>
                        <Label>City</Label>
                        <Input
                          placeholder="e.g., New York"
                          value={signupData.location.city}
                          onChange={(e) =>
                            setSignupData({
                              ...signupData,
                              location: {
                                ...signupData.location,
                                city: e.target.value,
                              },
                            })
                          }
                        />
                      </div>
                    </div>

                    {/* Demographics */}
                    <div className="space-y-3">
                      <Label>Demographics</Label>
                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <Label className="text-sm">Your Age Group</Label>
                          <select
                            className="w-full p-2 border rounded-md"
                            value={signupData.demographics.ageGroup}
                            onChange={(e) =>
                              setSignupData({
                                ...signupData,
                                demographics: {
                                  ...signupData.demographics,
                                  ageGroup: e.target.value,
                                },
                              })
                            }
                          >
                            <option value="">Select age group</option>
                            {ageGroups.map((age) => (
                              <option key={age} value={age}>
                                {age}
                              </option>
                            ))}
                          </select>
                        </div>
                        <div>
                          <Label className="text-sm">Your Gender</Label>
                          <select
                            className="w-full p-2 border rounded-md"
                            value={signupData.demographics.gender}
                            onChange={(e) =>
                              setSignupData({
                                ...signupData,
                                demographics: {
                                  ...signupData.demographics,
                                  gender: e.target.value,
                                },
                              })
                            }
                          >
                            <option value="">Select gender</option>
                            {genders.map((gender) => (
                              <option key={gender} value={gender}>
                                {gender}
                              </option>
                            ))}
                          </select>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <Label className="text-sm">
                            Primary Audience Age
                          </Label>
                          <select
                            className="w-full p-2 border rounded-md"
                            value={
                              signupData.demographics.primaryAudience.ageGroup
                            }
                            onChange={(e) =>
                              setSignupData({
                                ...signupData,
                                demographics: {
                                  ...signupData.demographics,
                                  primaryAudience: {
                                    ...signupData.demographics.primaryAudience,
                                    ageGroup: e.target.value,
                                  },
                                },
                              })
                            }
                          >
                            <option value="">Select audience age</option>
                            {ageGroups.map((age) => (
                              <option key={age} value={age}>
                                {age}
                              </option>
                            ))}
                          </select>
                        </div>
                        <div>
                          <Label className="text-sm">
                            Primary Audience Gender
                          </Label>
                          <select
                            className="w-full p-2 border rounded-md"
                            value={
                              signupData.demographics.primaryAudience.gender
                            }
                            onChange={(e) =>
                              setSignupData({
                                ...signupData,
                                demographics: {
                                  ...signupData.demographics,
                                  primaryAudience: {
                                    ...signupData.demographics.primaryAudience,
                                    gender: e.target.value,
                                  },
                                },
                              })
                            }
                          >
                            <option value="">Select audience gender</option>
                            {audienceGenders.map((gender) => (
                              <option key={gender} value={gender}>
                                {gender}
                              </option>
                            ))}
                          </select>
                        </div>
                      </div>
                    </div>

                    {/* Content Types */}
                    <div className="space-y-2">
                      <Label>Content Types You Create</Label>
                      <div className="grid grid-cols-3 gap-2">
                        {[
                          "post",
                          "story",
                          "reel",
                          "video",
                          "article",
                          "review",
                          "unboxing",
                          "tutorial",
                          "other",
                        ].map((type) => (
                          <label
                            key={type}
                            className="flex items-center space-x-2"
                          >
                            <input
                              type="checkbox"
                              checked={signupData.contentTypes.includes(type)}
                              onChange={(e) => {
                                const newTypes = e.target.checked
                                  ? [...signupData.contentTypes, type]
                                  : signupData.contentTypes.filter(
                                      (t) => t !== type
                                    );
                                setSignupData({
                                  ...signupData,
                                  contentTypes: newTypes,
                                });
                              }}
                            />
                            <span className="text-sm capitalize">{type}</span>
                          </label>
                        ))}
                      </div>
                    </div>

                    {/* Collaboration Types */}
                    <div className="space-y-2">
                      <Label>Collaboration Types You Offer</Label>
                      <div className="grid grid-cols-2 gap-2">
                        {[
                          "sponsored-post",
                          "product-review",
                          "brand-ambassador",
                          "event-coverage",
                          "giveaway",
                          "takeover",
                          "affiliate",
                          "other",
                        ].map((type) => (
                          <label
                            key={type}
                            className="flex items-center space-x-2"
                          >
                            <input
                              type="checkbox"
                              checked={signupData.collaborationTypes.includes(
                                type
                              )}
                              onChange={(e) => {
                                const newTypes = e.target.checked
                                  ? [...signupData.collaborationTypes, type]
                                  : signupData.collaborationTypes.filter(
                                      (t) => t !== type
                                    );
                                setSignupData({
                                  ...signupData,
                                  collaborationTypes: newTypes,
                                });
                              }}
                            />
                            <span className="text-sm">
                              {type.replace("-", " ")}
                            </span>
                          </label>
                        ))}
                      </div>
                    </div>

                    {/* Content Style */}
                    <div className="space-y-3">
                      <Label>Content Style</Label>
                      <div className="grid grid-cols-3 gap-3">
                        <div>
                          <Label className="text-sm">Visual Aesthetic</Label>
                          <select
                            className="w-full p-2 border rounded-md"
                            value={signupData.contentStyle.visualAesthetic}
                            onChange={(e) =>
                              setSignupData({
                                ...signupData,
                                contentStyle: {
                                  ...signupData.contentStyle,
                                  visualAesthetic: e.target.value,
                                },
                              })
                            }
                          >
                            <option value="">Select aesthetic</option>
                            <option value="minimalist">Minimalist</option>
                            <option value="colorful">Colorful</option>
                            <option value="dark">Dark</option>
                            <option value="bright">Bright</option>
                            <option value="vintage">Vintage</option>
                            <option value="modern">Modern</option>
                            <option value="artistic">Artistic</option>
                            <option value="lifestyle">Lifestyle</option>
                          </select>
                        </div>
                        <div>
                          <Label className="text-sm">Tone of Voice</Label>
                          <select
                            className="w-full p-2 border rounded-md"
                            value={signupData.contentStyle.toneOfVoice}
                            onChange={(e) =>
                              setSignupData({
                                ...signupData,
                                contentStyle: {
                                  ...signupData.contentStyle,
                                  toneOfVoice: e.target.value,
                                },
                              })
                            }
                          >
                            <option value="">Select tone</option>
                            <option value="professional">Professional</option>
                            <option value="casual">Casual</option>
                            <option value="humorous">Humorous</option>
                            <option value="inspirational">Inspirational</option>
                            <option value="educational">Educational</option>
                            <option value="friendly">Friendly</option>
                            <option value="authoritative">Authoritative</option>
                          </select>
                        </div>
                        <div>
                          <Label className="text-sm">Posting Frequency</Label>
                          <select
                            className="w-full p-2 border rounded-md"
                            value={signupData.contentStyle.contentFrequency}
                            onChange={(e) =>
                              setSignupData({
                                ...signupData,
                                contentStyle: {
                                  ...signupData.contentStyle,
                                  contentFrequency: e.target.value,
                                },
                              })
                            }
                          >
                            <option value="">Select frequency</option>
                            <option value="daily">Daily</option>
                            <option value="weekly">Weekly</option>
                            <option value="bi-weekly">Bi-weekly</option>
                            <option value="monthly">Monthly</option>
                            <option value="as-needed">As needed</option>
                          </select>
                        </div>
                      </div>
                    </div>

                    {/* Pricing */}
                    <div className="space-y-3">
                      <Label>Pricing (Optional - can be set later)</Label>
                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <Label className="text-sm">Post Price (USD)</Label>
                          <Input
                            type="number"
                            placeholder="e.g., 500"
                            value={signupData.pricing.postPrice || ""}
                            onChange={(e) =>
                              setSignupData({
                                ...signupData,
                                pricing: {
                                  ...signupData.pricing,
                                  postPrice: parseInt(e.target.value) || 0,
                                },
                              })
                            }
                          />
                        </div>
                        <div>
                          <Label className="text-sm">Story Price (USD)</Label>
                          <Input
                            type="number"
                            placeholder="e.g., 200"
                            value={signupData.pricing.storyPrice || ""}
                            onChange={(e) =>
                              setSignupData({
                                ...signupData,
                                pricing: {
                                  ...signupData.pricing,
                                  storyPrice: parseInt(e.target.value) || 0,
                                },
                              })
                            }
                          />
                        </div>
                        <div>
                          <Label className="text-sm">Video Price (USD)</Label>
                          <Input
                            type="number"
                            placeholder="e.g., 1000"
                            value={signupData.pricing.videoPrice || ""}
                            onChange={(e) =>
                              setSignupData({
                                ...signupData,
                                pricing: {
                                  ...signupData.pricing,
                                  videoPrice: parseInt(e.target.value) || 0,
                                },
                              })
                            }
                          />
                        </div>
                        <div>
                          <Label className="text-sm">Reel Price (USD)</Label>
                          <Input
                            type="number"
                            placeholder="e.g., 800"
                            value={signupData.pricing.reelPrice || ""}
                            onChange={(e) =>
                              setSignupData({
                                ...signupData,
                                pricing: {
                                  ...signupData.pricing,
                                  reelPrice: parseInt(e.target.value) || 0,
                                },
                              })
                            }
                          />
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <input
                          type="checkbox"
                          id="negotiable"
                          checked={signupData.pricing.negotiable}
                          onChange={(e) =>
                            setSignupData({
                              ...signupData,
                              pricing: {
                                ...signupData.pricing,
                                negotiable: e.target.checked,
                              },
                            })
                          }
                        />
                        <Label htmlFor="negotiable" className="text-sm">
                          Prices are negotiable
                        </Label>
                      </div>
                    </div>

                    {/* Languages */}
                    <div className="space-y-2">
                      <Label>Languages You Speak</Label>
                      <div className="grid grid-cols-2 gap-2">
                        {languages.map((language) => (
                          <label
                            key={language}
                            className="flex items-center space-x-2"
                          >
                            <input
                              type="checkbox"
                              checked={signupData.languages.includes(language)}
                              onChange={(e) => {
                                const newLanguages = e.target.checked
                                  ? [...signupData.languages, language]
                                  : signupData.languages.filter(
                                      (l) => l !== language
                                    );
                                setSignupData({
                                  ...signupData,
                                  languages: newLanguages,
                                });
                              }}
                            />
                            <span className="text-sm capitalize">
                              {language}
                            </span>
                          </label>
                        ))}
                      </div>
                    </div>

                    {/* Tags */}
                    <div className="space-y-2">
                      <Label>Tags/Keywords</Label>
                      <Input
                        placeholder="e.g., lifestyle, vegan, sustainable (comma separated)"
                        value={signupData.tags.join(", ")}
                        onChange={(e) => {
                          const tags = e.target.value
                            .split(",")
                            .map((tag) => tag.trim().toLowerCase())
                            .filter((tag) => tag);
                          setSignupData({ ...signupData, tags });
                        }}
                      />
                    </div>

                    {/* Availability */}
                    <div className="space-y-2">
                      <Label>Current Availability</Label>
                      <select
                        className="w-full p-2 border rounded-md"
                        value={signupData.availability.status}
                        onChange={(e) =>
                          setSignupData({
                            ...signupData,
                            availability: {
                              ...signupData.availability,
                              status: e.target.value as any,
                            },
                          })
                        }
                      >
                        <option value="available">Available</option>
                        <option value="busy">Busy</option>
                        <option value="unavailable">Unavailable</option>
                      </select>
                    </div>
                  </>
                )}

                <Button
                  type="submit"
                  className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700"
                  disabled={isLoading}
                >
                  {isLoading ? "Creating Account..." : "Create Account"}
                </Button>

                {error && (
                  <div className="text-sm text-red-600 text-center">
                    {error}
                  </div>
                )}
              </form>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
};

export default Auth;
