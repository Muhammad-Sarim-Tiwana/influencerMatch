import { useState, useEffect, useCallback, useRef } from "react";
import { useNavigate } from "react-router-dom";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useAuthStore, UserRole } from "@/store/authStore";
import PendingInfluencers from "@/components/PendingInfluencers";
import brandService, { CreateBrandData } from "@/services/brandService";
import userService from "@/services/userService";
import {
  Users,
  Building,
  Crown,
  TrendingUp,
  Activity,
  UserCheck,
  Link,
  RefreshCw,
  Plus,
  Eye,
} from "lucide-react";
import { toast } from "@/components/ui/use-toast";

interface InfluencerStats {
  total: number;
  active: number;
  pending: number;
  rejected: number;
}

interface Brand {
  id: string;
  companyName: string;
  industry: string;
  companyType: string;
  description: string;
  website: string;
  logo: string;
  isActive: boolean;
  verificationStatus: string;
  user: {
    id: string;
    name: string;
    email: string;
    role: UserRole;
    isEmailVerified: boolean;
  };
}

interface ApiResponse {
  results: Brand[];
  page: number;
  limit: number;
  totalPages: number;
  totalResults: number;
}

const AdminDashboard = () => {
  const navigate = useNavigate();

  // Subscribe to store state
  const users = useAuthStore((state) => state.users);
  const brands = useAuthStore((state) => state.brands);
  const campaigns = useAuthStore((state) => state.campaigns);
  const isLoading = useAuthStore((state) => state.isLoading);
  const hasDataLoaded = useAuthStore((state) => state.hasDataLoaded);
  const toggleUserStatus = useAuthStore((state) => state.toggleUserStatus);
  const updateUserRole = useAuthStore((state) => state.updateUserRole);
  const linkBrandToUser = useAuthStore((state) => state.linkBrandToUser);
  const error = useAuthStore((state) => state.error);

  const [filterRole, setFilterRole] = useState<UserRole | "all">("all");
  const [linkingUserId, setLinkingUserId] = useState<string | null>(null);
  const [apiError, setApiError] = useState<string | null>(null);
  const [isCreateBrandModalOpen, setIsCreateBrandModalOpen] = useState(false);
  const [pendingUserId, setPendingUserId] = useState<string | null>(null);
  const [newBrandData, setNewBrandData] = useState<CreateBrandData>({
    companyName: "",
    description: "",
    website: "",
    industry: "",
    companyType: "startup",
  });
  const [influencerStats, setInfluencerStats] = useState<InfluencerStats>({
    total: 0,
    active: 0,
    pending: 0,
    rejected: 0,
  });
  const [statsLoading, setStatsLoading] = useState(true);
  const hasFetchedRef = useRef(false);
  const isInitializing = useRef(false);
  const fetchPromiseRef = useRef<Promise<void> | null>(null);

  // Fetch data only once when component mounts using useRef pattern
  useEffect(() => {
    const initializeData = async () => {
      // Prevent multiple initialization attempts
      if (hasFetchedRef.current || isInitializing.current) {
        console.log("Data already fetched or initializing, skipping...");
        return;
      }

      // Check if we already have data
      const currentState = useAuthStore.getState();
      if (currentState.brands.length > 0 && currentState.users.length > 0) {
        console.log("Data already available in store, skipping fetch");
        hasFetchedRef.current = true;
        return;
      }

      isInitializing.current = true;
      hasFetchedRef.current = true;

      try {
        setApiError(null);
        console.log("Initializing admin dashboard data...");

        // Use fetchPromiseRef to prevent duplicate calls
        if (fetchPromiseRef.current) {
          await fetchPromiseRef.current;
          return;
        }

        const { fetchBrands } = useAuthStore.getState();
        fetchPromiseRef.current = fetchBrands();
        await fetchPromiseRef.current;

        console.log("Admin dashboard data loaded successfully");
        toast({
          title: "Success",
          description: "Data loaded successfully",
        });
      } catch (err) {
        console.error("Failed to load admin data:", err);
        setApiError("Failed to load data. Please try again.");
        toast({
          variant: "destructive",
          title: "Error",
          description: "Failed to load dashboard data",
        });
        // Reset flags on error so user can retry
        hasFetchedRef.current = false;
      } finally {
        isInitializing.current = false;
        fetchPromiseRef.current = null;
      }
    };

    initializeData();
  }, []); // Empty dependency array - only run once on mount

  const fetchInfluencerStats = async () => {
    try {
      setStatsLoading(true);
      const stats = await userService.getInfluencerStats();
      setInfluencerStats(
        stats || {
          total: 0,
          active: 0,
          pending: 0,
          rejected: 0,
        }
      );
    } catch (error) {
      console.error("Failed to fetch influencer stats:", error);
      // Set default values on error to prevent undefined access
      setInfluencerStats({
        total: 0,
        active: 0,
        pending: 0,
        rejected: 0,
      });
    } finally {
      setStatsLoading(false);
    }
  };

  useEffect(() => {
    fetchInfluencerStats();
  }, []);

  const handleRefreshData = useCallback(async () => {
    // Prevent multiple simultaneous refresh calls
    if (isInitializing.current || fetchPromiseRef.current) {
      console.log("Already refreshing data, skipping...");
      return;
    }

    try {
      setApiError(null);
      isInitializing.current = true;

      const { fetchBrands } = useAuthStore.getState();
      fetchPromiseRef.current = fetchBrands();
      await fetchPromiseRef.current;

      toast({
        title: "Success",
        description: "Data refreshed successfully",
      });
    } catch (err) {
      setApiError("Failed to refresh data. Please try again.");
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to refresh dashboard data",
      });
    } finally {
      isInitializing.current = false;
      fetchPromiseRef.current = null;
    }
  }, []);

  const handleLinkBrand = useCallback(
    async (userId: string, brandId: string) => {
      try {
        if (brandId === "create-new") {
          // Open modal to create new brand
          setPendingUserId(userId);
          setIsCreateBrandModalOpen(true);
          return;
        }

        await linkBrandToUser(userId, brandId);
        setLinkingUserId(null);
        toast({
          title: "Success",
          description: "Brand linked successfully",
        });
      } catch (err) {
        toast({
          variant: "destructive",
          title: "Error",
          description: "Failed to link brand",
        });
      }
    },
    [linkBrandToUser]
  );

  const handleCreateAndLinkBrand = useCallback(async () => {
    if (!pendingUserId) return;

    try {
      // Create the brand profile for the user
      const newBrand = await brandService.createBrandForUser(
        pendingUserId,
        newBrandData
      );

      // Refresh the brands data
      const { fetchBrands } = useAuthStore.getState();
      await fetchBrands();

      // Close modal and reset states
      setIsCreateBrandModalOpen(false);
      setLinkingUserId(null);
      setPendingUserId(null);
      setNewBrandData({
        companyName: "",
        description: "",
        website: "",
        industry: "",
        companyType: "startup",
      });

      toast({
        title: "Success",
        description: "Brand profile created and linked successfully",
      });
    } catch (err) {
      console.error("Error creating brand:", err);
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to create brand profile",
      });
    }
  }, [pendingUserId, newBrandData]);

  const filteredUsers = users.filter(
    (user) => filterRole === "all" || user.role === filterRole
  );

  const stats = {
    totalUsers: users.length,
    activeUsers: users.filter((u) => u.isActive).length,
    totalBrands: brands.length,
    totalInfluencers: users.filter((u) => u.role === "influencer").length,
    totalCampaigns: campaigns.length,
    activeCampaigns: campaigns.filter((c) => c.status === "active").length,
  };

  const getRoleIcon = (role: UserRole) => {
    switch (role) {
      case "brand":
        return Building;
      case "influencer":
        return Users;
      default:
        return Users; // Fallback icon
    }
  };

  const getRoleBadgeColor = (role: UserRole) => {
    switch (role) {
      case "brand":
        return "bg-blue-100 text-blue-800";
      case "influencer":
        return "bg-green-100 text-green-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            Admin Dashboard
          </h1>
          <p className="text-gray-600">
            Manage users, monitor platform activity, and oversee campaigns.
          </p>
        </div>

        {apiError && (
          <div className="text-red-600 text-sm mb-4">{apiError}</div>
        )}

        {/* Debug Section - Remove this in production */}
        {/* {process.env.NODE_ENV === "development" && (
          <Card className="mb-6 border-orange-200 bg-orange-50">
            <CardHeader>
              <CardTitle className="text-sm text-orange-800">
                Debug Info
              </CardTitle>
            </CardHeader>
            <CardContent className="text-xs text-orange-700">
              <div>Loading: {isLoading ? "Yes" : "No"}</div>
              <div>Has Data Loaded: {hasDataLoaded ? "Yes" : "No"}</div>
              <div>Brands Count: {brands.length}</div>
              <div>Users Count: {users.length}</div>
              <div>
                Brands:{" "}
                {brands.map((b) => b.companyName).join(", ") || "None"}
              </div>
            </CardContent>
          </Card>
        )} */}

        {/* Stats Cards */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Users</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.totalUsers}</div>
              <p className="text-xs text-muted-foreground">
                {stats.activeUsers} active users
              </p>
            </CardContent>
          </Card>

          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Brands</CardTitle>
              <Building className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.totalBrands}</div>
              <p className="text-xs text-muted-foreground">
                Registered companies
              </p>
            </CardContent>
          </Card>

          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Influencers</CardTitle>
              <UserCheck className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {statsLoading ? "..." : influencerStats?.total ?? 0}
              </div>
              <div className="space-y-1 text-xs text-muted-foreground">
                <div className="flex justify-between">
                  <span>Active:</span>
                  <span className="text-green-600 font-medium">
                    {statsLoading ? "..." : influencerStats?.active ?? 0}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span>Pending:</span>
                  <span className="text-orange-600 font-medium">
                    {statsLoading ? "..." : influencerStats?.pending ?? 0}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span>Rejected:</span>
                  <span className="text-red-600 font-medium">
                    {statsLoading ? "..." : influencerStats?.rejected ?? 0}
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                Total Campaigns
              </CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.totalCampaigns}</div>
              <p className="text-xs text-muted-foreground">
                {stats.activeCampaigns} active campaigns
              </p>
            </CardContent>
          </Card>

          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                Platform Activity
              </CardTitle>
              <Activity className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">98%</div>
              <p className="text-xs text-muted-foreground">Uptime this month</p>
            </CardContent>
          </Card>
        </div>

        {/* Management Tabs */}
        <Tabs defaultValue="users" className="w-full">
          <TabsList className="grid w-full grid-cols-2 max-w-md">
            <TabsTrigger value="users" className="flex items-center space-x-2">
              <Users className="h-4 w-4" />
              <span>Users</span>
            </TabsTrigger>
            <TabsTrigger
              value="influencers"
              className="flex items-center space-x-2"
            >
              <UserCheck className="h-4 w-4" />
              <span>Influencers</span>
              {(influencerStats?.pending ?? 0) > 0 && (
                <Badge
                  variant="destructive"
                  className="ml-1 h-5 w-5 rounded-full p-0 text-xs"
                >
                  {influencerStats?.pending ?? 0}
                </Badge>
              )}
            </TabsTrigger>
          </TabsList>

          <TabsContent value="users" className="mt-6">
            <Card>
              <CardHeader>
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-2 sm:space-y-0">
                  <div>
                    <CardTitle>User Management</CardTitle>
                    <CardDescription>
                      View and manage all registered users
                    </CardDescription>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={handleRefreshData}
                      disabled={isLoading}
                    >
                      <RefreshCw
                        className={`h-4 w-4 mr-2 ${
                          isLoading ? "animate-spin" : ""
                        }`}
                      />
                      Refresh
                    </Button>
                    <Select
                      value={filterRole}
                      onValueChange={(value: UserRole | "all") =>
                        setFilterRole(value)
                      }
                    >
                      <SelectTrigger className="w-[180px]">
                        <SelectValue placeholder="Filter by role" />
                      </SelectTrigger>
                      <SelectContent className="bg-white">
                        <SelectItem value="all">All Roles</SelectItem>

                        <SelectItem value="brand">Brands</SelectItem>
                        <SelectItem value="influencer">Influencers</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <div className="text-center py-8">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600 mx-auto mb-4"></div>
                    <p className="text-gray-600">Loading users...</p>
                  </div>
                ) : error ? (
                  <div className="text-center py-8">
                    <p className="text-red-600">{error}</p>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={handleRefreshData}
                      className="mt-4"
                    >
                      Try Again
                    </Button>
                  </div>
                ) : filteredUsers.length === 0 ? (
                  <div className="text-center py-8">
                    <p className="text-gray-600">No users found</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {filteredUsers.map((user) => {
                      const RoleIcon = getRoleIcon(user.role);
                      const isLinking = linkingUserId === user.id;

                      return (
                        <div
                          key={user.id}
                          className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50 transition-colors"
                        >
                          <div className="flex items-center space-x-4">
                            <Avatar>
                              <AvatarImage src={user.avatar} alt={user.name} />
                              <AvatarFallback>
                                {user.name
                                  .split(" ")
                                  .map((n) => n[0])
                                  .join("")}
                              </AvatarFallback>
                            </Avatar>
                            <div>
                              <div className="flex items-center space-x-2">
                                <h3 className="font-semibold">{user.name}</h3>
                                <Badge className={getRoleBadgeColor(user.role)}>
                                  <RoleIcon className="mr-1 h-3 w-3" />
                                  {user.role}
                                </Badge>
                                {!user.isActive && (
                                  <Badge variant="secondary">Inactive</Badge>
                                )}
                                {user.brandProfile && (
                                  <Badge
                                    variant="outline"
                                    className="text-blue-600"
                                  >
                                    <Building className="mr-1 h-3 w-3" />
                                    {user.brandProfile.companyName}
                                  </Badge>
                                )}
                              </div>
                              <p className="text-sm text-gray-600">
                                {user.email}
                              </p>
                              {user.brandProfile?.industry && (
                                <p className="text-sm text-gray-500">
                                  {user.brandProfile.industry}
                                </p>
                              )}
                              {user.followers && (
                                <p className="text-sm text-gray-500">
                                  {user.followers.toLocaleString()} followers
                                </p>
                              )}
                            </div>
                          </div>
                          <div className="flex items-center space-x-2">
                            {/* View Profile Buttons */}
                            {user.role === "brand" && user.brandProfile && (
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() =>
                                  navigate(
                                    `/admin/brand/${user.brandProfile.id}`
                                  )
                                }
                              >
                                <Eye className="h-4 w-4 mr-1" />
                                View Profile
                              </Button>
                            )}
                            {user.role === "influencer" && (
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() =>
                                  navigate(`/admin/influencer/${user.id}`)
                                }
                              >
                                <Eye className="h-4 w-4 mr-1" />
                                View Profile
                              </Button>
                            )}

                            {user.role === "brand" && !user.brandProfile && (
                              <div className="flex items-center space-x-2">
                                {isLinking ? (
                                  <>
                                    <Select
                                      onValueChange={(brandId) =>
                                        handleLinkBrand(user.id, brandId)
                                      }
                                    >
                                      <SelectTrigger className="w-48">
                                        <SelectValue
                                          placeholder={
                                            isLoading
                                              ? "Loading brands..."
                                              : brands.length === 0
                                              ? "No brands available"
                                              : "Select brand profile"
                                          }
                                        />
                                      </SelectTrigger>
                                      <SelectContent className="bg-white">
                                        {brands.length === 0 ? (
                                          <SelectItem
                                            value="no-brands"
                                            disabled
                                          >
                                            No brands available
                                          </SelectItem>
                                        ) : (
                                          brands
                                            .filter(
                                              (b) =>
                                                !users.some(
                                                  (u) =>
                                                    u.brandProfile?.id === b.id
                                                )
                                            )
                                            .map((brand) => (
                                              <SelectItem
                                                key={brand.id}
                                                value={brand.id}
                                              >
                                                <div className="flex items-center space-x-2">
                                                  <span>
                                                    {brand.companyName}
                                                  </span>
                                                  <Badge
                                                    variant="outline"
                                                    className="text-xs"
                                                  >
                                                    {brand.industry}
                                                  </Badge>
                                                </div>
                                              </SelectItem>
                                            ))
                                        )}
                                        <SelectItem
                                          value="create-new"
                                          className="border-t font-medium text-blue-600 focus:text-blue-700 focus:bg-blue-50"
                                        >
                                          <div className="flex items-center space-x-2">
                                            <Plus className="h-4 w-4" />
                                            <span>
                                              Create New Brand Profile
                                            </span>
                                          </div>
                                        </SelectItem>
                                      </SelectContent>
                                    </Select>
                                    <Button
                                      size="sm"
                                      variant="outline"
                                      onClick={() => setLinkingUserId(null)}
                                    >
                                      Cancel
                                    </Button>
                                  </>
                                ) : (
                                  <Button
                                    size="sm"
                                    variant="outline"
                                    onClick={() => setLinkingUserId(user.id)}
                                  >
                                    <Link className="h-4 w-4 mr-1" />
                                    Link Brand
                                  </Button>
                                )}
                              </div>
                            )}
                            <Select
                              value={user.role}
                              onValueChange={(newRole: UserRole) =>
                                updateUserRole(user.id, newRole)
                              }
                            >
                              <SelectTrigger className="w-32">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent className="bg-white">
                                <SelectItem value="brand">Brand</SelectItem>
                                <SelectItem value="influencer">
                                  Influencer
                                </SelectItem>
                              </SelectContent>
                            </Select>
                            <Button
                              variant={
                                user.isActive ? "destructive" : "default"
                              }
                              size="sm"
                              onClick={async () => {
                                try {
                                  await toggleUserStatus(user.id);
                                  toast({
                                    title: "Success",
                                    description: `User ${
                                      user.isActive
                                        ? "deactivated"
                                        : "activated"
                                    } successfully`,
                                  });
                                } catch (error) {
                                  toast({
                                    variant: "destructive",
                                    title: "Error",
                                    description: "Failed to update user status",
                                  });
                                }
                              }}
                            >
                              {user.isActive ? "Deactivate" : "Activate"}
                            </Button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="influencers" className="mt-6">
            <PendingInfluencers onStatsUpdate={fetchInfluencerStats} />
          </TabsContent>
        </Tabs>
      </div>

      {/* Brand Creation Modal */}
      <Dialog
        open={isCreateBrandModalOpen}
        onOpenChange={setIsCreateBrandModalOpen}
      >
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Create New Brand Profile</DialogTitle>
            <DialogDescription>
              Create a new brand profile to link with the selected user.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="companyName">Company Name *</Label>
              <Input
                id="companyName"
                value={newBrandData.companyName}
                onChange={(e) =>
                  setNewBrandData({
                    ...newBrandData,
                    companyName: e.target.value,
                  })
                }
                placeholder="Enter company name"
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="industry">Industry</Label>
              <Select
                value={newBrandData.industry}
                onValueChange={(value) =>
                  setNewBrandData({
                    ...newBrandData,
                    industry: value,
                  })
                }
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select industry" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="technology">Technology</SelectItem>
                  <SelectItem value="fashion">Fashion</SelectItem>
                  <SelectItem value="beauty">Beauty</SelectItem>
                  <SelectItem value="fitness">Fitness</SelectItem>
                  <SelectItem value="food">Food & Beverage</SelectItem>
                  <SelectItem value="travel">Travel</SelectItem>
                  <SelectItem value="lifestyle">Lifestyle</SelectItem>
                  <SelectItem value="health">Health</SelectItem>
                  <SelectItem value="finance">Finance</SelectItem>
                  <SelectItem value="education">Education</SelectItem>
                  <SelectItem value="entertainment">Entertainment</SelectItem>
                  <SelectItem value="automotive">Automotive</SelectItem>
                  <SelectItem value="real-estate">Real Estate</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="companyType">Company Type</Label>
              <Select
                value={newBrandData.companyType}
                onValueChange={(value: CreateBrandData["companyType"]) =>
                  setNewBrandData({
                    ...newBrandData,
                    companyType: value,
                  })
                }
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select company type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="startup">Startup</SelectItem>
                  <SelectItem value="small-brand">Small Brand</SelectItem>
                  <SelectItem value="medium-enterprise">
                    Medium Enterprise
                  </SelectItem>
                  <SelectItem value="large-enterprise">
                    Large Enterprise
                  </SelectItem>
                  <SelectItem value="corporation">Corporation</SelectItem>
                  <SelectItem value="non-profit">Non-Profit</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="website">Website</Label>
              <Input
                id="website"
                value={newBrandData.website}
                onChange={(e) =>
                  setNewBrandData({
                    ...newBrandData,
                    website: e.target.value,
                  })
                }
                placeholder="https://example.com"
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                value={newBrandData.description}
                onChange={(e) =>
                  setNewBrandData({
                    ...newBrandData,
                    description: e.target.value,
                  })
                }
                placeholder="Brief description of the brand"
                rows={3}
              />
            </div>
          </div>
          <div className="flex justify-end space-x-2">
            <Button
              variant="outline"
              onClick={() => {
                setIsCreateBrandModalOpen(false);
                setLinkingUserId(null);
                setPendingUserId(null);
              }}
            >
              Cancel
            </Button>
            <Button
              onClick={handleCreateAndLinkBrand}
              disabled={!newBrandData.companyName.trim()}
            >
              <Plus className="h-4 w-4 mr-2" />
              Create & Link
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default AdminDashboard;
