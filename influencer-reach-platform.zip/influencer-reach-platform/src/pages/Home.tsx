import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { useNavigate } from "react-router-dom";
import {
  Users,
  TrendingUp,
  Shield,
  Zap,
  Star,
  Target,
  ChevronLeft,
  ChevronRight,
  Instagram,
  Youtube,
  Video,
} from "lucide-react";
import Footer from "@/components/Footer";
import { useState, useEffect } from "react";

const Home = () => {
  const navigate = useNavigate();
  const [currentInfluencer, setCurrentInfluencer] = useState(0);
  const [currentTestimonial, setCurrentTestimonial] = useState(0);

  const features = [
    {
      icon: Users,
      title: "Connect with Influencers",
      description:
        "Find and collaborate with authentic content creators who align with your brand values.",
    },
    {
      icon: TrendingUp,
      title: "Campaign Management",
      description:
        "Create, manage, and track your influencer marketing campaigns with powerful analytics.",
    },
    {
      icon: Shield,
      title: "Verified Profiles",
      description:
        "All influencers are verified to ensure authentic engagement and quality partnerships.",
    },
    {
      icon: Zap,
      title: "Quick Matching",
      description:
        "Our AI-powered algorithm matches brands with the perfect influencers in seconds.",
    },
  ];

  const influencers = [
    {
      id: 1,
      name: "Emma Rodriguez",
      category: "Lifestyle & Fashion",
      followers: "2.5M",
      engagement: "8.5%",
      image:
        "https://images.unsplash.com/photo-1494790108755-2616b612b5bb?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1887&q=80",
      platforms: [Instagram, Youtube],
      verified: true,
    },
    {
      id: 2,
      name: "Marcus Johnson",
      category: "Fitness & Wellness",
      followers: "1.8M",
      engagement: "12.3%",
      image:
        "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1887&q=80",
      platforms: [Instagram, Video],
      verified: true,
    },
    {
      id: 3,
      name: "Sophia Chen",
      category: "Tech & Gaming",
      followers: "3.2M",
      engagement: "9.8%",
      image:
        "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1770&q=80",
      platforms: [Youtube, Video],
      verified: true,
    },
    {
      id: 4,
      name: "David Park",
      category: "Food & Travel",
      followers: "1.5M",
      engagement: "11.2%",
      image:
        "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1770&q=80",
      platforms: [Instagram, Youtube],
      verified: true,
    },
    {
      id: 5,
      name: "Isabella Martinez",
      category: "Beauty & Skincare",
      followers: "4.1M",
      engagement: "7.9%",
      image:
        "https://images.unsplash.com/photo-1544005313-94ddf0286df2?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1888&q=80",
      platforms: [Instagram, Video],
      verified: true,
    },
    {
      id: 6,
      name: "Alex Thompson",
      category: "Lifestyle & Travel",
      followers: "900K",
      engagement: "15.2%",
      image: null, // No image to demonstrate default avatar
      platforms: [Instagram, Youtube],
      verified: true,
    },
    {
      id: 7,
      name: "Jordan Williams",
      category: "Technology",
      followers: "1.2M",
      engagement: "10.5%",
      image: "", // Empty string to demonstrate default avatar
      platforms: [Video, Youtube],
      verified: false,
    },
  ];

  const testimonials = [
    {
      name: "Sarah Johnson",
      role: "Marketing Director",
      company: "Fashion Forward",
      content:
        "InfluencerMatch helped us find the perfect influencers for our brand. Our campaign ROI increased by 300%!",
      avatar:
        "https://api.dicebear.com/7.x/avataaars/svg?seed=sarah-testimonial",
    },
    {
      name: "Mike Chen",
      role: "Content Creator",
      content:
        "As an influencer, this platform made it so easy to find brands that actually align with my values and audience.",
      avatar:
        "https://api.dicebear.com/7.x/avataaars/svg?seed=mike-testimonial",
    },
    {
      name: "Lisa Williams",
      role: "Brand Manager",
      company: "TechFlow Inc",
      content:
        "The analytics and reporting features are incredible. We can track every aspect of our campaigns in real-time.",
      avatar:
        "https://api.dicebear.com/7.x/avataaars/svg?seed=lisa-testimonial",
    },
    {
      name: "Alex Thompson",
      role: "Lifestyle Influencer",
      content:
        "I've tripled my brand partnerships since joining. The quality of matches is outstanding!",
      avatar:
        "https://api.dicebear.com/7.x/avataaars/svg?seed=alex-testimonial",
    },
  ];

  // Auto-rotating carousel for influencers
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentInfluencer((prev) => (prev + 1) % (influencers.length - 2));
    }, 3000);
    return () => clearInterval(timer);
  }, [influencers.length]);

  // Auto-rotating carousel for testimonials
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 4000);
    return () => clearInterval(timer);
  }, [testimonials.length]);

  const nextInfluencer = () => {
    setCurrentInfluencer((prev) => (prev + 1) % (influencers.length - 2));
  };

  const prevInfluencer = () => {
    setCurrentInfluencer(
      (prev) => (prev - 1 + (influencers.length - 2)) % (influencers.length - 2)
    );
  };

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-indigo-600 via-purple-600 to-pink-600 py-20 overflow-hidden relative">
        <div className="absolute inset-0 bg-gradient-to-br from-black/20 via-transparent to-black/10"></div>
        <div className="container mx-auto px-4 text-center relative z-10">
          <div className="animate-fade-in-up">
            <h1 className="text-5xl md:text-6xl font-bold mb-6 text-white drop-shadow-lg animate-pulse">
              Connect Brands with
              <br />
              Authentic Influencers
            </h1>
          </div>
          <div className="animate-fade-in-up animation-delay-200">
            <p className="text-xl text-white/90 mb-8 max-w-3xl mx-auto drop-shadow-md">
              The ultimate platform for brands and influencers to create
              meaningful partnerships that drive real results and authentic
              engagement.
            </p>
          </div>
          <div className="flex flex-col sm:flex-row gap-4 justify-center animate-fade-in-up animation-delay-400">
            <Button
              size="lg"
              onClick={() => navigate("/auth")}
              className="bg-white text-indigo-600 hover:bg-gray-100 hover:text-purple-600 text-lg px-8 py-6 transform hover:scale-105 transition-all duration-300 shadow-xl hover:shadow-2xl font-semibold border-0 rounded-full"
            >
              Start Your Journey
            </Button>
            <Button
              size="lg"
              variant="outline"
              onClick={() => navigate("/about")}
              className="text-lg px-8 py-6 border-2  border-white/30 text-indigo-600 hover:bg-white/10 hover:border-white/50 backdrop-blur-sm transform hover:scale-105 transition-all duration-300 rounded-full font-semibold"
            >
              Learn More
            </Button>
          </div>

          {/* Floating elements for visual appeal */}
          <div className="absolute top-10 left-10 w-20 h-20 bg-white/20 rounded-full opacity-60 animate-bounce animation-delay-1000 backdrop-blur-sm"></div>
          <div className="absolute top-32 right-16 w-12 h-12 bg-white/30 rounded-full opacity-50 animate-bounce animation-delay-2000 backdrop-blur-sm"></div>
          <div className="absolute bottom-20 left-20 w-16 h-16 bg-white/25 rounded-full opacity-55 animate-bounce animation-delay-1500 backdrop-blur-sm"></div>
        </div>
      </section>

      {/* Featured Influencers Carousel */}
      <section className="py-20 bg-gradient-to-r from-gray-50 to-gray-100">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16 animate-fade-in-up">
            <h2 className="text-4xl font-bold mb-4 bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
              Featured Influencers
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Discover top-performing content creators across various niches
            </p>
          </div>

          <div className="relative max-w-6xl mx-auto">
            <div className="overflow-hidden rounded-2xl">
              <div
                className="flex transition-transform duration-500 ease-in-out"
                style={{
                  transform: `translateX(-${currentInfluencer * (100 / 3)}%)`,
                }}
              >
                {influencers.map((influencer, index) => (
                  <div key={influencer.id} className="w-1/3 flex-shrink-0">
                    <Card className="mx-2 overflow-hidden shadow-2xl border-0 bg-white">
                      <div className="relative">
                        <img
                          src={
                            influencer.image ||
                            "https://api.dicebear.com/7.x/avataaars/svg?seed=" +
                              encodeURIComponent(influencer.name)
                          }
                          alt={influencer.name}
                          className="w-full h-60 object-cover"
                          onError={(e) => {
                            e.currentTarget.src =
                              "https://api.dicebear.com/7.x/avataaars/svg?seed=" +
                              encodeURIComponent(influencer.name);
                          }}
                        />
                        <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-sm px-3 py-1 rounded-full text-sm font-semibold text-indigo-600">
                          {influencer.verified && "✓ Verified"}
                        </div>
                        <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/60 to-transparent p-4 text-white">
                          <h3 className="text-xl font-bold mb-1">
                            {influencer.name}
                          </h3>
                          <p className="text-sm opacity-90">
                            {influencer.category}
                          </p>
                        </div>
                      </div>
                      <CardContent className="p-4">
                        <div className="flex justify-between items-center mb-3">
                          <div className="text-center">
                            <div className="text-lg font-bold text-indigo-600">
                              {influencer.followers}
                            </div>
                            <div className="text-xs text-gray-500">
                              Followers
                            </div>
                          </div>
                          <div className="text-center">
                            <div className="text-lg font-bold text-purple-600">
                              {influencer.engagement}
                            </div>
                            <div className="text-xs text-gray-500">
                              Engagement
                            </div>
                          </div>
                        </div>
                        <div className="flex justify-center space-x-2">
                          {influencer.platforms.map((Platform, idx) => (
                            <div
                              key={idx}
                              className="p-1.5 bg-gray-100 rounded-full"
                            >
                              <Platform className="h-4 w-4 text-gray-600" />
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                ))}
              </div>
            </div>

            {/* Carousel Controls */}
            <button
              onClick={prevInfluencer}
              className="absolute left-4 top-1/2 -translate-y-1/2 bg-white/80 backdrop-blur-sm hover:bg-white p-3 rounded-full shadow-lg transition-all duration-300 hover:scale-110"
            >
              <ChevronLeft className="h-6 w-6 text-gray-600" />
            </button>
            <button
              onClick={nextInfluencer}
              className="absolute right-4 top-1/2 -translate-y-1/2 bg-white/80 backdrop-blur-sm hover:bg-white p-3 rounded-full shadow-lg transition-all duration-300 hover:scale-110"
            >
              <ChevronRight className="h-6 w-6 text-gray-600" />
            </button>

            {/* Carousel Indicators */}
            <div className="flex justify-center mt-6 space-x-2">
              {Array.from({ length: influencers.length - 2 }, (_, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentInfluencer(index)}
                  className={`w-3 h-3 rounded-full transition-all duration-300 ${
                    index === currentInfluencer
                      ? "bg-indigo-600 scale-125"
                      : "bg-gray-300 hover:bg-gray-400"
                  }`}
                />
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16 animate-fade-in-up">
            <h2 className="text-4xl font-bold mb-4">
              Why Choose InfluencerMatch?
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              We make influencer marketing simple, effective, and authentic for
              both brands and creators.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <Card
                key={index}
                className="text-center hover:shadow-xl transition-all duration-500 border-0 bg-gradient-to-br from-white to-gray-50 transform hover:-translate-y-2 hover:scale-105 animate-fade-in-up group"
                style={{ animationDelay: `${index * 200}ms` }}
              >
                <CardHeader>
                  <div className="mx-auto w-16 h-16 bg-gradient-to-r from-indigo-100 to-purple-100 rounded-full flex items-center justify-center mb-4 transition-all duration-300 group-hover:scale-110 group-hover:rotate-6">
                    <feature.icon className="h-8 w-8 text-indigo-600 transition-all duration-300 group-hover:scale-110" />
                  </div>
                  <CardTitle className="text-xl transition-colors duration-300 group-hover:text-indigo-600">
                    {feature.title}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600">{feature.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-20 bg-gradient-to-r from-indigo-600 to-purple-600 relative overflow-hidden">
        <div className="absolute inset-0 bg-black/10"></div>
        <div className="container mx-auto px-4 relative z-10">
          <div className="grid md:grid-cols-3 gap-8 text-center text-white">
            <div className="animate-fade-in-up transform hover:scale-110 transition-all duration-500">
              <div className="text-4xl font-bold mb-2 animate-pulse">
                10,000+
              </div>
              <div className="text-indigo-100">Active Influencers</div>
            </div>
            <div className="animate-fade-in-up animation-delay-200 transform hover:scale-110 transition-all duration-500">
              <div className="text-4xl font-bold mb-2 animate-pulse">500+</div>
              <div className="text-indigo-100">Brand Partners</div>
            </div>
            <div className="animate-fade-in-up animation-delay-400 transform hover:scale-110 transition-all duration-500">
              <div className="text-4xl font-bold mb-2 animate-pulse">95%</div>
              <div className="text-indigo-100">Success Rate</div>
            </div>
          </div>
        </div>

        {/* Animated background elements */}
        <div className="absolute top-10 left-10 w-32 h-32 bg-white/10 rounded-full animate-bounce animation-delay-1000"></div>
        <div className="absolute bottom-10 right-10 w-24 h-24 bg-white/10 rounded-full animate-bounce animation-delay-2000"></div>
      </section>

      {/* Testimonials */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16 animate-fade-in-up">
            <h2 className="text-4xl font-bold mb-4">What Our Users Say</h2>
            <p className="text-xl text-gray-600">
              Real stories from brands and influencers who found success on our
              platform.
            </p>
          </div>

          <div className="relative max-w-4xl mx-auto">
            <div className="overflow-hidden">
              <div
                className="flex transition-transform duration-700 ease-in-out"
                style={{
                  transform: `translateX(-${currentTestimonial * 50}%)`,
                }}
              >
                {testimonials.map((testimonial, index) => (
                  <div key={index} className="w-1/2 flex-shrink-0 px-4">
                    <Card className="hover:shadow-xl transition-all duration-500 transform hover:-translate-y-1 bg-white border-0 shadow-lg">
                      <CardContent className="p-8">
                        <div className="flex items-center mb-6">
                          {[...Array(5)].map((_, i) => (
                            <Star
                              key={i}
                              className="h-5 w-5 text-yellow-400 fill-current animate-pulse"
                              style={{ animationDelay: `${i * 100}ms` }}
                            />
                          ))}
                        </div>
                        <p className="text-gray-600 mb-8 italic text-lg leading-relaxed">
                          "{testimonial.content}"
                        </p>
                        <div className="flex items-center">
                          <img
                            src={testimonial.avatar}
                            alt={testimonial.name}
                            className="w-14 h-14 rounded-full mr-4 ring-4 ring-indigo-100 transition-all duration-300 hover:ring-indigo-200"
                          />
                          <div>
                            <div className="font-semibold text-lg text-gray-800">
                              {testimonial.name}
                            </div>
                            <div className="text-sm text-gray-600">
                              {testimonial.role}
                              {testimonial.company &&
                                ` • ${testimonial.company}`}
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                ))}
              </div>
            </div>

            {/* Testimonial Indicators */}
            <div className="flex justify-center mt-8 space-x-2">
              {testimonials.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentTestimonial(index)}
                  className={`w-3 h-3 rounded-full transition-all duration-300 ${
                    index === currentTestimonial
                      ? "bg-indigo-600 scale-125"
                      : "bg-gray-300 hover:bg-gray-400"
                  }`}
                />
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-white relative overflow-hidden">
        <div className="container mx-auto px-4 text-center relative z-10">
          <div className="animate-fade-in-up">
            <h2 className="text-4xl font-bold mb-4 bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
              Ready to Get Started?
            </h2>
          </div>
          <div className="animate-fade-in-up animation-delay-200">
            <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
              Join thousands of brands and influencers who are already creating
              amazing partnerships on InfluencerMatch.
            </p>
          </div>
          <div className="animate-fade-in-up animation-delay-400">
            <Button
              size="lg"
              onClick={() => navigate("/auth")}
              className="bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-lg px-8 py-6 transform hover:scale-110 transition-all duration-300 shadow-xl hover:shadow-2xl"
            >
              Join InfluencerMatch Today
            </Button>
          </div>
        </div>

        {/* Animated background elements */}
        <div className="absolute top-10 right-10 w-20 h-20 bg-gradient-to-r from-indigo-100 to-purple-100 rounded-full opacity-50 animate-bounce animation-delay-1000"></div>
        <div className="absolute bottom-10 left-10 w-16 h-16 bg-gradient-to-r from-purple-100 to-pink-100 rounded-full opacity-50 animate-bounce animation-delay-1500"></div>
      </section>
      <Footer />
    </div>
  );
};

export default Home;
