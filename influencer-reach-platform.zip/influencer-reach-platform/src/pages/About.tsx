import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import { Users, Target, Zap, Shield, TrendingUp, Award } from "lucide-react";
import Footer from "@/components/Footer";

const About = () => {
  const navigate = useNavigate();

  const values = [
    {
      icon: Shield,
      title: "Authenticity First",
      description:
        "We believe in genuine partnerships that create real value for both brands and creators.",
    },
    {
      icon: Users,
      title: "Community Driven",
      description:
        "Our platform is built by creators, for creators, with input from the community at every step.",
    },
    {
      icon: TrendingUp,
      title: "Growth Focused",
      description:
        "We help both influencers and brands grow their reach and impact through strategic partnerships.",
    },
    {
      icon: Award,
      title: "Quality Excellence",
      description:
        "We maintain high standards to ensure every partnership delivers exceptional results.",
    },
  ];

  const stats = [
    { label: "Successful Campaigns", value: "25,000+" },
    { label: "Active Creators", value: "10,000+" },
    { label: "Brand Partners", value: "500+" },
    { label: "Countries Served", value: "50+" },
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-indigo-50 via-white to-purple-50 py-20">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-5xl font-bold mb-6 bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
              About InfluencerMatch
            </h1>
            <p className="text-xl text-gray-600 mb-8 leading-relaxed">
              We're on a mission to revolutionize influencer marketing by
              creating authentic connections between brands and content
              creators. Our platform empowers both sides to build meaningful
              partnerships that drive real results.
            </p>
            <Button
              size="lg"
              onClick={() => navigate("/auth")}
              className="bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-lg px-8 py-6"
            >
              Join Our Community
            </Button>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8 text-center">
            {stats.map((stat, index) => (
              <div key={index} className="space-y-2">
                <div className="text-4xl font-bold text-indigo-600">
                  {stat.value}
                </div>
                <div className="text-gray-600">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Story Section */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-4xl font-bold text-center mb-12">Our Story</h2>
            <div className="grid md:grid-cols-2 gap-12 items-center">
              <div>
                <h3 className="text-2xl font-semibold mb-4">
                  The Problem We Solved
                </h3>
                <p className="text-gray-600 mb-6">
                  Traditional influencer marketing was broken. Brands struggled
                  to find authentic creators who aligned with their values,
                  while influencers had limited access to quality brand
                  partnerships. The process was opaque, inefficient, and often
                  resulted in poor matches.
                </p>
                <h3 className="text-2xl font-semibold mb-4">Our Solution</h3>
                <p className="text-gray-600">
                  InfluencerMatch was born from the need to create a
                  transparent, efficient, and authentic platform where brands
                  and creators could find their perfect match. We use advanced
                  algorithms and human curation to ensure every partnership has
                  the potential for success.
                </p>
              </div>
              <div className="bg-gradient-to-br from-indigo-100 to-purple-100 rounded-lg p-8 text-center">
                <Target className="h-16 w-16 text-indigo-600 mx-auto mb-4" />
                <h3 className="text-xl font-semibold mb-2">Our Mission</h3>
                <p className="text-gray-600">
                  To democratize influencer marketing and make authentic brand
                  partnerships accessible to creators of all sizes while helping
                  brands connect with their ideal audiences.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Values Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-4">Our Values</h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              These core principles guide everything we do and shape the culture
              of our platform.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {values.map((value, index) => (
              <Card
                key={index}
                className="text-center hover:shadow-lg transition-shadow border-0 bg-gradient-to-br from-white to-gray-50"
              >
                <CardContent className="p-6">
                  <div className="mx-auto w-16 h-16 bg-gradient-to-r from-indigo-100 to-purple-100 rounded-full flex items-center justify-center mb-4">
                    <value.icon className="h-8 w-8 text-indigo-600" />
                  </div>
                  <h3 className="text-xl font-semibold mb-3">{value.title}</h3>
                  <p className="text-gray-600">{value.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section className="py-20 bg-gradient-to-r from-indigo-600 to-purple-600">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-4xl font-bold text-white mb-4">
            Built by Creators, for Creators
          </h2>
          <p className="text-xl text-indigo-100 mb-8 max-w-3xl mx-auto">
            Our team consists of former influencers, marketing professionals,
            and technology experts who understand the challenges and
            opportunities in the creator economy.
          </p>
          <div className="grid md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            <div className="text-center">
              <div className="w-24 h-24 bg-white/20 rounded-full mx-auto mb-4 flex items-center justify-center">
                <Users className="h-12 w-12 text-white" />
              </div>
              <h3 className="text-xl font-semibold text-white mb-2">
                Creator Experience
              </h3>
              <p className="text-indigo-100">
                Deep understanding of creator needs and challenges
              </p>
            </div>
            <div className="text-center">
              <div className="w-24 h-24 bg-white/20 rounded-full mx-auto mb-4 flex items-center justify-center">
                <Target className="h-12 w-12 text-white" />
              </div>
              <h3 className="text-xl font-semibold text-white mb-2">
                Marketing Expertise
              </h3>
              <p className="text-indigo-100">
                Years of experience in digital marketing and brand strategy
              </p>
            </div>
            <div className="text-center">
              <div className="w-24 h-24 bg-white/20 rounded-full mx-auto mb-4 flex items-center justify-center">
                <Zap className="h-12 w-12 text-white" />
              </div>
              <h3 className="text-xl font-semibold text-white mb-2">
                Technology Innovation
              </h3>
              <p className="text-indigo-100">
                Cutting-edge technology to power seamless connections
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-4xl font-bold mb-4">
            Ready to Join Our Mission?
          </h2>
          <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
            Whether you're a brand looking for authentic partnerships or a
            creator ready to monetize your influence, we're here to help you
            succeed.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              size="lg"
              onClick={() => navigate("/auth")}
              className="bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-lg px-8 py-6"
            >
              Get Started Today
            </Button>
            <Button
              size="lg"
              variant="outline"
              onClick={() => navigate("/contact")}
              className="text-lg px-8 py-6 border-2 border-indigo-200 hover:border-indigo-300"
            >
              Contact Us
            </Button>
          </div>
        </div>
      </section>
      <Footer />
    </div>
  );
};

export default About;
