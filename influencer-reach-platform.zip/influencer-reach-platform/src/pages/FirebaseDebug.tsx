import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { firebaseChatService } from "@/services/firebaseChatService";
import { useAuthStore } from "@/store/authStore";
import { CheckCircle, XCircle, AlertTriangle } from "lucide-react";

const FirebaseDebug: React.FC = () => {
  const { user } = useAuthStore();
  const [debugResults, setDebugResults] = useState<{
    firebaseConfig: boolean;
    databaseConnection: boolean;
    conversationCreation: boolean;
    error?: string;
  } | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const runTests = async () => {
    setIsLoading(true);
    const results = {
      firebaseConfig: false,
      databaseConnection: false,
      conversationCreation: false,
      error: undefined as string | undefined,
    };

    try {
      // Test 1: Check Firebase config
      const config = {
        apiKey: import.meta.env.VITE_FIREBASE_API_KEY,
        authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN,
        databaseURL: import.meta.env.VITE_FIREBASE_DATABASE_URL,
        projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID,
      };

      results.firebaseConfig = !!(
        config.apiKey &&
        config.authDomain &&
        config.databaseURL &&
        config.projectId
      );

      // Test 2: Try to connect to database (read test)
      try {
        await firebaseChatService.getUserConversations(user?.id || "test-user");
        results.databaseConnection = true;
      } catch (error) {
        console.error("Database connection test failed:", error);
        results.error = `Database connection: ${error}`;
      }

      // Test 3: Try to create a test conversation
      if (user && results.databaseConnection) {
        try {
          const testConversationId =
            await firebaseChatService.createOrGetConversation(
              user.id,
              user.name,
              user.role as "influencer" | "brand" | "superadmin",
              "test-user-id",
              "Test User",
              "brand"
            );
          results.conversationCreation = !!testConversationId;
        } catch (error) {
          console.error("Conversation creation test failed:", error);
          results.error = `Conversation creation: ${error}`;
        }
      }
    } catch (error) {
      results.error = `General error: ${error}`;
    }

    setDebugResults(results);
    setIsLoading(false);
  };

  const getStatusIcon = (status: boolean) => {
    return status ? (
      <CheckCircle className="h-5 w-5 text-green-600" />
    ) : (
      <XCircle className="h-5 w-5 text-red-600" />
    );
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <Card className="max-w-2xl mx-auto">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <AlertTriangle className="h-5 w-5" />
            <span>Firebase Chat System Debug</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div>
            <h3 className="font-semibold mb-2">Environment Variables</h3>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span>VITE_FIREBASE_API_KEY:</span>
                <span
                  className={
                    import.meta.env.VITE_FIREBASE_API_KEY
                      ? "text-green-600"
                      : "text-red-600"
                  }
                >
                  {import.meta.env.VITE_FIREBASE_API_KEY
                    ? "✓ Set"
                    : "✗ Missing"}
                </span>
              </div>
              <div className="flex justify-between">
                <span>VITE_FIREBASE_DATABASE_URL:</span>
                <span
                  className={
                    import.meta.env.VITE_FIREBASE_DATABASE_URL
                      ? "text-green-600"
                      : "text-red-600"
                  }
                >
                  {import.meta.env.VITE_FIREBASE_DATABASE_URL
                    ? "✓ Set"
                    : "✗ Missing"}
                </span>
              </div>
              <div className="flex justify-between">
                <span>VITE_FIREBASE_PROJECT_ID:</span>
                <span
                  className={
                    import.meta.env.VITE_FIREBASE_PROJECT_ID
                      ? "text-green-600"
                      : "text-red-600"
                  }
                >
                  {import.meta.env.VITE_FIREBASE_PROJECT_ID
                    ? "✓ Set"
                    : "✗ Missing"}
                </span>
              </div>
            </div>
          </div>

          <div>
            <h3 className="font-semibold mb-2">Current User</h3>
            <div className="text-sm space-y-1">
              <div>ID: {user?.id || "Not logged in"}</div>
              <div>Name: {user?.name || "N/A"}</div>
              <div>Role: {user?.role || "N/A"}</div>
            </div>
          </div>

          <Button onClick={runTests} disabled={isLoading} className="w-full">
            {isLoading ? "Running Tests..." : "Run Firebase Tests"}
          </Button>

          {debugResults && (
            <div className="space-y-3">
              <h3 className="font-semibold">Test Results</h3>

              <div className="flex items-center justify-between p-3 border rounded">
                <span>Firebase Configuration</span>
                {getStatusIcon(debugResults.firebaseConfig)}
              </div>

              <div className="flex items-center justify-between p-3 border rounded">
                <span>Database Connection</span>
                {getStatusIcon(debugResults.databaseConnection)}
              </div>

              <div className="flex items-center justify-between p-3 border rounded">
                <span>Conversation Creation</span>
                {getStatusIcon(debugResults.conversationCreation)}
              </div>

              {debugResults.error && (
                <Alert variant="destructive">
                  <AlertTriangle className="h-4 w-4" />
                  <AlertDescription>
                    <strong>Error:</strong> {debugResults.error}
                  </AlertDescription>
                </Alert>
              )}
            </div>
          )}

          <div className="text-sm text-muted-foreground">
            <h4 className="font-semibold">Common Issues:</h4>
            <ul className="list-disc list-inside space-y-1 mt-2">
              <li>Missing Firebase environment variables in .env file</li>
              <li>Firebase project not configured for Realtime Database</li>
              <li>Database rules blocking read/write access</li>
              <li>Network connectivity issues</li>
            </ul>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default FirebaseDebug;
