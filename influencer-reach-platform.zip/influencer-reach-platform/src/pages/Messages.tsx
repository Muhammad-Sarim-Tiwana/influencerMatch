import React, { useState, useEffect } from "react";
import { useAuthStore } from "@/store/authStore";
import { useLocation } from "react-router-dom";
import ChatList from "@/components/ChatListNew";
import Chat from "@/components/ChatNew";
import { Card, CardContent } from "@/components/ui/card";

const Messages: React.FC = () => {
  const { user } = useAuthStore();
  const location = useLocation();
  const [selectedConversation, setSelectedConversation] = useState<{
    conversationId: string;
    otherParticipant: {
      id: string;
      name: string;
      role: "influencer" | "brand" | "superadmin";
    };
  } | null>(null);

  // Handle navigation state from other pages
  useEffect(() => {
    if (location.state?.selectedConversation) {
      const { conversationId, otherParticipant } =
        location.state.selectedConversation;
      setSelectedConversation({
        conversationId: conversationId || "", // Use the provided conversation ID
        otherParticipant,
      });
    }
  }, [location.state]);

  const handleConversationSelect = (
    conversationId: string,
    otherParticipant: {
      id: string;
      name: string;
      role: "influencer" | "brand" | "superadmin";
    }
  ) => {
    setSelectedConversation({ conversationId, otherParticipant });
  };

  const handleBackToList = () => {
    setSelectedConversation(null);
  };

  if (!user) {
    return (
      <div className="container mx-auto px-4 py-8">
        <Card className="h-[600px] flex items-center justify-center">
          <CardContent>
            <p className="text-muted-foreground">
              Please log in to access messages.
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-6">
        <h1 className="text-3xl font-bold tracking-tight">Messages</h1>
        <p className="text-muted-foreground">
          Communicate with other users in real-time
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Chat List - Always visible on desktop, hidden on mobile when conversation is selected */}
        <div
          className={`${selectedConversation ? "hidden lg:block" : "block"}`}
        >
          <ChatList onConversationSelect={handleConversationSelect} />
        </div>

        {/* Chat Window - Only visible when conversation is selected */}
        {selectedConversation ? (
          <div className="lg:col-span-1">
            <Chat
              conversationId={selectedConversation.conversationId}
              recipientId={selectedConversation.otherParticipant.id}
              recipientName={selectedConversation.otherParticipant.name}
              recipientRole={selectedConversation.otherParticipant.role}
              onBack={handleBackToList}
            />
          </div>
        ) : (
          /* Placeholder when no conversation is selected */
          <div className="hidden lg:block">
            <Card className="h-[600px] flex items-center justify-center">
              <CardContent className="text-center">
                <div className="text-6xl mb-4">💬</div>
                <h3 className="text-xl font-semibold mb-2">
                  Select a conversation
                </h3>
                <p className="text-muted-foreground">
                  Choose a conversation from the list to start messaging
                </p>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
};

export default Messages;
