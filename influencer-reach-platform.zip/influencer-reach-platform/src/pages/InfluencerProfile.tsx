import { useState, useEffect } from "react";
import { useParams, useNavigate, useSearchParams } from "react-router-dom";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useAuthStore } from "@/store/authStore";
import userService, { BackendUser } from "@/services/userService";
import { campaignService } from "@/services/campaignService";
import {
  initiateCampaignConversation,
  initiateUserConversation,
} from "@/utils/chatUtils";
import { toast } from "@/hooks/use-toast";
import {
  Users,
  MapPin,
  Calendar,
  MessageCircle,
  ArrowLeft,
  Star,
  CheckCircle,
  TrendingUp,
  Globe,
  Instagram,
  Youtube,
  Twitter,
  Heart,
  Eye,
  DollarSign,
  Briefcase,
  Award,
  Clock,
  Languages,
  Video,
  Image,
  Link,
  Palette,
  Handshake,
  Tag,
} from "lucide-react";

const InfluencerProfile = () => {
  const { id } = useParams<{ id: string }>();
  const [searchParams] = useSearchParams();
  const campaignId = searchParams.get("campaignId");
  const navigate = useNavigate();
  const { user } = useAuthStore();
  const [influencer, setInfluencer] = useState<BackendUser | null>(null);
  const [campaign, setCampaign] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (id) {
      loadInfluencer();
    }
    if (campaignId) {
      loadCampaign();
    }
  }, [id, campaignId]);

  const loadInfluencer = async () => {
    if (!id) {
      console.error("InfluencerProfile: ID is undefined or empty:", id);
      setError("Invalid influencer ID");
      return;
    }

    setIsLoading(true);
    setError(null);
    try {
      const influencerData = await userService.getInfluencerById(id);

      // Check if the response is valid
      if (!influencerData) {
        setError("Influencer not found");
        return;
      }

      // Double-check that this is actually an influencer
      if (influencerData.role !== "influencer") {
        setError("User is not an influencer");
        return;
      }

      setInfluencer(influencerData);
    } catch (error: any) {
      console.error("Failed to load influencer:", error);
      // Check if it's a 404 error
      if (error.response && error.response.status === 404) {
        setError("Influencer not found");
      } else {
        setError("Failed to load influencer profile");
      }
      toast({
        title: "Error",
        description: "Failed to load influencer profile. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const loadCampaign = async () => {
    if (!campaignId) return;

    try {
      const campaignData = await campaignService.getCampaign(campaignId);
      setCampaign(campaignData);
    } catch (error: any) {
      console.error("Failed to load campaign:", error);
      // Don't show error toast for campaign loading failure as it's not critical
    }
  };

  const formatFollowers = (count: number | undefined | null) => {
    if (!count || count === 0) {
      return "0";
    }
    if (count >= 1000000) {
      return `${(count / 1000000).toFixed(1)}M`;
    } else if (count >= 1000) {
      return `${(count / 1000).toFixed(1)}K`;
    }
    return count.toString();
  };

  const getPlatformIcon = (platform: string) => {
    switch (platform.toLowerCase()) {
      case "instagram":
        return <Instagram className="h-4 w-4" />;
      case "youtube":
        return <Youtube className="h-4 w-4" />;
      case "twitter":
        return <Twitter className="h-4 w-4" />;
      default:
        return <Globe className="h-4 w-4" />;
    }
  };

  const getAvailabilityColor = (status?: string) => {
    switch (status) {
      case "available":
        return "bg-green-100 text-green-800";
      case "busy":
        return "bg-yellow-100 text-yellow-800";
      case "unavailable":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const handleStartChat = async () => {
    if (!user || !influencer) {
      toast({
        title: "Authentication required",
        description: "Please log in to start a chat.",
        variant: "destructive",
      });
      return;
    }

    try {
      let conversationId: string;

      // If we have campaign context, initiate campaign-specific conversation
      if (campaignId && campaign) {
        conversationId = await initiateCampaignConversation(
          {
            id: user.id,
            name: user.name,
            role: user.role as "influencer" | "brand" | "superadmin",
          },
          {
            id: influencer.id,
            name: influencer.name,
            role: "influencer",
          },
          {
            id: campaign.id || campaignId,
            title: campaign.title || "Campaign Chat",
          }
        );
      } else {
        // Regular user conversation
        conversationId = await initiateUserConversation(
          {
            id: user.id,
            name: user.name,
            role: user.role as "influencer" | "brand" | "superadmin",
          },
          {
            id: influencer.id,
            name: influencer.name,
            role: "influencer",
          }
        );
      }

      // Navigate to messages page with selected conversation
      navigate("/messages", {
        state: {
          selectedConversation: {
            conversationId,
            otherParticipant: {
              id: influencer.id,
              name: influencer.name,
              role: "influencer" as const,
            },
          },
        },
      });

      toast({
        title: "Chat started!",
        description: `Starting conversation with ${influencer.name}`,
      });
    } catch (error) {
      console.error("Failed to start conversation:", error);
      toast({
        title: "Error",
        description: "Failed to start conversation. Please try again.",
        variant: "destructive",
      });
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <div className="container mx-auto px-4 py-8">
          <Skeleton className="h-10 w-32 mb-6" />
          <div className="max-w-4xl mx-auto">
            <Card>
              <CardHeader className="text-center">
                <Skeleton className="w-32 h-32 rounded-full mx-auto mb-4" />
                <Skeleton className="h-8 w-48 mx-auto mb-2" />
                <Skeleton className="h-4 w-32 mx-auto" />
              </CardHeader>
              <CardContent className="space-y-6">
                <Skeleton className="h-20 w-full" />
                <div className="grid md:grid-cols-3 gap-4">
                  <Skeleton className="h-20 w-full" />
                  <Skeleton className="h-20 w-full" />
                  <Skeleton className="h-20 w-full" />
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    );
  }

  if (error || !influencer) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">
            {error || "Influencer not found"}
          </h2>
          <Button onClick={() => navigate(-1)}>
            <ArrowLeft className="h-4 w-4 mr-2" />
            Go Back
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        <Button variant="ghost" onClick={() => navigate(-1)} className="mb-6">
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back
        </Button>

        <div className="max-w-6xl mx-auto">
          {/* Header Card */}
          <Card className="mb-6">
            <CardHeader>
              <div className="flex flex-col md:flex-row items-center md:items-start gap-6">
                <div className="relative">
                  <Avatar className="w-32 h-32">
                    <AvatarImage
                      src={influencer.profileImage}
                      alt={influencer.name}
                    />
                    <AvatarFallback className="text-3xl">
                      {influencer.name
                        .split(" ")
                        .map((n) => n[0])
                        .join("")}
                    </AvatarFallback>
                  </Avatar>
                  {influencer.verificationStatus === "verified" && (
                    <CheckCircle className="absolute -bottom-2 -right-2 h-8 w-8 text-blue-600 bg-white rounded-full" />
                  )}
                </div>

                <div className="flex-1 text-center md:text-left">
                  <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-4">
                    <div>
                      <CardTitle className="text-3xl mb-2">
                        {influencer.name}
                      </CardTitle>
                      <CardDescription className="text-lg">
                        {influencer.bio || "Content Creator & Influencer"}
                      </CardDescription>
                    </div>

                    <div className="flex items-center gap-4 mt-4 md:mt-0">
                      {influencer.availability?.status && (
                        <Badge
                          className={getAvailabilityColor(
                            influencer.availability.status
                          )}
                        >
                          <Clock className="h-3 w-3 mr-1" />
                          {influencer.availability.status
                            .charAt(0)
                            .toUpperCase() +
                            influencer.availability.status.slice(1)}
                        </Badge>
                      )}

                      {influencer.metrics?.rating && (
                        <div className="flex items-center bg-yellow-50 px-3 py-1 rounded-full">
                          <Star className="h-4 w-4 text-yellow-500 fill-current mr-1" />
                          <span className="font-semibold text-yellow-700">
                            {influencer.metrics.rating.toFixed(1)}
                          </span>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Quick Stats - Only show metrics that have actual values */}
                  {influencer.metrics &&
                    (influencer.metrics.totalFollowers ||
                      influencer.metrics.averageEngagement ||
                      influencer.metrics.completedCampaigns ||
                      influencer.metrics.responseRate) && (
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                        {influencer.metrics.totalFollowers && (
                          <div className="text-center p-3 bg-blue-50 rounded-lg">
                            <Users className="h-5 w-5 text-blue-600 mx-auto mb-1" />
                            <p className="text-xs text-gray-600">
                              Total Followers
                            </p>
                            <p className="font-bold text-blue-600">
                              {formatFollowers(
                                influencer.metrics.totalFollowers
                              )}
                            </p>
                          </div>
                        )}

                        {influencer.metrics.averageEngagement && (
                          <div className="text-center p-3 bg-green-50 rounded-lg">
                            <TrendingUp className="h-5 w-5 text-green-600 mx-auto mb-1" />
                            <p className="text-xs text-gray-600">
                              Avg. Engagement
                            </p>
                            <p className="font-bold text-green-600">
                              {influencer.metrics.averageEngagement.toFixed(1)}%
                            </p>
                          </div>
                        )}

                        {influencer.metrics.completedCampaigns && (
                          <div className="text-center p-3 bg-purple-50 rounded-lg">
                            <Briefcase className="h-5 w-5 text-purple-600 mx-auto mb-1" />
                            <p className="text-xs text-gray-600">Campaigns</p>
                            <p className="font-bold text-purple-600">
                              {influencer.metrics.completedCampaigns}
                            </p>
                          </div>
                        )}

                        {influencer.metrics.responseRate && (
                          <div className="text-center p-3 bg-orange-50 rounded-lg">
                            <Award className="h-5 w-5 text-orange-600 mx-auto mb-1" />
                            <p className="text-xs text-gray-600">
                              Response Rate
                            </p>
                            <p className="font-bold text-orange-600">
                              {influencer.metrics.responseRate}%
                            </p>
                          </div>
                        )}
                      </div>
                    )}

                  {/* Extended Stats - Only show stats that have actual data */}
                  {((influencer.socialPlatforms &&
                    influencer.socialPlatforms.length > 0) ||
                    (influencer.categories &&
                      influencer.categories.length > 0) ||
                    (influencer.languages && influencer.languages.length > 0) ||
                    (influencer.portfolio && influencer.portfolio.length > 0) ||
                    (influencer.pastBrands &&
                      influencer.pastBrands.length > 0)) && (
                    <div className="grid grid-cols-2 md:grid-cols-5 gap-3 mt-4">
                      {influencer.socialPlatforms &&
                        influencer.socialPlatforms.length > 0 && (
                          <div className="text-center p-2 bg-gray-50 rounded">
                            <p className="text-xs text-gray-600">Platforms</p>
                            <p className="font-semibold text-gray-800">
                              {influencer.socialPlatforms.length}
                            </p>
                          </div>
                        )}

                      {influencer.categories &&
                        influencer.categories.length > 0 && (
                          <div className="text-center p-2 bg-gray-50 rounded">
                            <p className="text-xs text-gray-600">Categories</p>
                            <p className="font-semibold text-gray-800">
                              {influencer.categories.length}
                            </p>
                          </div>
                        )}

                      {influencer.languages &&
                        influencer.languages.length > 0 && (
                          <div className="text-center p-2 bg-gray-50 rounded">
                            <p className="text-xs text-gray-600">Languages</p>
                            <p className="font-semibold text-gray-800">
                              {influencer.languages.length}
                            </p>
                          </div>
                        )}

                      {influencer.portfolio &&
                        influencer.portfolio.length > 0 && (
                          <div className="text-center p-2 bg-gray-50 rounded">
                            <p className="text-xs text-gray-600">Portfolio</p>
                            <p className="font-semibold text-gray-800">
                              {influencer.portfolio.length}
                            </p>
                          </div>
                        )}

                      {influencer.pastBrands &&
                        influencer.pastBrands.length > 0 && (
                          <div className="text-center p-2 bg-gray-50 rounded">
                            <p className="text-xs text-gray-600">Past Brands</p>
                            <p className="font-semibold text-gray-800">
                              {influencer.pastBrands.length}
                            </p>
                          </div>
                        )}
                    </div>
                  )}
                </div>
              </div>
            </CardHeader>
          </Card>

          {/* Tabs Content */}
          <Tabs defaultValue="overview" className="space-y-6">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="platforms">Platforms</TabsTrigger>
              <TabsTrigger value="pricing">Pricing</TabsTrigger>
              <TabsTrigger value="details">Details</TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                {/* About Section */}
                <Card>
                  <CardHeader>
                    <CardTitle>About</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-600 leading-relaxed">
                      {influencer.bio || "No bio available."}
                    </p>

                    {influencer.location && (
                      <div className="flex items-center mt-4 text-sm text-gray-500">
                        <MapPin className="h-4 w-4 mr-2" />
                        {influencer.location.city && influencer.location.country
                          ? `${influencer.location.city}, ${influencer.location.country}`
                          : influencer.location.city ||
                            influencer.location.country ||
                            "Location not specified"}
                      </div>
                    )}

                    <div className="flex items-center mt-2 text-sm text-gray-500">
                      <Calendar className="h-4 w-4 mr-2" />
                      Joined{" "}
                      {new Date(influencer.createdAt).toLocaleDateString(
                        "en-US",
                        {
                          year: "numeric",
                          month: "long",
                          day: "numeric",
                        }
                      )}
                    </div>
                  </CardContent>
                </Card>

                {/* Categories */}
                <Card>
                  <CardHeader>
                    <CardTitle>Content Categories</CardTitle>
                  </CardHeader>
                  <CardContent>
                    {influencer.categories &&
                    influencer.categories.length > 0 ? (
                      <div className="flex flex-wrap gap-2">
                        {influencer.categories.map((category, index) => (
                          <Badge
                            key={index}
                            variant="secondary"
                            className="capitalize"
                          >
                            {category}
                          </Badge>
                        ))}
                      </div>
                    ) : (
                      <p className="text-gray-500">No categories specified</p>
                    )}

                    {influencer.tags && influencer.tags.length > 0 && (
                      <div className="mt-4">
                        <h5 className="text-sm font-medium text-gray-700 mb-2">
                          Tags
                        </h5>
                        <div className="flex flex-wrap gap-1">
                          {influencer.tags.slice(0, 10).map((tag, index) => (
                            <Badge
                              key={index}
                              variant="outline"
                              className="text-xs"
                            >
                              #{tag}
                            </Badge>
                          ))}
                          {influencer.tags.length > 10 && (
                            <Badge variant="outline" className="text-xs">
                              +{influencer.tags.length - 10} more
                            </Badge>
                          )}
                        </div>
                      </div>
                    )}

                    {/* Show AI tags if manual tags are empty */}
                    {(!influencer.tags || influencer.tags.length === 0) &&
                      influencer.aiSummary?.tags &&
                      influencer.aiSummary.tags.length > 0 && (
                        <div className="mt-4">
                          <h5 className="text-sm font-medium text-gray-700 mb-2">
                            AI-Generated Tags
                          </h5>
                          <div className="flex flex-wrap gap-1">
                            {influencer.aiSummary.tags
                              .slice(0, 10)
                              .map((tag, index) => (
                                <Badge
                                  key={index}
                                  variant="outline"
                                  className="text-xs bg-blue-50 text-blue-700"
                                >
                                  #{tag}
                                </Badge>
                              ))}
                            {influencer.aiSummary.tags.length > 10 && (
                              <Badge
                                variant="outline"
                                className="text-xs bg-blue-50 text-blue-700"
                              >
                                +{influencer.aiSummary.tags.length - 10} more
                              </Badge>
                            )}
                          </div>
                        </div>
                      )}
                  </CardContent>
                </Card>
              </div>

              {/* Languages & Content Types - New Section */}
              <div className="grid md:grid-cols-2 gap-6">
                {/* Languages */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <Languages className="h-5 w-5 mr-2" />
                      Languages
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    {influencer.languages && influencer.languages.length > 0 ? (
                      <div className="flex flex-wrap gap-2">
                        {influencer.languages.map((language, index) => (
                          <Badge
                            key={index}
                            variant="secondary"
                            className="capitalize"
                          >
                            {language}
                          </Badge>
                        ))}
                      </div>
                    ) : (
                      <p className="text-gray-500">No languages specified</p>
                    )}
                  </CardContent>
                </Card>

                {/* Content Types */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <Palette className="h-5 w-5 mr-2" />
                      Content Types
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    {influencer.contentTypes &&
                    influencer.contentTypes.length > 0 ? (
                      <div className="flex flex-wrap gap-2">
                        {influencer.contentTypes.map((type, index) => (
                          <Badge
                            key={index}
                            variant="outline"
                            className="capitalize"
                          >
                            {type}
                          </Badge>
                        ))}
                      </div>
                    ) : influencer.aiSummary?.contentTypes &&
                      influencer.aiSummary.contentTypes.length > 0 ? (
                      <div>
                        <div className="flex flex-wrap gap-2 mb-2">
                          {influencer.aiSummary.contentTypes.map(
                            (type, index) => (
                              <Badge
                                key={index}
                                variant="secondary"
                                className="capitalize bg-blue-50 text-blue-700"
                              >
                                {type}
                              </Badge>
                            )
                          )}
                        </div>
                        <p className="text-xs text-blue-600">
                          AI-detected content types
                        </p>
                      </div>
                    ) : (
                      <p className="text-gray-500">
                        No content types specified
                      </p>
                    )}
                  </CardContent>
                </Card>
              </div>

              {/* Collaboration Types */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Handshake className="h-5 w-5 mr-2" />
                    Collaboration Types
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {influencer.collaborationTypes &&
                  influencer.collaborationTypes.length > 0 ? (
                    <div className="flex flex-wrap gap-2">
                      {influencer.collaborationTypes.map((type, index) => (
                        <Badge
                          key={index}
                          variant="secondary"
                          className="capitalize"
                        >
                          {type}
                        </Badge>
                      ))}
                    </div>
                  ) : (
                    <p className="text-gray-500">
                      No collaboration types specified
                    </p>
                  )}
                </CardContent>
              </Card>

              {/* Brand Experience - Past & Excluded Brands */}
              {((influencer.pastBrands && influencer.pastBrands.length > 0) ||
                (influencer.excludedBrands &&
                  influencer.excludedBrands.length > 0)) && (
                <div className="grid md:grid-cols-2 gap-6">
                  {/* Past Brands */}
                  {influencer.pastBrands &&
                    influencer.pastBrands.length > 0 && (
                      <Card>
                        <CardHeader>
                          <CardTitle className="flex items-center">
                            <Award className="h-5 w-5 mr-2" />
                            Past Brand Collaborations
                          </CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-3">
                            {influencer.pastBrands
                              .slice(0, 6)
                              .map((brand, index) => (
                                <div
                                  key={index}
                                  className="flex items-center justify-between p-3 bg-green-50 rounded-lg border border-green-200"
                                >
                                  <div>
                                    <h5 className="font-medium text-green-800">
                                      {brand.name}
                                    </h5>
                                    <p className="text-sm text-green-600">
                                      {brand.category}
                                    </p>
                                    <p className="text-xs text-green-500 capitalize">
                                      {brand.collaborationType.replace(
                                        "-",
                                        " "
                                      )}
                                    </p>
                                  </div>
                                  <div className="text-right">
                                    <Badge
                                      variant="outline"
                                      className="bg-white"
                                    >
                                      {brand.year}
                                    </Badge>
                                  </div>
                                </div>
                              ))}
                          </div>
                          {influencer.pastBrands.length > 6 && (
                            <div className="text-center mt-4">
                              <p className="text-sm text-gray-500">
                                +{influencer.pastBrands.length - 6} more
                                collaborations
                              </p>
                            </div>
                          )}
                        </CardContent>
                      </Card>
                    )}

                  {/* Excluded Brands */}
                  {influencer.excludedBrands &&
                    influencer.excludedBrands.length > 0 && (
                      <Card>
                        <CardHeader>
                          <CardTitle>Brand Exclusions</CardTitle>
                          <CardDescription>
                            Brands this influencer prefers not to work with
                          </CardDescription>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-3">
                            {influencer.excludedBrands
                              .slice(0, 4)
                              .map((brand, index) => (
                                <div
                                  key={index}
                                  className="p-3 bg-red-50 rounded-lg border border-red-200"
                                >
                                  <h5 className="font-medium text-red-800 mb-1">
                                    {brand.name}
                                  </h5>
                                  <p className="text-sm text-red-600">
                                    Reason: {brand.reason}
                                  </p>
                                </div>
                              ))}
                          </div>
                          {influencer.excludedBrands.length > 4 && (
                            <div className="text-center mt-4">
                              <p className="text-sm text-gray-500">
                                +{influencer.excludedBrands.length - 4} more
                                exclusions
                              </p>
                            </div>
                          )}
                        </CardContent>
                      </Card>
                    )}
                </div>
              )}

              {/* Portfolio Section */}
              {influencer.portfolio && influencer.portfolio.length > 0 && (
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <Briefcase className="h-5 w-5 mr-2" />
                      Portfolio
                    </CardTitle>
                    <CardDescription>
                      Showcase of previous work and content
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                      {influencer.portfolio.slice(0, 6).map((item, index) => (
                        <div
                          key={index}
                          className="border rounded-lg overflow-hidden hover:shadow-md transition-shadow"
                        >
                          <div className="aspect-video bg-gray-100 flex items-center justify-center">
                            {item.imageUrl && (
                              <Image className="h-8 w-8 text-gray-400" />
                            )}
                            {item.videoUrl && (
                              <Video className="h-8 w-8 text-gray-400" />
                            )}
                            {!item.imageUrl && !item.videoUrl && (
                              <Link className="h-8 w-8 text-gray-400" />
                            )}
                          </div>
                          <div className="p-3">
                            {item.title && (
                              <h4 className="font-medium text-sm mb-1 line-clamp-1">
                                {item.title}
                              </h4>
                            )}
                            {item.description && (
                              <p className="text-xs text-gray-600 mb-2 line-clamp-2">
                                {item.description}
                              </p>
                            )}
                            {item.metrics && (
                              <div className="flex items-center gap-3 text-xs text-gray-500 mb-2">
                                {item.metrics.views && (
                                  <div className="flex items-center gap-1">
                                    <Eye className="h-3 w-3" />
                                    {formatFollowers(item.metrics.views)}
                                  </div>
                                )}
                                {item.metrics.likes && (
                                  <div className="flex items-center gap-1">
                                    <Heart className="h-3 w-3" />
                                    {formatFollowers(item.metrics.likes)}
                                  </div>
                                )}
                                {item.metrics.comments && (
                                  <div className="flex items-center gap-1">
                                    <MessageCircle className="h-3 w-3" />
                                    {formatFollowers(item.metrics.comments)}
                                  </div>
                                )}
                              </div>
                            )}

                            {/* Additional portfolio metadata */}
                            <div className="space-y-1 mb-2">
                              {item.brandName && (
                                <div className="flex items-center gap-1">
                                  <Badge variant="outline" className="text-xs">
                                    {item.brandName}
                                  </Badge>
                                </div>
                              )}

                              {item.campaignType && (
                                <div className="flex items-center gap-1">
                                  <Tag className="h-3 w-3 text-gray-400" />
                                  <span className="text-xs text-gray-500 capitalize">
                                    {item.campaignType.replace("-", " ")}
                                  </span>
                                </div>
                              )}

                              {item.platform && (
                                <div className="flex items-center gap-1">
                                  {getPlatformIcon(item.platform)}
                                  <span className="text-xs text-gray-500 capitalize">
                                    {item.platform}
                                  </span>
                                </div>
                              )}

                              {item.date && (
                                <div className="flex items-center gap-1">
                                  <Calendar className="h-3 w-3 text-gray-400" />
                                  <span className="text-xs text-gray-500">
                                    {new Date(item.date).toLocaleDateString(
                                      "en-US",
                                      {
                                        year: "numeric",
                                        month: "short",
                                      }
                                    )}
                                  </span>
                                </div>
                              )}
                            </div>
                            <a
                              href={item.imageUrl || item.videoUrl || "#"}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-xs text-blue-600 hover:underline mt-2 inline-block"
                            >
                              View Content →
                            </a>
                          </div>
                        </div>
                      ))}
                    </div>
                    {influencer.portfolio.length > 6 && (
                      <div className="text-center mt-4">
                        <p className="text-sm text-gray-500">
                          +{influencer.portfolio.length - 6} more portfolio
                          items
                        </p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              )}

              {/* Demographics */}
              {influencer.demographics && (
                <Card>
                  <CardHeader>
                    <CardTitle>Demographics & Audience</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid md:grid-cols-3 gap-6">
                      {influencer.demographics.ageGroup && (
                        <div>
                          <h5 className="font-medium text-gray-700 mb-2">
                            Age Group
                          </h5>
                          <Badge variant="secondary">
                            {influencer.demographics.ageGroup}
                          </Badge>
                        </div>
                      )}

                      {influencer.demographics.gender && (
                        <div>
                          <h5 className="font-medium text-gray-700 mb-2">
                            Gender
                          </h5>
                          <Badge variant="secondary" className="capitalize">
                            {influencer.demographics.gender}
                          </Badge>
                        </div>
                      )}

                      {influencer.demographics.primaryAudience && (
                        <div>
                          <h5 className="font-medium text-gray-700 mb-2">
                            Primary Audience
                          </h5>
                          <div className="space-y-1">
                            {influencer.demographics.primaryAudience
                              .ageGroup && (
                              <Badge variant="outline" className="mr-2">
                                Age:{" "}
                                {
                                  influencer.demographics.primaryAudience
                                    .ageGroup
                                }
                              </Badge>
                            )}
                            {influencer.demographics.primaryAudience.gender && (
                              <Badge variant="outline" className="capitalize">
                                {influencer.demographics.primaryAudience.gender}
                              </Badge>
                            )}
                          </div>
                        </div>
                      )}
                    </div>

                    {influencer.demographics.primaryAudience?.locations && (
                      <div className="mt-4">
                        <h5 className="font-medium text-gray-700 mb-2">
                          Audience Locations
                        </h5>
                        <div className="flex flex-wrap gap-2">
                          {influencer.demographics.primaryAudience.locations.map(
                            (location, index) => (
                              <Badge key={index} variant="outline">
                                {location}
                              </Badge>
                            )
                          )}
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              )}

              {/* Performance Metrics - Only show if data exists */}
              {influencer.performanceMetrics &&
                (influencer.performanceMetrics.averageViewsPerPost ||
                  influencer.performanceMetrics.averageLikesPerPost ||
                  influencer.performanceMetrics.averageCommentsPerPost ||
                  influencer.performanceMetrics.averageSharesPerPost ||
                  influencer.performanceMetrics.bestPerformingContentType ||
                  (influencer.performanceMetrics.peakEngagementHours &&
                    influencer.performanceMetrics.peakEngagementHours.length >
                      0)) && (
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center">
                        <TrendingUp className="h-5 w-5 mr-2" />
                        Performance Metrics
                      </CardTitle>
                      <CardDescription>
                        Average engagement and performance data
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                        {influencer.performanceMetrics.averageViewsPerPost && (
                          <div className="text-center p-3 bg-blue-50 rounded-lg">
                            <Eye className="h-5 w-5 text-blue-600 mx-auto mb-1" />
                            <p className="text-xs text-gray-600">Avg. Views</p>
                            <p className="font-bold text-blue-600">
                              {formatFollowers(
                                influencer.performanceMetrics
                                  .averageViewsPerPost
                              )}
                            </p>
                          </div>
                        )}

                        {influencer.performanceMetrics.averageLikesPerPost && (
                          <div className="text-center p-3 bg-pink-50 rounded-lg">
                            <Heart className="h-5 w-5 text-pink-600 mx-auto mb-1" />
                            <p className="text-xs text-gray-600">Avg. Likes</p>
                            <p className="font-bold text-pink-600">
                              {formatFollowers(
                                influencer.performanceMetrics
                                  .averageLikesPerPost
                              )}
                            </p>
                          </div>
                        )}

                        {influencer.performanceMetrics
                          .averageCommentsPerPost && (
                          <div className="text-center p-3 bg-green-50 rounded-lg">
                            <MessageCircle className="h-5 w-5 text-green-600 mx-auto mb-1" />
                            <p className="text-xs text-gray-600">
                              Avg. Comments
                            </p>
                            <p className="font-bold text-green-600">
                              {formatFollowers(
                                influencer.performanceMetrics
                                  .averageCommentsPerPost
                              )}
                            </p>
                          </div>
                        )}

                        {influencer.performanceMetrics.averageSharesPerPost && (
                          <div className="text-center p-3 bg-purple-50 rounded-lg">
                            <TrendingUp className="h-5 w-5 text-purple-600 mx-auto mb-1" />
                            <p className="text-xs text-gray-600">Avg. Shares</p>
                            <p className="font-bold text-purple-600">
                              {formatFollowers(
                                influencer.performanceMetrics
                                  .averageSharesPerPost
                              )}
                            </p>
                          </div>
                        )}
                      </div>

                      {influencer.performanceMetrics
                        .bestPerformingContentType && (
                        <div className="mt-4 text-center">
                          <Badge
                            variant="secondary"
                            className="bg-yellow-50 text-yellow-800"
                          >
                            Best Content:{" "}
                            {
                              influencer.performanceMetrics
                                .bestPerformingContentType
                            }
                          </Badge>
                        </div>
                      )}

                      {influencer.performanceMetrics.peakEngagementHours &&
                        influencer.performanceMetrics.peakEngagementHours
                          .length > 0 && (
                          <div className="mt-4">
                            <h5 className="text-sm font-medium text-gray-700 mb-2">
                              Peak Engagement Hours
                            </h5>
                            <div className="flex flex-wrap gap-2">
                              {influencer.performanceMetrics.peakEngagementHours.map(
                                (hour, index) => (
                                  <Badge
                                    key={index}
                                    variant="outline"
                                    className="text-xs"
                                  >
                                    {hour}
                                  </Badge>
                                )
                              )}
                            </div>
                          </div>
                        )}
                    </CardContent>
                  </Card>
                )}

              {/* Content Style & Personality - Only show if data exists */}
              {((influencer.contentStyle &&
                (influencer.contentStyle.visualAesthetic ||
                  influencer.contentStyle.toneOfVoice ||
                  influencer.contentStyle.contentFrequency)) ||
                (influencer.personalityTraits &&
                  Object.keys(influencer.personalityTraits).length > 0)) && (
                <div className="grid md:grid-cols-2 gap-6">
                  {/* Content Style - Only show if has actual data */}
                  {influencer.contentStyle &&
                    (influencer.contentStyle.visualAesthetic ||
                      influencer.contentStyle.toneOfVoice ||
                      influencer.contentStyle.contentFrequency) && (
                      <Card>
                        <CardHeader>
                          <CardTitle className="flex items-center">
                            <Palette className="h-5 w-5 mr-2" />
                            Content Style
                          </CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-3">
                          {influencer.contentStyle.visualAesthetic && (
                            <div>
                              <span className="text-sm text-gray-600">
                                Visual Style:
                              </span>
                              <Badge
                                variant="secondary"
                                className="ml-2 capitalize"
                              >
                                {influencer.contentStyle.visualAesthetic.replace(
                                  "-",
                                  " "
                                )}
                              </Badge>
                            </div>
                          )}

                          {influencer.contentStyle.toneOfVoice && (
                            <div>
                              <span className="text-sm text-gray-600">
                                Tone:
                              </span>
                              <Badge
                                variant="secondary"
                                className="ml-2 capitalize"
                              >
                                {influencer.contentStyle.toneOfVoice.replace(
                                  "-",
                                  " "
                                )}
                              </Badge>
                            </div>
                          )}

                          {influencer.contentStyle.contentFrequency && (
                            <div>
                              <span className="text-sm text-gray-600">
                                Posting Frequency:
                              </span>
                              <Badge
                                variant="outline"
                                className="ml-2 capitalize"
                              >
                                {influencer.contentStyle.contentFrequency.replace(
                                  "-",
                                  " "
                                )}
                              </Badge>
                            </div>
                          )}
                        </CardContent>
                      </Card>
                    )}

                  {/* Personality Traits - Only show if has actual data */}
                  {influencer.personalityTraits &&
                    Object.keys(influencer.personalityTraits).length > 0 && (
                      <Card>
                        <CardHeader>
                          <CardTitle className="flex items-center">
                            <Award className="h-5 w-5 mr-2" />
                            Personality Traits
                          </CardTitle>
                          <CardDescription>
                            Professional qualities and characteristics
                          </CardDescription>
                        </CardHeader>
                        <CardContent className="space-y-3">
                          {Object.entries(influencer.personalityTraits).map(
                            ([trait, score]) => (
                              <div
                                key={trait}
                                className="flex items-center justify-between"
                              >
                                <span className="text-sm text-gray-600 capitalize">
                                  {trait}:
                                </span>
                                <div className="flex items-center">
                                  <div className="w-20 bg-gray-200 rounded-full h-2 mr-2">
                                    <div
                                      className="bg-blue-600 h-2 rounded-full"
                                      style={{
                                        width: `${(score / 10) * 100}%`,
                                      }}
                                    ></div>
                                  </div>
                                  <span className="text-sm font-medium">
                                    {score}/10
                                  </span>
                                </div>
                              </div>
                            )
                          )}
                        </CardContent>
                      </Card>
                    )}
                </div>
              )}

              {/* Brand Affinities */}
              {influencer.brandAffinities &&
                influencer.brandAffinities.length > 0 && (
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center">
                        <Handshake className="h-5 w-5 mr-2" />
                        Brand Affinities
                      </CardTitle>
                      <CardDescription>
                        Brands and categories this influencer aligns with
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                        {influencer.brandAffinities
                          .slice(0, 9)
                          .map((affinity, index) => (
                            <div key={index} className="p-3 border rounded-lg">
                              <div className="flex items-center justify-between mb-2">
                                <h5 className="font-medium text-sm">
                                  {affinity.brand}
                                </h5>
                                <Badge variant="outline" className="text-xs">
                                  {affinity.score}/10
                                </Badge>
                              </div>
                              <p className="text-xs text-gray-600 mb-1">
                                {affinity.category}
                              </p>
                              <p className="text-xs text-gray-500 capitalize">
                                {affinity.collaborationType.replace("-", " ")}
                              </p>
                              <p className="text-xs text-gray-400">
                                {new Date(affinity.date).toLocaleDateString()}
                              </p>
                            </div>
                          ))}
                      </div>
                      {influencer.brandAffinities.length > 9 && (
                        <div className="text-center mt-4">
                          <p className="text-sm text-gray-500">
                            +{influencer.brandAffinities.length - 9} more brand
                            affinities
                          </p>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                )}
            </TabsContent>

            <TabsContent value="platforms" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Social Media Platforms</CardTitle>
                  <CardDescription>
                    Follower counts and engagement rates across platforms
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {influencer.socialPlatforms &&
                  influencer.socialPlatforms.length > 0 ? (
                    <div className="grid md:grid-cols-2 gap-4">
                      {influencer.socialPlatforms.map((platform, index) => (
                        <div
                          key={index}
                          className="flex items-center justify-between p-4 bg-gradient-to-r from-gray-50 to-gray-100 rounded-lg border"
                        >
                          <div className="flex items-center space-x-3">
                            {getPlatformIcon(platform.platform)}
                            <div>
                              <p className="font-medium capitalize">
                                {platform.platform}
                              </p>
                              <p className="text-sm text-gray-600">
                                @{platform.username}
                              </p>
                              {platform.profileUrl && (
                                <a
                                  href={platform.profileUrl}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="text-xs text-blue-600 hover:underline"
                                >
                                  View Profile
                                </a>
                              )}
                            </div>
                          </div>
                          <div className="text-right">
                            <p className="font-bold text-lg">
                              {formatFollowers(platform.followerCount || 0)}
                            </p>
                            <p className="text-sm text-gray-600">followers</p>
                            {platform.engagementRate !== undefined && (
                              <p className="text-sm font-medium text-green-600">
                                {platform.engagementRate}% engagement
                              </p>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-gray-500 text-center py-8">
                      No social media platforms connected
                    </p>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="pricing" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <DollarSign className="h-5 w-5 mr-2" />
                    Pricing Information
                  </CardTitle>
                  <CardDescription>
                    Standard rates for different types of content
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {influencer.pricing ? (
                    <div className="space-y-6">
                      {/* Standard Pricing - Only show prices that exist */}
                      {influencer.pricing.postPrice ||
                      influencer.pricing.storyPrice ||
                      influencer.pricing.videoPrice ||
                      influencer.pricing.reelPrice ? (
                        <div className="grid md:grid-cols-3 gap-4">
                          {influencer.pricing.postPrice && (
                            <div className="p-4 bg-blue-50 rounded-lg text-center">
                              <h4 className="font-semibold text-blue-900">
                                Post
                              </h4>
                              <p className="text-2xl font-bold text-blue-600">
                                ${influencer.pricing.postPrice}
                              </p>
                              <p className="text-sm text-blue-700">per post</p>
                            </div>
                          )}

                          {influencer.pricing.storyPrice && (
                            <div className="p-4 bg-green-50 rounded-lg text-center">
                              <h4 className="font-semibold text-green-900">
                                Story
                              </h4>
                              <p className="text-2xl font-bold text-green-600">
                                ${influencer.pricing.storyPrice}
                              </p>
                              <p className="text-sm text-green-700">
                                per story
                              </p>
                            </div>
                          )}

                          {influencer.pricing.videoPrice && (
                            <div className="p-4 bg-purple-50 rounded-lg text-center">
                              <h4 className="font-semibold text-purple-900">
                                Video
                              </h4>
                              <p className="text-2xl font-bold text-purple-600">
                                ${influencer.pricing.videoPrice}
                              </p>
                              <p className="text-sm text-purple-700">
                                per video
                              </p>
                            </div>
                          )}

                          {influencer.pricing.reelPrice && (
                            <div className="p-4 bg-orange-50 rounded-lg text-center">
                              <h4 className="font-semibold text-orange-900">
                                Reel
                              </h4>
                              <p className="text-2xl font-bold text-orange-600">
                                ${influencer.pricing.reelPrice}
                              </p>
                              <p className="text-sm text-orange-700">
                                per reel
                              </p>
                            </div>
                          )}
                        </div>
                      ) : (
                        /* Custom Pricing Display - Show when no specific pricing is available */
                        <div className="relative overflow-hidden">
                          <div className="absolute inset-0 bg-gradient-to-br from-indigo-50 via-blue-50 to-purple-50 rounded-2xl"></div>
                          <div className="relative p-8 text-center">
                            <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-r from-indigo-500 to-purple-600 rounded-full mb-6">
                              <DollarSign className="h-8 w-8 text-white" />
                            </div>

                            <h3 className="text-2xl font-bold text-gray-900 mb-3">
                              Custom Pricing Model
                            </h3>

                            <p className="text-lg text-gray-600 mb-6 max-w-2xl mx-auto leading-relaxed">
                              This influencer uses a custom pricing approach
                              tailored to each project's unique requirements.
                              <span className="font-medium text-gray-800">
                                {" "}
                                Contact them directly
                              </span>{" "}
                              to discuss rates based on your specific campaign
                              needs, audience reach, and content deliverables.
                            </p>

                            <div className="flex flex-wrap justify-center items-center gap-4 mb-6">
                              {influencer.pricing.currency && (
                                <div className="flex items-center bg-white/80 backdrop-blur-sm px-4 py-2 rounded-full border border-indigo-200">
                                  <DollarSign className="h-4 w-4 text-indigo-600 mr-2" />
                                  <span className="text-sm font-medium text-gray-700">
                                    Quotes in{" "}
                                    {influencer.pricing.currency.toUpperCase()}
                                  </span>
                                </div>
                              )}

                              {influencer.pricing.negotiable !== undefined && (
                                <div
                                  className={`flex items-center px-4 py-2 rounded-full border ${
                                    influencer.pricing.negotiable
                                      ? "bg-green-100/80 border-green-200 text-green-800"
                                      : "bg-gray-100/80 border-gray-200 text-gray-800"
                                  }`}
                                >
                                  {influencer.pricing.negotiable ? (
                                    <>
                                      <CheckCircle className="h-4 w-4 mr-2" />
                                      <span className="text-sm font-medium">
                                        Flexible & Negotiable
                                      </span>
                                    </>
                                  ) : (
                                    <>
                                      <Clock className="h-4 w-4 mr-2" />
                                      <span className="text-sm font-medium">
                                        Fixed Rate Structure
                                      </span>
                                    </>
                                  )}
                                </div>
                              )}
                            </div>

                            <div className="bg-white/60 backdrop-blur-sm rounded-xl p-6 border border-white/50">
                              <h4 className="font-semibold text-gray-900 mb-3">
                                What to Include in Your Inquiry:
                              </h4>
                              <div className="grid md:grid-cols-2 gap-3 text-sm text-gray-600">
                                <div className="flex items-center">
                                  <div className="w-2 h-2 bg-indigo-500 rounded-full mr-3"></div>
                                  Campaign objectives & timeline
                                </div>
                                <div className="flex items-center">
                                  <div className="w-2 h-2 bg-indigo-500 rounded-full mr-3"></div>
                                  Content type & deliverables
                                </div>
                                <div className="flex items-center">
                                  <div className="w-2 h-2 bg-indigo-500 rounded-full mr-3"></div>
                                  Target audience & reach
                                </div>
                                <div className="flex items-center">
                                  <div className="w-2 h-2 bg-indigo-500 rounded-full mr-3"></div>
                                  Usage rights & exclusivity
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      )}

                      {/* Package Deals - Only show if they exist */}
                      {influencer.pricing.packageDeals &&
                        influencer.pricing.packageDeals.length > 0 && (
                          <div>
                            <h4 className="font-semibold mb-4">
                              Package Deals
                            </h4>
                            <div className="grid md:grid-cols-2 gap-4">
                              {influencer.pricing.packageDeals.map(
                                (deal, index) => (
                                  <div
                                    key={index}
                                    className="p-4 border rounded-lg"
                                  >
                                    <h5 className="font-semibold text-lg">
                                      {deal.name}
                                    </h5>
                                    <p className="text-gray-600 text-sm mb-2">
                                      {deal.description}
                                    </p>
                                    <p className="text-2xl font-bold text-green-600 mb-2">
                                      ${deal.price}
                                    </p>
                                    <div className="space-y-1">
                                      {deal.deliverables.map(
                                        (deliverable, idx) => (
                                          <div
                                            key={idx}
                                            className="flex items-center text-sm"
                                          >
                                            <CheckCircle className="h-3 w-3 text-green-500 mr-2" />
                                            {deliverable}
                                          </div>
                                        )
                                      )}
                                    </div>
                                  </div>
                                )
                              )}
                            </div>
                          </div>
                        )}

                      {/* Pricing Notes - Only show if currency or negotiable info exists */}
                      {(influencer.pricing.currency ||
                        influencer.pricing.negotiable !== undefined) && (
                        <div className="mt-6 pt-6 border-t">
                          <div className="flex flex-wrap items-center gap-4 text-sm text-gray-600">
                            {influencer.pricing.currency && (
                              <div className="flex items-center">
                                <DollarSign className="h-4 w-4 mr-1" />
                                Currency:{" "}
                                {influencer.pricing.currency.toUpperCase()}
                              </div>
                            )}

                            {influencer.pricing.negotiable !== undefined && (
                              <Badge
                                variant={
                                  influencer.pricing.negotiable
                                    ? "secondary"
                                    : "outline"
                                }
                                className={
                                  influencer.pricing.negotiable
                                    ? "bg-green-50 text-green-700"
                                    : ""
                                }
                              >
                                {influencer.pricing.negotiable
                                  ? "Negotiable"
                                  : "Fixed Pricing"}
                              </Badge>
                            )}
                          </div>
                        </div>
                      )}
                    </div>
                  ) : (
                    /* Show when no pricing object exists at all */
                    <div className="relative overflow-hidden">
                      <div className="absolute inset-0 bg-gradient-to-br from-gray-50 via-slate-50 to-gray-100 rounded-2xl"></div>
                      <div className="relative p-8 text-center">
                        <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-r from-gray-400 to-gray-600 rounded-full mb-6">
                          <DollarSign className="h-8 w-8 text-white" />
                        </div>

                        <h3 className="text-2xl font-bold text-gray-900 mb-3">
                          Pricing Information Unavailable
                        </h3>

                        <p className="text-lg text-gray-600 mb-6 max-w-xl mx-auto leading-relaxed">
                          This influencer hasn't set up their pricing structure
                          yet.
                          <span className="font-medium text-gray-800">
                            {" "}
                            Contact them directly
                          </span>{" "}
                          to discuss custom rates for your campaign.
                        </p>

                        <div className="bg-white/60 backdrop-blur-sm rounded-xl p-6 border border-white/50">
                          <Badge variant="outline" className="bg-white/80">
                            💬 Direct Contact Required
                          </Badge>
                        </div>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="details" className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                {/* Account Details */}
                <Card>
                  <CardHeader>
                    <CardTitle>Account Information</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-gray-600">Email:</span>
                      <span className="font-medium">{influencer.email}</span>
                    </div>

                    <div className="flex justify-between items-center">
                      <span className="text-gray-600">
                        Verification Status:
                      </span>
                      <Badge
                        className={
                          influencer.verificationStatus === "verified"
                            ? "bg-green-100 text-green-800"
                            : influencer.verificationStatus === "pending"
                            ? "bg-yellow-100 text-yellow-800"
                            : "bg-red-100 text-red-800"
                        }
                      >
                        {influencer.verificationStatus || "pending"}
                      </Badge>
                    </div>

                    <div className="flex justify-between items-center">
                      <span className="text-gray-600">Email Verified:</span>
                      <Badge
                        className={
                          influencer.isEmailVerified
                            ? "bg-green-100 text-green-800"
                            : "bg-red-100 text-red-800"
                        }
                      >
                        {influencer.isEmailVerified ? "Yes" : "No"}
                      </Badge>
                    </div>

                    <div className="flex justify-between items-center">
                      <span className="text-gray-600">Account Status:</span>
                      <Badge
                        className={
                          influencer.isActive
                            ? "bg-green-100 text-green-800"
                            : "bg-red-100 text-red-800"
                        }
                      >
                        {influencer.isActive ? "Active" : "Inactive"}
                      </Badge>
                    </div>

                    <div className="flex justify-between items-center">
                      <span className="text-gray-600">Member Since:</span>
                      <span className="font-medium">
                        {new Date(influencer.createdAt).toLocaleDateString(
                          "en-US",
                          {
                            year: "numeric",
                            month: "long",
                            day: "numeric",
                          }
                        )}
                      </span>
                    </div>

                    {influencer.updatedAt && (
                      <div className="flex justify-between items-center">
                        <span className="text-gray-600">Last Updated:</span>
                        <span className="font-medium">
                          {new Date(influencer.updatedAt).toLocaleDateString(
                            "en-US",
                            {
                              year: "numeric",
                              month: "long",
                              day: "numeric",
                            }
                          )}
                        </span>
                      </div>
                    )}
                  </CardContent>
                </Card>

                {/* Availability - Only show if availability data exists */}
                {influencer.availability &&
                  (influencer.availability.status ||
                    influencer.availability.nextAvailable) && (
                    <Card>
                      <CardHeader>
                        <CardTitle>Availability</CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-3">
                        {influencer.availability.status && (
                          <div className="flex justify-between items-center">
                            <span className="text-gray-600">
                              Current Status:
                            </span>
                            <Badge
                              className={getAvailabilityColor(
                                influencer.availability.status
                              )}
                            >
                              {influencer.availability.status}
                            </Badge>
                          </div>
                        )}

                        {influencer.availability.nextAvailable && (
                          <div className="flex justify-between items-center">
                            <span className="text-gray-600">
                              Next Available:
                            </span>
                            <span className="font-medium">
                              {new Date(
                                influencer.availability.nextAvailable
                              ).toLocaleDateString("en-US", {
                                year: "numeric",
                                month: "long",
                                day: "numeric",
                              })}
                            </span>
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  )}
              </div>
            </TabsContent>
          </Tabs>

          {/* Contact Button */}
          <Card>
            <CardContent className="pt-6">
              <div className="text-center">
                <Button
                  onClick={handleStartChat}
                  size="lg"
                  className="bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 px-8"
                >
                  <MessageCircle className="h-5 w-5 mr-2" />
                  Start Conversation
                </Button>
                <p className="text-sm text-gray-500 mt-2">
                  Get in touch to discuss collaboration opportunities
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default InfluencerProfile;
