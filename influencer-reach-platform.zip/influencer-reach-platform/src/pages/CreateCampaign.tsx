import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import {
  campaignService,
  CreateCampaignData,
} from "@/services/campaignService";
import brandService from "@/services/brandService";
import { useAuthStore } from "@/store/authStore";
import { toast } from "@/hooks/use-toast";
import {
  ArrowLeft,
  Plus,
  Trash2,
  Calendar,
  DollarSign,
  Users,
  Target,
  Mail,
  Phone,
  MessageCircle,
} from "lucide-react";

const CreateCampaign = () => {
  const { user, isAuthenticated } = useAuthStore();
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(false);
  const [hasBrandProfile, setHasBrandProfile] = useState<boolean | null>(null);
  const [currentStep, setCurrentStep] = useState(1);
  const totalSteps = 5;

  useEffect(() => {
    // Only check brand profile if user is authenticated
    if (user && isAuthenticated) {
      checkBrandProfile();
    }
  }, [user, isAuthenticated]);

  const checkBrandProfile = async () => {
    // Double-check authentication before making API calls
    if (!user || !isAuthenticated) {
      console.log("User not authenticated, skipping brand profile check");
      return;
    }

    try {
      await brandService.getMyProfile();
      setHasBrandProfile(true);
    } catch (error: any) {
      if (error.code === 401) {
        // Authentication error - redirect to login
        console.error("Authentication failed:", error);
        toast({
          title: "Authentication Required",
          description: "Please log in to access campaign creation.",
          variant: "destructive",
        });
        navigate("/auth");
        return;
      } else if (error.code === 404) {
        setHasBrandProfile(false);
        // Don't show the toast here, we'll show the contact admin message instead
      } else {
        console.error("Failed to check brand profile:", error);
        toast({
          title: "Error",
          description: "Failed to verify brand profile. Please try again.",
          variant: "destructive",
        });
        // Don't navigate away - let them see the contact admin message
      }
    }
  };

  const [formData, setFormData] = useState<CreateCampaignData>({
    title: "",
    description: "",
    category: "lifestyle",
    objectives: [],
    productInfo: {
      name: "",
      description: "",
      price: undefined,
      urls: [],
      images: [],
    },
    timeline: {
      applicationDeadline: "",
      campaignStart: "",
      campaignEnd: "",
      contentDeadline: "",
    },
    budget: {
      type: "negotiable",
      currency: "USD",
      paymentTerms: "",
    },
    requirements: {
      platforms: [],
      influencerTypes: [],
      followerRange: {
        min: undefined,
        max: undefined,
      },
      demographics: {
        ageGroups: [],
        genders: [],
      },
      engagementRate: {
        min: undefined,
        max: undefined,
      },
      languages: [],
      excludeCompetitors: false,
    },
    deliverables: [],
    visibility: "public",
    tags: [],
    attachments: [],
  });

  const [newDeliverable, setNewDeliverable] = useState({
    type: "post" as
      | "post"
      | "story"
      | "reel"
      | "video"
      | "article"
      | "review"
      | "unboxing"
      | "tutorial"
      | "other",
    platform: "instagram" as
      | "instagram"
      | "tiktok"
      | "youtube"
      | "twitter"
      | "facebook"
      | "linkedin"
      | "twitch"
      | "snapchat",
    quantity: 1,
    specifications: {
      duration: undefined as number | undefined,
      dimensions: "",
      hashtags: [] as string[],
      mentions: [] as string[],
      guidelines: "",
    },
  });

  // State for adding new tags
  const [newTag, setNewTag] = useState("");

  const categories = [
    "fashion",
    "beauty",
    "fitness",
    "food",
    "travel",
    "lifestyle",
    "technology",
    "gaming",
    "music",
    "art",
    "education",
    "brand",
    "health",
    "parenting",
    "pets",
    "sports",
    "entertainment",
    "comedy",
    "diy",
    "automotive",
    "home",
    "finance",
    "books",
    "photography",
    "other",
  ];

  const objectives = [
    "brand-awareness",
    "lead-generation",
    "sales-conversion",
    "engagement",
    "content-creation",
    "event-promotion",
    "product-launch",
    "app-downloads",
    "website-traffic",
    "social-media-growth",
  ];

  const platforms = [
    "instagram",
    "tiktok",
    "youtube",
    "twitter",
    "facebook",
    "linkedin",
    "twitch",
    "snapchat",
  ];

  const influencerTypes = ["nano", "micro", "macro", "mega"];

  const deliverableTypes = [
    "post",
    "story",
    "reel",
    "video",
    "article",
    "review",
    "unboxing",
    "tutorial",
    "other",
  ];

  const ageGroups = [
    "13-17",
    "18-24",
    "25-34",
    "35-44",
    "45-54",
    "55-64",
    "65+",
  ];

  const genders = ["male", "female", "mixed", "other"];

  const currencies = ["USD", "EUR", "GBP", "CAD", "AUD", "JPY", "INR"];

  const languages = [
    "English",
    "Spanish",
    "French",
    "German",
    "Italian",
    "Portuguese",
    "Chinese",
    "Japanese",
    "Korean",
    "Arabic",
    "Hindi",
    "Russian",
  ];

  const handleObjectiveChange = (objective: string, checked: boolean) => {
    setFormData((prev) => ({
      ...prev,
      objectives: checked
        ? [...(prev.objectives || []), objective as any]
        : (prev.objectives || []).filter((o) => o !== objective),
    }));
  };

  const handlePlatformChange = (platform: string, checked: boolean) => {
    setFormData((prev) => ({
      ...prev,
      requirements: {
        ...prev.requirements,
        platforms: checked
          ? [...(prev.requirements?.platforms || []), platform as any]
          : (prev.requirements?.platforms || []).filter((p) => p !== platform),
      },
    }));
  };

  const handleInfluencerTypeChange = (type: string, checked: boolean) => {
    setFormData((prev) => ({
      ...prev,
      requirements: {
        ...prev.requirements,
        influencerTypes: checked
          ? [...(prev.requirements?.influencerTypes || []), type as any]
          : (prev.requirements?.influencerTypes || []).filter(
              (t) => t !== type
            ),
      },
    }));
  };

  const handleAgeGroupChange = (ageGroup: string, checked: boolean) => {
    setFormData((prev) => ({
      ...prev,
      requirements: {
        ...prev.requirements,
        demographics: {
          ...prev.requirements?.demographics,
          ageGroups: checked
            ? [
                ...(prev.requirements?.demographics?.ageGroups || []),
                ageGroup as any,
              ]
            : (prev.requirements?.demographics?.ageGroups || []).filter(
                (ag) => ag !== ageGroup
              ),
        },
      },
    }));
  };

  const handleGenderChange = (gender: string, checked: boolean) => {
    setFormData((prev) => ({
      ...prev,
      requirements: {
        ...prev.requirements,
        demographics: {
          ...prev.requirements?.demographics,
          genders: checked
            ? [
                ...(prev.requirements?.demographics?.genders || []),
                gender as any,
              ]
            : (prev.requirements?.demographics?.genders || []).filter(
                (g) => g !== gender
              ),
        },
      },
    }));
  };

  const handleLanguageChange = (language: string, checked: boolean) => {
    setFormData((prev) => ({
      ...prev,
      requirements: {
        ...prev.requirements,
        languages: checked
          ? [...(prev.requirements?.languages || []), language]
          : (prev.requirements?.languages || []).filter((l) => l !== language),
      },
    }));
  };

  const addTag = () => {
    if (newTag.trim() && !(formData.tags || []).includes(newTag.trim())) {
      setFormData((prev) => ({
        ...prev,
        tags: [...(prev.tags || []), newTag.trim()],
      }));
      setNewTag("");
    }
  };

  const removeTag = (index: number) => {
    setFormData((prev) => ({
      ...prev,
      tags: (prev.tags || []).filter((_, i) => i !== index),
    }));
  };

  const addDeliverable = () => {
    if (newDeliverable.quantity > 0) {
      setFormData((prev) => ({
        ...prev,
        deliverables: [...(prev.deliverables || []), { ...newDeliverable }],
      }));
      setNewDeliverable({
        type: "post",
        platform: "instagram",
        quantity: 1,
        specifications: {
          duration: undefined,
          dimensions: "",
          hashtags: [],
          mentions: [],
          guidelines: "",
        },
      });
    }
  };

  const removeDeliverable = (index: number) => {
    setFormData((prev) => ({
      ...prev,
      deliverables: (prev.deliverables || []).filter((_, i) => i !== index),
    }));
  };

  const handleSubmit = async () => {
    // Final validation before submit
    const allErrors: string[] = [];

    // Validate all steps
    for (let step = 1; step <= 2; step++) {
      const stepErrors = getValidationErrors(step);
      allErrors.push(...stepErrors);
    }

    if (allErrors.length > 0) {
      toast({
        title: "Please fix the following errors before submitting:",
        description: allErrors.join("; "),
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);
    try {
      await campaignService.createCampaign(formData);
      toast({
        title: "Campaign created!",
        description: "Your campaign has been successfully created.",
      });
      navigate("/campaigns");
    } catch (error: any) {
      console.error("Failed to create campaign:", error);
      toast({
        title: "Error",
        description:
          error.message || "Failed to create campaign. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const validateStep = (step: number): boolean => {
    switch (step) {
      case 1:
        // Title is required (max 200 chars), description is required (max 3000 chars), category is required
        return !!(
          formData.title &&
          formData.title.length <= 200 &&
          formData.description &&
          formData.description.length <= 3000 &&
          formData.category
        );
      case 2:
        // Timeline fields are required
        return !!(
          formData.timeline.applicationDeadline &&
          formData.timeline.campaignStart &&
          formData.timeline.campaignEnd &&
          // Validate that dates are in correct order
          new Date(formData.timeline.applicationDeadline) <
            new Date(formData.timeline.campaignStart) &&
          new Date(formData.timeline.campaignStart) <
            new Date(formData.timeline.campaignEnd)
        );
      case 3:
        return true; // Requirements are optional
      case 4:
        return true; // Product info and deliverables are optional
      case 5:
        return true; // Review step
      default:
        return false;
    }
  };

  const getValidationErrors = (step: number): string[] => {
    const errors: string[] = [];

    switch (step) {
      case 1:
        if (!formData.title) errors.push("Campaign title is required");
        else if (formData.title.length > 200)
          errors.push("Campaign title must be 200 characters or less");

        if (!formData.description)
          errors.push("Campaign description is required");
        else if (formData.description.length > 3000)
          errors.push("Campaign description must be 3000 characters or less");

        if (!formData.category) errors.push("Campaign category is required");
        break;

      case 2:
        if (!formData.timeline.applicationDeadline)
          errors.push("Application deadline is required");
        if (!formData.timeline.campaignStart)
          errors.push("Campaign start date is required");
        if (!formData.timeline.campaignEnd)
          errors.push("Campaign end date is required");

        if (
          formData.timeline.applicationDeadline &&
          formData.timeline.campaignStart &&
          new Date(formData.timeline.applicationDeadline) >=
            new Date(formData.timeline.campaignStart)
        ) {
          errors.push(
            "Application deadline must be before campaign start date"
          );
        }

        if (
          formData.timeline.campaignStart &&
          formData.timeline.campaignEnd &&
          new Date(formData.timeline.campaignStart) >=
            new Date(formData.timeline.campaignEnd)
        ) {
          errors.push("Campaign start date must be before campaign end date");
        }
        break;
    }

    return errors;
  };

  const nextStep = () => {
    const errors = getValidationErrors(currentStep);

    if (errors.length > 0) {
      toast({
        title: "Please fix the following errors:",
        description: errors.join("; "),
        variant: "destructive",
      });
      return;
    }

    if (validateStep(currentStep) && currentStep < totalSteps) {
      setCurrentStep(currentStep + 1);
    }
  };

  const prevStep = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const renderStepContent = () => {
    switch (currentStep) {
      case 1:
        return (
          <div className="space-y-6">
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
              <h3 className="font-medium text-blue-900 mb-2">
                Step 1: Basic Campaign Information
              </h3>
              <p className="text-blue-700 text-sm">
                Provide the essential details about your campaign. All fields
                marked with * are required.
              </p>
            </div>

            <div>
              <Label htmlFor="title">Campaign Title *</Label>
              <Input
                id="title"
                placeholder="e.g., Summer Fashion Collection Launch"
                value={formData.title}
                onChange={(e) =>
                  setFormData((prev) => ({ ...prev, title: e.target.value }))
                }
                className={`mt-1 ${
                  formData.title.length > 200 ? "border-red-500" : ""
                }`}
                maxLength={200}
              />
              <div className="flex justify-between text-xs text-gray-500 mt-1">
                <span>Required field</span>
                <span
                  className={formData.title.length > 200 ? "text-red-500" : ""}
                >
                  {formData.title.length}/200
                </span>
              </div>
            </div>

            <div>
              <Label htmlFor="description">Description *</Label>
              <Textarea
                id="description"
                placeholder="Describe your campaign goals, brand values, and what you're looking for..."
                value={formData.description}
                onChange={(e) =>
                  setFormData((prev) => ({
                    ...prev,
                    description: e.target.value,
                  }))
                }
                rows={4}
                className={`mt-1 ${
                  formData.description.length > 3000 ? "border-red-500" : ""
                }`}
                maxLength={3000}
              />
              <div className="flex justify-between text-xs text-gray-500 mt-1">
                <span>Required field</span>
                <span
                  className={
                    formData.description.length > 3000 ? "text-red-500" : ""
                  }
                >
                  {formData.description.length}/3000
                </span>
              </div>
            </div>

            <div>
              <Label htmlFor="category">Category *</Label>
              <Select
                value={formData.category}
                onValueChange={(value) =>
                  setFormData((prev) => ({ ...prev, category: value as any }))
                }
              >
                <SelectTrigger className="mt-1">
                  <SelectValue placeholder="Select a category" />
                </SelectTrigger>
                <SelectContent>
                  {categories.map((category) => (
                    <SelectItem key={category} value={category}>
                      {category.charAt(0).toUpperCase() + category.slice(1)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <div className="text-xs text-gray-500 mt-1">
                <span>Required field</span>
              </div>
            </div>

            <div>
              <Label>Campaign Objectives</Label>
              <div className="grid grid-cols-2 gap-2 mt-2">
                {objectives.map((objective) => (
                  <div key={objective} className="flex items-center space-x-2">
                    <Checkbox
                      id={objective}
                      checked={(formData.objectives || []).includes(
                        objective as any
                      )}
                      onCheckedChange={(checked) =>
                        handleObjectiveChange(objective, checked as boolean)
                      }
                    />
                    <Label htmlFor={objective} className="text-sm">
                      {objective
                        .split("-")
                        .map(
                          (word) => word.charAt(0).toUpperCase() + word.slice(1)
                        )
                        .join(" ")}
                    </Label>
                  </div>
                ))}
              </div>
            </div>

            <div>
              <Label>Tags</Label>
              <div className="space-y-2">
                <div className="flex flex-wrap gap-2">
                  {(formData.tags || []).map((tag, index) => (
                    <Badge
                      key={index}
                      variant="secondary"
                      className="cursor-pointer"
                      onClick={() => removeTag(index)}
                    >
                      {tag} ×
                    </Badge>
                  ))}
                </div>
                <div className="flex gap-2">
                  <Input
                    placeholder="Add a tag"
                    value={newTag}
                    onChange={(e) => setNewTag(e.target.value)}
                    onKeyPress={(e) => e.key === "Enter" && addTag()}
                  />
                  <Button type="button" variant="outline" onClick={addTag}>
                    <Plus className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </div>
          </div>
        );

      case 2:
        return (
          <div className="space-y-6">
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
              <h3 className="font-medium text-blue-900 mb-2">
                Step 2: Timeline & Budget
              </h3>
              <p className="text-blue-700 text-sm">
                Set your campaign dates and budget information. All timeline
                fields are required and must be in chronological order.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="applicationDeadline">
                  Application Deadline *
                </Label>
                <Input
                  id="applicationDeadline"
                  type="datetime-local"
                  value={formData.timeline.applicationDeadline}
                  onChange={(e) =>
                    setFormData((prev) => ({
                      ...prev,
                      timeline: {
                        ...prev.timeline,
                        applicationDeadline: e.target.value,
                      },
                    }))
                  }
                  className="mt-1"
                />
                <div className="text-xs text-gray-500 mt-1">
                  <span>Required field - Must be before campaign start</span>
                </div>
              </div>

              <div>
                <Label htmlFor="contentDeadline">Content Deadline</Label>
                <Input
                  id="contentDeadline"
                  type="datetime-local"
                  value={formData.timeline.contentDeadline || ""}
                  onChange={(e) =>
                    setFormData((prev) => ({
                      ...prev,
                      timeline: {
                        ...prev.timeline,
                        contentDeadline: e.target.value,
                      },
                    }))
                  }
                  className="mt-1"
                />
                <div className="text-xs text-gray-500 mt-1">
                  <span>
                    Optional - When influencers should submit their content
                  </span>
                </div>
              </div>

              <div>
                <Label htmlFor="campaignStart">Campaign Start *</Label>
                <Input
                  id="campaignStart"
                  type="datetime-local"
                  value={formData.timeline.campaignStart}
                  onChange={(e) =>
                    setFormData((prev) => ({
                      ...prev,
                      timeline: {
                        ...prev.timeline,
                        campaignStart: e.target.value,
                      },
                    }))
                  }
                  className="mt-1"
                />
                <div className="text-xs text-gray-500 mt-1">
                  <span>
                    Required field - Must be after application deadline
                  </span>
                </div>
              </div>

              <div>
                <Label htmlFor="campaignEnd">Campaign End *</Label>
                <Input
                  id="campaignEnd"
                  type="datetime-local"
                  value={formData.timeline.campaignEnd}
                  onChange={(e) =>
                    setFormData((prev) => ({
                      ...prev,
                      timeline: {
                        ...prev.timeline,
                        campaignEnd: e.target.value,
                      },
                    }))
                  }
                  className="mt-1"
                />
                <div className="text-xs text-gray-500 mt-1">
                  <span>Required field - Must be after campaign start</span>
                </div>
              </div>
            </div>

            <div>
              <Label>Budget</Label>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mt-2">
                <div>
                  <Label htmlFor="budgetType">Budget Type</Label>
                  <Select
                    value={formData.budget?.type || "negotiable"}
                    onValueChange={(value) =>
                      setFormData((prev) => ({
                        ...prev,
                        budget: { ...prev.budget, type: value as any },
                      }))
                    }
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="fixed">Fixed</SelectItem>
                      <SelectItem value="negotiable">Negotiable</SelectItem>
                      <SelectItem value="performance">
                        Performance-based
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="currency">Currency</Label>
                  <Select
                    value={formData.budget?.currency || "USD"}
                    onValueChange={(value) =>
                      setFormData((prev) => ({
                        ...prev,
                        budget: { ...prev.budget, currency: value },
                      }))
                    }
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {currencies.map((currency) => (
                        <SelectItem key={currency} value={currency}>
                          {currency}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="minBudget">Minimum Budget</Label>
                  <Input
                    id="minBudget"
                    type="number"
                    placeholder="1000"
                    value={formData.budget?.amount?.min || ""}
                    onChange={(e) =>
                      setFormData((prev) => ({
                        ...prev,
                        budget: {
                          ...prev.budget,
                          amount: {
                            ...prev.budget?.amount,
                            min: e.target.value
                              ? parseInt(e.target.value)
                              : undefined,
                          },
                        },
                      }))
                    }
                  />
                </div>

                <div>
                  <Label htmlFor="maxBudget">Maximum Budget</Label>
                  <Input
                    id="maxBudget"
                    type="number"
                    placeholder="5000"
                    value={formData.budget?.amount?.max || ""}
                    onChange={(e) =>
                      setFormData((prev) => ({
                        ...prev,
                        budget: {
                          ...prev.budget,
                          amount: {
                            ...prev.budget?.amount,
                            max: e.target.value
                              ? parseInt(e.target.value)
                              : undefined,
                          },
                        },
                      }))
                    }
                  />
                </div>
              </div>

              <div className="mt-4">
                <Label htmlFor="paymentTerms">Payment Terms</Label>
                <Textarea
                  id="paymentTerms"
                  placeholder="e.g., 50% upfront, 50% upon completion"
                  value={formData.budget?.paymentTerms || ""}
                  onChange={(e) =>
                    setFormData((prev) => ({
                      ...prev,
                      budget: {
                        ...prev.budget,
                        paymentTerms: e.target.value,
                      },
                    }))
                  }
                  rows={2}
                  className="mt-1"
                />
              </div>
            </div>
          </div>
        );

      case 3:
        return (
          <div className="space-y-6">
            <div className="bg-green-50 border border-green-200 rounded-lg p-4 mb-6">
              <h3 className="font-medium text-green-900 mb-2">
                Step 3: Target Requirements
              </h3>
              <p className="text-green-700 text-sm">
                Define your ideal influencer criteria. All fields in this step
                are optional but help us find better matches.
              </p>
            </div>

            <div>
              <Label>Target Platforms</Label>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-2 mt-2">
                {platforms.map((platform) => (
                  <div key={platform} className="flex items-center space-x-2">
                    <Checkbox
                      id={platform}
                      checked={(
                        formData.requirements?.platforms || []
                      ).includes(platform as any)}
                      onCheckedChange={(checked) =>
                        handlePlatformChange(platform, checked as boolean)
                      }
                    />
                    <Label htmlFor={platform} className="text-sm capitalize">
                      {platform}
                    </Label>
                  </div>
                ))}
              </div>
            </div>

            <div>
              <Label>Influencer Types</Label>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-2 mt-2">
                {influencerTypes.map((type) => (
                  <div key={type} className="flex items-center space-x-2">
                    <Checkbox
                      id={type}
                      checked={(
                        formData.requirements?.influencerTypes || []
                      ).includes(type as any)}
                      onCheckedChange={(checked) =>
                        handleInfluencerTypeChange(type, checked as boolean)
                      }
                    />
                    <Label htmlFor={type} className="text-sm capitalize">
                      {type}
                    </Label>
                  </div>
                ))}
              </div>
            </div>

            <div>
              <Label>Follower Range</Label>
              <div className="grid grid-cols-2 gap-4 mt-2">
                <div>
                  <Label htmlFor="minFollowers">Minimum Followers</Label>
                  <Input
                    id="minFollowers"
                    type="number"
                    placeholder="1000"
                    value={formData.requirements?.followerRange?.min || ""}
                    onChange={(e) =>
                      setFormData((prev) => ({
                        ...prev,
                        requirements: {
                          ...prev.requirements,
                          followerRange: {
                            ...prev.requirements?.followerRange,
                            min: e.target.value
                              ? parseInt(e.target.value)
                              : undefined,
                          },
                        },
                      }))
                    }
                  />
                </div>
                <div>
                  <Label htmlFor="maxFollowers">Maximum Followers</Label>
                  <Input
                    id="maxFollowers"
                    type="number"
                    placeholder="100000"
                    value={formData.requirements?.followerRange?.max || ""}
                    onChange={(e) =>
                      setFormData((prev) => ({
                        ...prev,
                        requirements: {
                          ...prev.requirements,
                          followerRange: {
                            ...prev.requirements?.followerRange,
                            max: e.target.value
                              ? parseInt(e.target.value)
                              : undefined,
                          },
                        },
                      }))
                    }
                  />
                </div>
              </div>
            </div>

            <div>
              <Label>Demographics</Label>
              <div className="space-y-4 mt-2">
                <div>
                  <Label className="text-sm font-medium">Age Groups</Label>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-2 mt-1">
                    {ageGroups.map((ageGroup) => (
                      <div
                        key={ageGroup}
                        className="flex items-center space-x-2"
                      >
                        <Checkbox
                          id={ageGroup}
                          checked={(
                            formData.requirements?.demographics?.ageGroups || []
                          ).includes(ageGroup as any)}
                          onCheckedChange={(checked) =>
                            handleAgeGroupChange(ageGroup, checked as boolean)
                          }
                        />
                        <Label htmlFor={ageGroup} className="text-sm">
                          {ageGroup}
                        </Label>
                      </div>
                    ))}
                  </div>
                </div>

                <div>
                  <Label className="text-sm font-medium">Genders</Label>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-2 mt-1">
                    {genders.map((gender) => (
                      <div key={gender} className="flex items-center space-x-2">
                        <Checkbox
                          id={gender}
                          checked={(
                            formData.requirements?.demographics?.genders || []
                          ).includes(gender as any)}
                          onCheckedChange={(checked) =>
                            handleGenderChange(gender, checked as boolean)
                          }
                        />
                        <Label htmlFor={gender} className="text-sm capitalize">
                          {gender}
                        </Label>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            <div>
              <Label>Engagement Rate (%)</Label>
              <div className="grid grid-cols-2 gap-4 mt-2">
                <div>
                  <Label htmlFor="minEngagement">Minimum Engagement</Label>
                  <Input
                    id="minEngagement"
                    type="number"
                    placeholder="1"
                    min="0"
                    max="100"
                    step="0.1"
                    value={formData.requirements?.engagementRate?.min || ""}
                    onChange={(e) =>
                      setFormData((prev) => ({
                        ...prev,
                        requirements: {
                          ...prev.requirements,
                          engagementRate: {
                            ...prev.requirements?.engagementRate,
                            min: e.target.value
                              ? parseFloat(e.target.value)
                              : undefined,
                          },
                        },
                      }))
                    }
                  />
                </div>
                <div>
                  <Label htmlFor="maxEngagement">Maximum Engagement</Label>
                  <Input
                    id="maxEngagement"
                    type="number"
                    placeholder="10"
                    min="0"
                    max="100"
                    step="0.1"
                    value={formData.requirements?.engagementRate?.max || ""}
                    onChange={(e) =>
                      setFormData((prev) => ({
                        ...prev,
                        requirements: {
                          ...prev.requirements,
                          engagementRate: {
                            ...prev.requirements?.engagementRate,
                            max: e.target.value
                              ? parseFloat(e.target.value)
                              : undefined,
                          },
                        },
                      }))
                    }
                  />
                </div>
              </div>
            </div>

            <div>
              <Label>Languages</Label>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-2 mt-2">
                {languages.map((language) => (
                  <div key={language} className="flex items-center space-x-2">
                    <Checkbox
                      id={language}
                      checked={(
                        formData.requirements?.languages || []
                      ).includes(language)}
                      onCheckedChange={(checked) =>
                        handleLanguageChange(language, checked as boolean)
                      }
                    />
                    <Label htmlFor={language} className="text-sm">
                      {language}
                    </Label>
                  </div>
                ))}
              </div>
            </div>

            <div className="flex items-center space-x-2">
              <Checkbox
                id="excludeCompetitors"
                checked={formData.requirements?.excludeCompetitors || false}
                onCheckedChange={(checked) =>
                  setFormData((prev) => ({
                    ...prev,
                    requirements: {
                      ...prev.requirements,
                      excludeCompetitors: checked as boolean,
                    },
                  }))
                }
              />
              <Label htmlFor="excludeCompetitors">
                Exclude influencers who work with competitors
              </Label>
            </div>
          </div>
        );

      case 4:
        return (
          <div className="space-y-6">
            <div className="bg-green-50 border border-green-200 rounded-lg p-4 mb-6">
              <h3 className="font-medium text-green-900 mb-2">
                Step 4: Product & Deliverables
              </h3>
              <p className="text-green-700 text-sm">
                Provide product details and specify what content you need. All
                fields are optional.
              </p>
            </div>

            <div>
              <Label>Product Information</Label>
              <div className="space-y-4 mt-2">
                <div>
                  <Label htmlFor="productName">Product Name</Label>
                  <Input
                    id="productName"
                    placeholder="e.g., Summer Collection 2024"
                    value={formData.productInfo?.name || ""}
                    onChange={(e) =>
                      setFormData((prev) => ({
                        ...prev,
                        productInfo: {
                          ...prev.productInfo,
                          name: e.target.value,
                        },
                      }))
                    }
                    className="mt-1"
                  />
                </div>

                <div>
                  <Label htmlFor="productDescription">
                    Product Description
                  </Label>
                  <Textarea
                    id="productDescription"
                    placeholder="Describe the product or service being promoted"
                    value={formData.productInfo?.description || ""}
                    onChange={(e) =>
                      setFormData((prev) => ({
                        ...prev,
                        productInfo: {
                          ...prev.productInfo,
                          description: e.target.value,
                        },
                      }))
                    }
                    rows={3}
                    className="mt-1"
                  />
                </div>

                <div>
                  <Label htmlFor="productPrice">Price</Label>
                  <Input
                    id="productPrice"
                    type="number"
                    placeholder="99.99"
                    value={formData.productInfo?.price || ""}
                    onChange={(e) =>
                      setFormData((prev) => ({
                        ...prev,
                        productInfo: {
                          ...prev.productInfo,
                          price: e.target.value
                            ? parseFloat(e.target.value)
                            : undefined,
                        },
                      }))
                    }
                    className="mt-1"
                  />
                </div>
              </div>
            </div>

            <div>
              <Label>Deliverables</Label>
              <div className="space-y-4 mt-2">
                {(formData.deliverables || []).map((deliverable, index) => (
                  <div
                    key={index}
                    className="flex items-center justify-between p-3 border rounded-lg"
                  >
                    <div>
                      <Badge variant="outline" className="mr-2">
                        {deliverable.quantity} {deliverable.type}(s)
                      </Badge>
                      <Badge variant="secondary">{deliverable.platform}</Badge>
                      {deliverable.specifications?.duration && (
                        <Badge variant="outline" className="ml-2">
                          {deliverable.specifications.duration}s
                        </Badge>
                      )}
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => removeDeliverable(index)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                ))}

                <div className="p-4 border-2 border-dashed border-gray-300 rounded-lg">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-3">
                    <Select
                      value={newDeliverable.type}
                      onValueChange={(value) =>
                        setNewDeliverable((prev) => ({
                          ...prev,
                          type: value as any,
                        }))
                      }
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {deliverableTypes.map((type) => (
                          <SelectItem key={type} value={type}>
                            {type.charAt(0).toUpperCase() + type.slice(1)}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>

                    <Select
                      value={newDeliverable.platform}
                      onValueChange={(value) =>
                        setNewDeliverable((prev) => ({
                          ...prev,
                          platform: value as any,
                        }))
                      }
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {platforms.map((platform) => (
                          <SelectItem key={platform} value={platform}>
                            {platform.charAt(0).toUpperCase() +
                              platform.slice(1)}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>

                    <Input
                      type="number"
                      min="1"
                      placeholder="Quantity"
                      value={newDeliverable.quantity}
                      onChange={(e) =>
                        setNewDeliverable((prev) => ({
                          ...prev,
                          quantity: parseInt(e.target.value) || 1,
                        }))
                      }
                    />

                    {(newDeliverable.type === "video" ||
                      newDeliverable.type === "reel") && (
                      <Input
                        type="number"
                        placeholder="Duration (seconds)"
                        value={newDeliverable.specifications.duration || ""}
                        onChange={(e) =>
                          setNewDeliverable((prev) => ({
                            ...prev,
                            specifications: {
                              ...prev.specifications,
                              duration: e.target.value
                                ? parseInt(e.target.value)
                                : undefined,
                            },
                          }))
                        }
                      />
                    )}
                  </div>

                  <div className="grid grid-cols-1 gap-3 mb-3">
                    <Input
                      placeholder="Dimensions (e.g., 1080x1080)"
                      value={newDeliverable.specifications.dimensions}
                      onChange={(e) =>
                        setNewDeliverable((prev) => ({
                          ...prev,
                          specifications: {
                            ...prev.specifications,
                            dimensions: e.target.value,
                          },
                        }))
                      }
                    />

                    <Textarea
                      placeholder="Guidelines and special requirements"
                      value={newDeliverable.specifications.guidelines}
                      onChange={(e) =>
                        setNewDeliverable((prev) => ({
                          ...prev,
                          specifications: {
                            ...prev.specifications,
                            guidelines: e.target.value,
                          },
                        }))
                      }
                      rows={2}
                    />
                  </div>

                  <Button
                    onClick={addDeliverable}
                    variant="outline"
                    className="w-full"
                  >
                    <Plus className="h-4 w-4 mr-1" />
                    Add Deliverable
                  </Button>
                </div>
              </div>
            </div>
          </div>
        );

      case 5:
        return (
          <div className="space-y-6">
            <div className="bg-purple-50 border border-purple-200 rounded-lg p-4 mb-6">
              <h3 className="font-medium text-purple-900 mb-2">
                Step 5: Review & Publish
              </h3>
              <p className="text-purple-700 text-sm">
                Review all your campaign details before publishing. Make sure
                everything looks correct.
              </p>
            </div>

            <div className="text-center mb-6">
              <h3 className="text-lg font-semibold">Review Your Campaign</h3>
              <p className="text-gray-600">
                Please review all details before publishing
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Target className="h-5 w-5 mr-2" />
                    Basic Information
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  <div>
                    <span className="font-medium">Title:</span> {formData.title}
                  </div>
                  <div>
                    <span className="font-medium">Category:</span>{" "}
                    {formData.category}
                  </div>
                  <div>
                    <span className="font-medium">Description:</span>
                    <p className="text-sm text-gray-600 mt-1">
                      {formData.description}
                    </p>
                  </div>
                  {formData.objectives && formData.objectives.length > 0 && (
                    <div>
                      <span className="font-medium">Objectives:</span>
                      <div className="flex flex-wrap gap-1 mt-1">
                        {formData.objectives.map((objective, index) => (
                          <Badge
                            key={index}
                            variant="secondary"
                            className="text-xs"
                          >
                            {objective.replace("-", " ")}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Calendar className="h-5 w-5 mr-2" />
                    Timeline & Budget
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  <div>
                    <span className="font-medium">Application Deadline:</span>
                    <br />
                    {new Date(
                      formData.timeline.applicationDeadline
                    ).toLocaleString()}
                  </div>
                  <div>
                    <span className="font-medium">Campaign Period:</span>
                    <br />
                    {new Date(
                      formData.timeline.campaignStart
                    ).toLocaleDateString()}{" "}
                    -{" "}
                    {new Date(
                      formData.timeline.campaignEnd
                    ).toLocaleDateString()}
                  </div>
                  <div>
                    <span className="font-medium">Budget:</span>{" "}
                    {formData.budget?.type || "Negotiable"}
                    {formData.budget?.amount?.min &&
                      ` (${formData.budget.currency || "USD"} ${
                        formData.budget.amount.min
                      }+)`}
                  </div>
                </CardContent>
              </Card>

              {formData.requirements && (
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <Users className="h-5 w-5 mr-2" />
                      Requirements
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    {formData.requirements.platforms &&
                      formData.requirements.platforms.length > 0 && (
                        <div>
                          <span className="font-medium">Platforms:</span>
                          <div className="flex flex-wrap gap-1 mt-1">
                            {formData.requirements.platforms.map(
                              (platform, index) => (
                                <Badge
                                  key={index}
                                  variant="outline"
                                  className="text-xs"
                                >
                                  {platform}
                                </Badge>
                              )
                            )}
                          </div>
                        </div>
                      )}
                    {formData.requirements.influencerTypes &&
                      formData.requirements.influencerTypes.length > 0 && (
                        <div>
                          <span className="font-medium">Influencer Types:</span>
                          <div className="flex flex-wrap gap-1 mt-1">
                            {formData.requirements.influencerTypes.map(
                              (type, index) => (
                                <Badge
                                  key={index}
                                  variant="outline"
                                  className="text-xs"
                                >
                                  {type}
                                </Badge>
                              )
                            )}
                          </div>
                        </div>
                      )}
                  </CardContent>
                </Card>
              )}

              {formData.deliverables && formData.deliverables.length > 0 && (
                <Card>
                  <CardHeader>
                    <CardTitle>Deliverables</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      {formData.deliverables.map((deliverable, index) => (
                        <div key={index} className="flex items-center gap-2">
                          <Badge variant="outline">
                            {deliverable.quantity} {deliverable.type}(s)
                          </Badge>
                          <Badge variant="secondary">
                            {deliverable.platform}
                          </Badge>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>

            <div>
              <Label>Visibility</Label>
              <Select
                value={formData.visibility || "public"}
                onValueChange={(value) =>
                  setFormData((prev) => ({ ...prev, visibility: value as any }))
                }
              >
                <SelectTrigger className="mt-1">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="public">
                    Public - Visible to all influencers
                  </SelectItem>
                  <SelectItem value="private">
                    Private - Only you can see it
                  </SelectItem>
                  <SelectItem value="invited-only">
                    Invited Only - Only invited influencers can see it
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  // Check authentication first
  if (!user || !isAuthenticated) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Verifying authentication...</p>
        </div>
      </div>
    );
  }

  // Don't render anything if we're still checking brand profile
  if (hasBrandProfile === null) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Checking brand profile...</p>
        </div>
      </div>
    );
  }

  // Show contact admin message if no brand profile exists
  if (hasBrandProfile === false) {
    return (
      <div className="min-h-screen bg-gray-50">
        <div className="container mx-auto px-4 py-8">
          <div className="flex items-center mb-8">
            <Button
              variant="outline"
              onClick={() => navigate("/brand")}
              className="mr-4"
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Dashboard
            </Button>
            <div>
              <h1 className="text-3xl font-bold text-gray-900">
                Create New Campaign
              </h1>
            </div>
          </div>

          <div className="max-w-2xl mx-auto">
            <Card>
              <CardHeader className="text-center">
                <CardTitle className="text-2xl">
                  Brand Profile Activation Required
                </CardTitle>
                <CardDescription>
                  Your brand account needs to be activated by an administrator
                  before you can create campaigns.
                </CardDescription>
              </CardHeader>
              <CardContent className="text-center space-y-6">
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
                  <div className="flex items-center justify-center mb-4">
                    <Mail className="h-12 w-12 text-blue-600" />
                  </div>
                  <h3 className="text-lg font-semibold text-blue-900 mb-2">
                    Contact Administrator for Activation
                  </h3>
                  <p className="text-blue-700 mb-4">
                    Please contact our admin team to activate your brand profile
                    and start creating campaigns.
                  </p>
                  <div className="space-y-3">
                    <div className="flex items-center justify-center text-blue-700">
                      <Mail className="h-4 w-4 mr-2" />
                      <span className="font-medium">
                        admin@influencermatch.com
                      </span>
                    </div>
                    <div className="flex items-center justify-center text-blue-700">
                      <Phone className="h-4 w-4 mr-2" />
                      <span className="font-medium">+1 (555) 123-4567</span>
                    </div>
                  </div>
                </div>
                <div className="flex gap-3 justify-center">
                  <Button
                    onClick={() =>
                      (window.location.href =
                        "mailto:admin@influencermatch.com?subject=Brand Profile Activation Request&body=Hello, I would like to activate my brand profile. My account email is: " +
                        encodeURIComponent(user?.email || ""))
                    }
                    className="bg-blue-600 hover:bg-blue-700"
                  >
                    <Mail className="h-4 w-4 mr-2" />
                    Send Email Request
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => navigate("/contact")}
                  >
                    <MessageCircle className="h-4 w-4 mr-2" />
                    Contact Form
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center mb-8">
          <Button
            variant="outline"
            onClick={() => navigate("/campaigns")}
            className="mr-4"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Campaigns
          </Button>
          <div>
            <h1 className="text-3xl font-bold text-gray-900">
              Create New Campaign
            </h1>
            <p className="text-gray-600">
              Step {currentStep} of {totalSteps}
            </p>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-2">
            {Array.from({ length: totalSteps }, (_, i) => i + 1).map((step) => {
              const isCompleted = step < currentStep;
              const isCurrent = step === currentStep;
              const isValid = validateStep(step);

              return (
                <div key={step} className="flex items-center">
                  <div
                    className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                      isCompleted
                        ? "bg-green-500 text-white"
                        : isCurrent
                        ? isValid
                          ? "bg-indigo-600 text-white"
                          : "bg-red-500 text-white"
                        : "bg-gray-200 text-gray-600"
                    }`}
                  >
                    {step}
                  </div>
                  {step < totalSteps && (
                    <div
                      className={`w-full h-1 mx-2 ${
                        step < currentStep ? "bg-indigo-600" : "bg-gray-200"
                      }`}
                    />
                  )}
                </div>
              );
            })}
          </div>
          <div className="flex justify-between text-xs text-gray-600">
            <span>Basic Info</span>
            <span>Timeline</span>
            <span>Requirements</span>
            <span>Deliverables</span>
            <span>Review</span>
          </div>
        </div>

        {/* Form Content */}
        <Card className="max-w-4xl mx-auto">
          <CardContent className="p-8">{renderStepContent()}</CardContent>
        </Card>

        {/* Navigation */}
        <div className="flex justify-between mt-8 max-w-4xl mx-auto">
          <Button
            variant="outline"
            onClick={prevStep}
            disabled={currentStep === 1}
          >
            Previous
          </Button>

          {currentStep < totalSteps ? (
            <div className="flex items-center gap-2">
              {!validateStep(currentStep) && (
                <span className="text-red-500 text-sm">
                  Please complete all required fields
                </span>
              )}
              <Button
                onClick={nextStep}
                disabled={!validateStep(currentStep)}
                className={`${
                  validateStep(currentStep)
                    ? "bg-indigo-600 hover:bg-indigo-700"
                    : "bg-gray-400 cursor-not-allowed"
                }`}
              >
                Next
              </Button>
            </div>
          ) : (
            <Button
              onClick={handleSubmit}
              disabled={isLoading}
              className="bg-green-600 hover:bg-green-700"
            >
              {isLoading ? "Creating..." : "Create Campaign"}
            </Button>
          )}
        </div>
      </div>
    </div>
  );
};

export default CreateCampaign;
