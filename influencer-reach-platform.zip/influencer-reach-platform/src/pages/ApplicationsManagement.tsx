import { useState, useEffect } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { useAuthStore } from "@/store/authStore";
import applicationService, { Application } from "@/services/applicationService";
import { firebaseChatService } from "@/services/firebaseChatService";
import { initiateCampaignConversation } from "@/utils/chatUtils";
import { toast } from "@/hooks/use-toast";
import {
  FileText,
  CheckCircle,
  XCircle,
  Clock,
  User,
  DollarSign,
  Calendar,
  MessageSquare,
  TrendingUp,
  Eye,
} from "lucide-react";
import { useNavigate } from "react-router-dom";

const ApplicationsManagement = () => {
  const { user } = useAuthStore();
  const navigate = useNavigate();
  const [applications, setApplications] = useState<Application[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState<string | null>(null);
  const [selectedApplication, setSelectedApplication] =
    useState<Application | null>(null);
  const [reviewNotes, setReviewNotes] = useState("");

  useEffect(() => {
    loadApplications();
  }, []);

  const loadApplications = async () => {
    setIsLoading(true);
    try {
      const response = await applicationService.getApplications();
      setApplications(response.results);
    } catch (error) {
      console.error("Failed to load applications:", error);
      toast({
        title: "Error",
        description: "Failed to load applications. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleAcceptApplication = async (applicationId: string) => {
    setActionLoading(applicationId);
    try {
      await applicationService.acceptApplication(applicationId, reviewNotes);
      toast({
        title: "Application accepted!",
        description: "The influencer has been notified.",
      });
      loadApplications();
      setSelectedApplication(null);
      setReviewNotes("");
    } catch (error) {
      console.error("Failed to accept application:", error);
      toast({
        title: "Error",
        description: "Failed to accept application. Please try again.",
        variant: "destructive",
      });
    } finally {
      setActionLoading(null);
    }
  };

  const handleRejectApplication = async (applicationId: string) => {
    setActionLoading(applicationId);
    try {
      await applicationService.rejectApplication(applicationId, reviewNotes);
      toast({
        title: "Application rejected",
        description: "The influencer has been notified.",
      });
      loadApplications();
      setSelectedApplication(null);
      setReviewNotes("");
    } catch (error) {
      console.error("Failed to reject application:", error);
      toast({
        title: "Error",
        description: "Failed to reject application. Please try again.",
        variant: "destructive",
      });
    } finally {
      setActionLoading(null);
    }
  };

  const handleContactInfluencer = async (application: Application) => {
    if (!user) return;

    try {
      console.log("🚀 Starting conversation with influencer:", application);

      // Create campaign-specific conversation between brand and influencer
      const conversationId = await initiateCampaignConversation(
        {
          id: user.id,
          name: user.name,
          role: user.role as "influencer" | "brand" | "superadmin",
        },
        {
          id: application.influencer.id,
          name: application.influencer.username,
          role: "influencer",
        },
        {
          id: application.campaign.id,
          title: application.campaign.title,
        }
      );

      console.log("✅ Conversation created/synced:", conversationId);

      // Navigate to messages page with selected conversation
      navigate("/messages", {
        state: {
          selectedConversation: {
            conversationId,
            otherParticipant: {
              id: application.influencer.id,
              name: application.influencer.username,
              role: "influencer" as const,
            },
          },
        },
      });

      toast({
        title: "Conversation started!",
        description: `You can now communicate directly with ${application.influencer.username}. The conversation is available in your messages.`,
      });
    } catch (error) {
      console.error("❌ Failed to start conversation:", error);
      toast({
        title: "Error",
        description: "Failed to start conversation. Please try again.",
        variant: "destructive",
      });
    }
  };

  const getStatusColor = (status: Application["status"]) => {
    switch (status) {
      case "pending":
        return "bg-yellow-100 text-yellow-800";
      case "accepted":
        return "bg-green-100 text-green-800";
      case "rejected":
        return "bg-red-100 text-red-800";
      case "withdrawn":
        return "bg-gray-100 text-gray-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getStatusIcon = (status: Application["status"]) => {
    switch (status) {
      case "pending":
        return <Clock className="h-4 w-4" />;
      case "accepted":
        return <CheckCircle className="h-4 w-4" />;
      case "rejected":
        return <XCircle className="h-4 w-4" />;
      case "withdrawn":
        return <XCircle className="h-4 w-4" />;
      default:
        return <FileText className="h-4 w-4" />;
    }
  };

  const pendingApplications = applications.filter(
    (app) => app.status === "pending"
  );
  const acceptedApplications = applications.filter(
    (app) => app.status === "accepted"
  );
  const rejectedApplications = applications.filter(
    (app) => app.status === "rejected"
  );

  const stats = {
    total: applications.length,
    pending: pendingApplications.length,
    accepted: acceptedApplications.length,
    rejected: rejectedApplications.length,
  };

  const ApplicationCard = ({ application }: { application: Application }) => (
    <Card className="hover:shadow-md transition-shadow">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Avatar>
              <AvatarImage
                src={application.influencer.profilePicture}
                alt={application.influencer.username}
              />
              <AvatarFallback>
                {application.influencer.username[0].toUpperCase()}
              </AvatarFallback>
            </Avatar>
            <div>
              <h4 className="font-semibold">
                {application.influencer.username}
              </h4>
              <p className="text-sm text-gray-600">
                {application.campaign.title}
              </p>
            </div>
          </div>
          <Badge className={getStatusColor(application.status)}>
            <span className="flex items-center space-x-1">
              {getStatusIcon(application.status)}
              <span>{application.status}</span>
            </span>
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        {application.notes && (
          <div>
            <h5 className="font-medium text-sm mb-1">Cover Letter:</h5>
            <p className="text-sm text-gray-700 line-clamp-3">
              {application.notes}
            </p>
          </div>
        )}

        {application.proposedBudget && application.proposedBudget.amount && (
          <div className="flex items-center space-x-2 text-sm">
            <DollarSign className="h-4 w-4 text-green-600" />
            <span className="font-medium text-green-600">
              {application.proposedBudget.currency}{" "}
              {application.proposedBudget.amount.toLocaleString()}
            </span>
            {application.proposedBudget.justification && (
              <span className="text-gray-500">
                ({application.proposedBudget.justification})
              </span>
            )}
          </div>
        )}

        <div className="flex items-center justify-between pt-2">
          <span className="text-sm text-gray-500 flex items-center">
            <Calendar className="h-4 w-4 mr-1" />
            {new Date(application.createdAt).toLocaleDateString()}
          </span>

          <div className="flex space-x-2">
            <Button
              size="sm"
              variant="outline"
              onClick={() => setSelectedApplication(application)}
            >
              <Eye className="h-4 w-4 mr-1" />
              View Details
            </Button>

            {application.status === "pending" && (
              <>
                <Button
                  size="sm"
                  variant="outline"
                  className="text-green-600 border-green-600 hover:bg-green-50"
                  onClick={() => handleAcceptApplication(application.id)}
                  disabled={actionLoading === application.id}
                >
                  <CheckCircle className="h-4 w-4 mr-1" />
                  Accept
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  className="text-red-600 border-red-600 hover:bg-red-50"
                  onClick={() => handleRejectApplication(application.id)}
                  disabled={actionLoading === application.id}
                >
                  <XCircle className="h-4 w-4 mr-1" />
                  Reject
                </Button>
              </>
            )}

            {application.status === "accepted" && (
              <Button
                size="sm"
                className="bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700"
                onClick={() => handleContactInfluencer(application)}
              >
                <MessageSquare className="h-4 w-4 mr-1" />
                Contact Influencer
              </Button>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading applications...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            Applications Management
          </h1>
          <p className="text-gray-600">
            Review and manage applications to your campaigns.
          </p>
        </div>

        {/* Stats Cards */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                Total Applications
              </CardTitle>
              <FileText className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.total}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                Pending Review
              </CardTitle>
              <Clock className="h-4 w-4 text-yellow-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-yellow-600">
                {stats.pending}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Accepted</CardTitle>
              <CheckCircle className="h-4 w-4 text-green-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600">
                {stats.accepted}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Rejected</CardTitle>
              <XCircle className="h-4 w-4 text-red-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-red-600">
                {stats.rejected}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Applications Tabs */}
        <Tabs defaultValue="pending" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger
              value="pending"
              className="flex items-center space-x-2"
            >
              <Clock className="h-4 w-4" />
              <span>Pending ({stats.pending})</span>
            </TabsTrigger>
            <TabsTrigger
              value="accepted"
              className="flex items-center space-x-2"
            >
              <CheckCircle className="h-4 w-4" />
              <span>Accepted ({stats.accepted})</span>
            </TabsTrigger>
            <TabsTrigger
              value="rejected"
              className="flex items-center space-x-2"
            >
              <XCircle className="h-4 w-4" />
              <span>Rejected ({stats.rejected})</span>
            </TabsTrigger>
            <TabsTrigger value="all" className="flex items-center space-x-2">
              <FileText className="h-4 w-4" />
              <span>All ({stats.total})</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="pending" className="space-y-4">
            {pendingApplications.length === 0 ? (
              <Card>
                <CardContent className="flex flex-col items-center justify-center py-12">
                  <Clock className="h-12 w-12 text-gray-400 mb-4" />
                  <p className="text-gray-600 text-center">
                    No pending applications
                  </p>
                  <p className="text-sm text-gray-500 text-center">
                    New applications will appear here for review
                  </p>
                </CardContent>
              </Card>
            ) : (
              <div className="grid gap-4">
                {pendingApplications.map((application) => (
                  <ApplicationCard
                    key={application.id}
                    application={application}
                  />
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="accepted" className="space-y-4">
            {acceptedApplications.length === 0 ? (
              <Card>
                <CardContent className="flex flex-col items-center justify-center py-12">
                  <CheckCircle className="h-12 w-12 text-gray-400 mb-4" />
                  <p className="text-gray-600 text-center">
                    No accepted applications
                  </p>
                </CardContent>
              </Card>
            ) : (
              <div className="grid gap-4">
                {acceptedApplications.map((application) => (
                  <ApplicationCard
                    key={application.id}
                    application={application}
                  />
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="rejected" className="space-y-4">
            {rejectedApplications.length === 0 ? (
              <Card>
                <CardContent className="flex flex-col items-center justify-center py-12">
                  <XCircle className="h-12 w-12 text-gray-400 mb-4" />
                  <p className="text-gray-600 text-center">
                    No rejected applications
                  </p>
                </CardContent>
              </Card>
            ) : (
              <div className="grid gap-4">
                {rejectedApplications.map((application) => (
                  <ApplicationCard
                    key={application.id}
                    application={application}
                  />
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="all" className="space-y-4">
            {applications.length === 0 ? (
              <Card>
                <CardContent className="flex flex-col items-center justify-center py-12">
                  <FileText className="h-12 w-12 text-gray-400 mb-4" />
                  <p className="text-gray-600 text-center">
                    No applications yet
                  </p>
                  <p className="text-sm text-gray-500 text-center">
                    Create campaigns to start receiving applications
                  </p>
                  <Button
                    onClick={() => navigate("/campaigns/create")}
                    className="mt-4"
                  >
                    Create Campaign
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <div className="grid gap-4">
                {applications.map((application) => (
                  <ApplicationCard
                    key={application.id}
                    application={application}
                  />
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>

        {/* Application Detail Modal */}
        {selectedApplication && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
            <div className="bg-white rounded-lg p-6 w-full max-w-2xl max-h-[90vh] overflow-y-auto">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-semibold">Application Details</h3>
                <Button
                  variant="ghost"
                  onClick={() => setSelectedApplication(null)}
                >
                  ×
                </Button>
              </div>

              <div className="space-y-6">
                {/* Influencer Info */}
                <div className="flex items-center space-x-4">
                  <Avatar className="h-16 w-16">
                    <AvatarImage
                      src={selectedApplication.influencer.profilePicture}
                      alt={selectedApplication.influencer.username}
                    />
                    <AvatarFallback>
                      {selectedApplication.influencer.username[0].toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <h4 className="text-lg font-semibold">
                      {selectedApplication.influencer.username}
                    </h4>
                    <p className="text-gray-600">
                      {selectedApplication.campaign.title}
                    </p>
                    <Badge
                      className={getStatusColor(selectedApplication.status)}
                    >
                      {selectedApplication.status}
                    </Badge>
                  </div>
                </div>

                {/* Cover Letter */}
                {selectedApplication.notes && (
                  <div>
                    <h5 className="font-medium mb-2">Cover Letter:</h5>
                    <p className="text-gray-700 whitespace-pre-wrap bg-gray-50 p-4 rounded-md">
                      {selectedApplication.notes}
                    </p>
                  </div>
                )}

                {/* Proposed Budget */}
                {selectedApplication.proposedBudget &&
                  selectedApplication.proposedBudget.amount && (
                    <div>
                      <h5 className="font-medium mb-2">Proposed Budget:</h5>
                      <div className="bg-gray-50 p-4 rounded-md">
                        <p className="text-lg font-semibold text-green-600">
                          {selectedApplication.proposedBudget.currency}{" "}
                          {selectedApplication.proposedBudget.amount.toLocaleString()}
                        </p>
                        {selectedApplication.proposedBudget.justification && (
                          <p className="text-gray-700 mt-2">
                            {selectedApplication.proposedBudget.justification}
                          </p>
                        )}
                      </div>
                    </div>
                  )}

                {/* Portfolio */}
                {selectedApplication.portfolio &&
                  selectedApplication.portfolio.length > 0 && (
                    <div>
                      <h5 className="font-medium mb-2">Portfolio:</h5>
                      <div className="space-y-3">
                        {selectedApplication.portfolio.map((item, index) => (
                          <div key={index} className="border rounded-md p-3">
                            <div className="flex items-center justify-between">
                              <div>
                                <p className="font-medium">{item.platform}</p>
                                <p className="text-sm text-gray-600">
                                  {item.description}
                                </p>
                              </div>
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() =>
                                  window.open(item.postUrl, "_blank")
                                }
                              >
                                View Post
                              </Button>
                            </div>
                            {item.metrics && (
                              <div className="flex space-x-4 mt-2 text-sm text-gray-500">
                                <span>
                                  Views: {item.metrics.views?.toLocaleString()}
                                </span>
                                <span>
                                  Likes: {item.metrics.likes?.toLocaleString()}
                                </span>
                                <span>
                                  Comments:{" "}
                                  {item.metrics.comments?.toLocaleString()}
                                </span>
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                {/* Review Actions */}
                {selectedApplication.status === "pending" && (
                  <div className="border-t pt-6">
                    <h5 className="font-medium mb-2">Review Application:</h5>
                    <div className="space-y-4">
                      <div>
                        <Label htmlFor="reviewNotes">Notes (optional)</Label>
                        <Textarea
                          id="reviewNotes"
                          placeholder="Add any notes for the influencer..."
                          value={reviewNotes}
                          onChange={(e) => setReviewNotes(e.target.value)}
                          rows={3}
                        />
                      </div>

                      <div className="flex space-x-3">
                        <Button
                          onClick={() =>
                            handleAcceptApplication(selectedApplication.id)
                          }
                          disabled={actionLoading === selectedApplication.id}
                          className="flex-1 bg-green-600 hover:bg-green-700"
                        >
                          <CheckCircle className="h-4 w-4 mr-2" />
                          Accept Application
                        </Button>
                        <Button
                          onClick={() =>
                            handleRejectApplication(selectedApplication.id)
                          }
                          disabled={actionLoading === selectedApplication.id}
                          variant="outline"
                          className="flex-1 text-red-600 border-red-600 hover:bg-red-50"
                        >
                          <XCircle className="h-4 w-4 mr-2" />
                          Reject Application
                        </Button>
                      </div>
                    </div>
                  </div>
                )}

                {/* Contact Influencer */}
                {selectedApplication.status === "accepted" && (
                  <div className="border-t pt-6">
                    <h5 className="font-medium mb-2">Contact Influencer:</h5>
                    <Button
                      onClick={() =>
                        handleContactInfluencer(selectedApplication)
                      }
                      className="w-full bg-blue-600 hover:bg-blue-700 text-white"
                    >
                      <MessageSquare className="h-4 w-4 mr-2" />
                      Message Influencer
                    </Button>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ApplicationsManagement;
