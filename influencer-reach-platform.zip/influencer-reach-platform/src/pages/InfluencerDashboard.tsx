import { useState, useEffect, useRef } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { useAuthStore } from "@/store/authStore";
import { campaignService, Campaign } from "@/services/campaignService";
import applicationService from "@/services/applicationService";
import { toast } from "@/hooks/use-toast";
import {
  TrendingUp,
  DollarSign,
  Calendar,
  Building,
  Users,
  Eye,
  Target,
} from "lucide-react";
import { useNavigate } from "react-router-dom";

const InfluencerDashboard = () => {
  const { user, users, fetchUsers } = useAuthStore();
  const navigate = useNavigate();
  const [campaigns, setCampaigns] = useState<Campaign[]>([]);
  const [applications, setApplications] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const initialized = useRef(false);
  const campaignsLoaded = useRef(false);
  const applicationsLoaded = useRef(false);

  useEffect(() => {
    if (!initialized.current) {
      initialized.current = true;
      loadCampaigns();
      loadApplications();
      fetchUsers();
    }
  }, []); // Empty dependency array

  const loadCampaigns = async () => {
    if (campaignsLoaded.current) return;
    campaignsLoaded.current = true;

    setIsLoading(true);
    try {
      const response = await campaignService.getCampaigns({ status: "active" });
      //@ts-ignore
      setCampaigns(response.results);
    } catch (error) {
      console.error("Failed to load campaigns:", error);
      campaignsLoaded.current = false; // Reset on error
      toast({
        title: "Error",
        description: "Failed to load campaigns. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const loadApplications = async () => {
    if (applicationsLoaded.current) return;
    applicationsLoaded.current = true;

    try {
      const myApplications = await applicationService.getMyApplications();
      setApplications(myApplications);
    } catch (error) {
      console.error("Failed to load applications:", error);
      applicationsLoaded.current = false; // Reset on error
    }
  };

  const availableCampaigns = (campaigns || []).filter(
    (campaign) => campaign.status === "active"
  );
  const appliedCampaigns = (applications || []).filter(
    (app) => app.status === "pending" || app.status === "accepted"
  );

  const stats = {
    availableCampaigns: availableCampaigns.length,
    appliedCampaigns: appliedCampaigns.length,
    totalEarnings: (applications || [])
      .filter((app) => app.status === "accepted")
      .reduce((sum, app) => {
        return sum + (app.proposedBudget?.amount || 0);
      }, 0),
    completedCampaigns: (applications || []).filter(
      (app) => app.status === "accepted"
    ).length,
  };

  const handleApplyCampaign = async (campaignId: string) => {
    if (!user) return;

    // Check if user account is active
    if (!user.isActive) {
      toast({
        title: "Account Pending Approval",
        description:
          "You need admin approval before you can apply to campaigns. Please wait for your account to be activated.",
        variant: "destructive",
        duration: 5000,
      });
      return;
    }

    // Navigate to campaign detail page to start chat
    navigate(`/campaigns/${campaignId}`);
  };

  const getStatusColor = (status: Campaign["status"]) => {
    switch (status) {
      case "active":
        return "bg-green-100 text-green-800";
      case "draft":
        return "bg-yellow-100 text-yellow-800";
      case "completed":
        return "bg-blue-100 text-blue-800";
      case "paused":
        return "bg-orange-100 text-orange-800";
      case "cancelled":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const formatBudget = (budget: Campaign["budget"]) => {
    if (!budget.amount) return "Negotiable";

    const { min, max } = budget.amount;
    if (min && max) {
      return `${
        budget.currency
      } ${min.toLocaleString()} - ${max.toLocaleString()}`;
    } else if (min) {
      return `${budget.currency} ${min.toLocaleString()}+`;
    } else if (max) {
      return `${budget.currency} ${max.toLocaleString()} max`;
    }
    return "Negotiable";
  };

  const brands = users?.filter((u) => u.role === "brand" && u.isActive) || [];

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        {/* Show only message for inactive influencers */}
        {user && !user.isActive ? (
          <div className="flex items-center justify-center min-h-[60vh]">
            <div className="max-w-md w-full">
              <div className="p-6 bg-orange-50 border border-orange-200 rounded-lg text-center">
                <div className="mb-4">
                  <svg
                    className="h-12 w-12 text-orange-400 mx-auto"
                    viewBox="0 0 20 20"
                    fill="currentColor"
                  >
                    <path
                      fillRule="evenodd"
                      d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z"
                      clipRule="evenodd"
                    />
                  </svg>
                </div>
                <h2 className="text-2xl font-bold text-orange-800 mb-4">
                  Account Pending Approval
                </h2>
                <div className="text-sm text-orange-700 mb-6 space-y-3">
                  <p>
                    Your influencer account is currently pending admin approval.
                  </p>
                  <p>
                    <strong>What happens next?</strong>
                  </p>
                  <ul className="text-left space-y-2">
                    <li>• Our admin team will review your application</li>
                    <li>• We'll verify your social media profiles</li>
                    <li>
                      • You'll receive an email notification once approved
                    </li>
                    <li>• This typically takes 1-3 brand days</li>
                  </ul>
                </div>
                <div className="mb-4">
                  <Badge
                    variant="outline"
                    className="text-orange-700 border-orange-300 px-4 py-2"
                  >
                    Status: Pending Review
                  </Badge>
                </div>
                <p className="text-xs text-orange-600">
                  Thank you for your patience. We'll be in touch soon!
                </p>
              </div>
            </div>
          </div>
        ) : (
          // Show full dashboard for active users
          <>
            <div className="mb-8">
              <h1 className="text-3xl font-bold text-gray-900 mb-2">
                Influencer Dashboard
              </h1>
              <p className="text-gray-600">
                Discover campaigns and grow your partnerships.
              </p>
            </div>

            {/* Stats Cards */}
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
              <Card className="hover:shadow-lg transition-shadow">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">
                    Available Campaigns
                  </CardTitle>
                  <Target className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    {stats.availableCampaigns}
                  </div>
                  <p className="text-xs text-muted-foreground">
                    New opportunities
                  </p>
                </CardContent>
              </Card>

              <Card className="hover:shadow-lg transition-shadow">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">
                    Applied Campaigns
                  </CardTitle>
                  <TrendingUp className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    {stats.appliedCampaigns}
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Pending applications
                  </p>
                </CardContent>
              </Card>

              <Card className="hover:shadow-lg transition-shadow">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">
                    Total Earnings
                  </CardTitle>
                  <DollarSign className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    ${stats.totalEarnings.toLocaleString()}
                  </div>
                  <p className="text-xs text-muted-foreground">
                    From completed campaigns
                  </p>
                </CardContent>
              </Card>

              <Card className="hover:shadow-lg transition-shadow">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">
                    Completed
                  </CardTitle>
                  <Eye className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    {stats.completedCampaigns}
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Successful partnerships
                  </p>
                </CardContent>
              </Card>
            </div>

            <div className="flex">
              {/* Available Campaigns */}
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle>Available Campaigns</CardTitle>
                      <CardDescription>
                        Browse and apply to new opportunities
                      </CardDescription>
                    </div>
                    <Button
                      variant="outline"
                      onClick={() => navigate("/campaigns")}
                    >
                      View All
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {isLoading ? (
                      <div className="text-center py-8 text-gray-500">
                        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600 mx-auto mb-4"></div>
                        <p>Loading campaigns...</p>
                      </div>
                    ) : availableCampaigns.length === 0 ? (
                      <div className="text-center py-8 text-gray-500">
                        <Target className="mx-auto h-12 w-12 mb-4 text-gray-300" />
                        <p>No campaigns available</p>
                        <p className="text-sm">
                          Check back soon for new opportunities
                        </p>
                      </div>
                    ) : (
                      availableCampaigns.slice(0, 3).map((campaign) => (
                        <div
                          key={campaign.id}
                          className="border rounded-lg p-4 hover:bg-gray-50 transition-colors cursor-pointer"
                          onClick={() => navigate(`/campaigns/${campaign.id}`)}
                        >
                          <div className="flex justify-between items-start mb-2">
                            <h3 className="font-semibold">{campaign.title}</h3>
                            <Badge className={getStatusColor(campaign.status)}>
                              {campaign.status}
                            </Badge>
                          </div>
                          <p className="text-sm text-gray-600 mb-3 line-clamp-2">
                            {campaign.description}
                          </p>

                          {/* Requirements */}
                          {campaign.requirements?.platforms &&
                            campaign.requirements.platforms.length > 0 && (
                              <div className="mb-3">
                                <h4 className="text-sm font-medium mb-1">
                                  Platforms:
                                </h4>
                                <div className="flex flex-wrap gap-1">
                                  {campaign.requirements.platforms.map(
                                    (platform, index) => (
                                      <Badge
                                        key={index}
                                        variant="secondary"
                                        className="text-xs"
                                      >
                                        {platform}
                                      </Badge>
                                    )
                                  )}
                                </div>
                              </div>
                            )}

                          <div className="flex items-center justify-between">
                            <div className="flex items-center space-x-4 text-sm">
                              <span className="flex items-center text-green-600">
                                <DollarSign className="h-4 w-4 mr-1" />
                                {formatBudget(campaign.budget)}
                              </span>
                              <span className="flex items-center text-gray-500">
                                <Building className="h-4 w-4 mr-1" />
                                {campaign?.brand?.companyName}
                              </span>
                            </div>
                            <div className="flex items-center space-x-2">
                              <span className="text-sm text-gray-500 flex items-center">
                                <Calendar className="h-4 w-4 mr-1" />
                                {new Date(
                                  campaign.timeline.applicationDeadline
                                ).toLocaleDateString()}
                              </span>
                              <Button
                                size="sm"
                                onClick={() => handleApplyCampaign(campaign.id)}
                              >
                                Start Chat
                              </Button>
                            </div>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          </>
        )}
      </div>
    </div>
  );
};

export default InfluencerDashboard;
