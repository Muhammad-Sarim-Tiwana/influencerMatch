import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { toast } from "@/components/ui/use-toast";
import brandService, { BrandProfile } from "@/services/brandService";
import {
  Building,
  Globe,
  MapPin,
  Users,
  Calendar,
  DollarSign,
  ArrowLeft,
  ExternalLink,
  Mail,
  Phone,
  Instagram,
  Twitter,
  Linkedin,
  Facebook,
  Youtube,
  Loader2,
} from "lucide-react";

const AdminBrandProfile = () => {
  const { brandId } = useParams<{ brandId: string }>();
  const navigate = useNavigate();
  const [brand, setBrand] = useState<BrandProfile | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchBrandProfile = async () => {
      if (!brandId) {
        setError("Brand ID is required");
        setIsLoading(false);
        return;
      }

      try {
        setIsLoading(true);
        setError(null);
        const brandData = await brandService.getBrandById(brandId);
        setBrand(brandData);
      } catch (err) {
        console.error("Failed to fetch brand profile:", err);
        setError("Failed to load brand profile");
        toast({
          variant: "destructive",
          title: "Error",
          description: "Failed to load brand profile",
        });
      } finally {
        setIsLoading(false);
      }
    };

    fetchBrandProfile();
  }, [brandId]);

  const getCompanyTypeLabel = (type: string) => {
    const types: Record<string, string> = {
      startup: "Startup",
      "small-brand": "Small Brand",
      "medium-brand": "Medium Brand",
      enterprise: "Enterprise",
      agency: "Agency",
      nonprofit: "Non-Profit",
    };
    return types[type] || type;
  };

  const getBudgetLabel = (budget: string) => {
    const budgets: Record<string, string> = {
      "under-1k": "Under $1,000",
      "1k-5k": "$1,000 - $5,000",
      "5k-10k": "$5,000 - $10,000",
      "10k-25k": "$10,000 - $25,000",
      "25k-50k": "$25,000 - $50,000",
      "50k-100k": "$50,000 - $100,000",
      "100k+": "$100,000+",
    };
    return budgets[budget] || budget;
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "verified":
        return "bg-green-100 text-green-800";
      case "pending":
        return "bg-yellow-100 text-yellow-800";
      case "rejected":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="h-8 w-8 animate-spin mx-auto mb-4" />
          <p className="text-gray-600">Loading brand profile...</p>
        </div>
      </div>
    );
  }

  if (error || !brand) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <p className="text-red-600 mb-4">{error || "Brand not found"}</p>
          <Button onClick={() => navigate("/admin")} variant="outline">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Admin Dashboard
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-6">
          <Button
            onClick={() => navigate("/admin")}
            variant="outline"
            className="mb-4"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Admin Dashboard
          </Button>
          <div className="flex items-center space-x-4">
            <Avatar className="h-16 w-16">
              <AvatarImage src={brand.logo} alt={brand.companyName} />
              <AvatarFallback className="text-lg">
                {brand.companyName.charAt(0)}
              </AvatarFallback>
            </Avatar>
            <div>
              <h1 className="text-3xl font-bold text-gray-900">
                {brand.companyName}
              </h1>
              <div className="flex items-center space-x-2 mt-2">
                <Badge variant="outline">{brand.industry}</Badge>
                <Badge variant="outline">
                  {getCompanyTypeLabel(brand.companyType)}
                </Badge>
                <Badge className={getStatusColor(brand.verificationStatus)}>
                  {brand.verificationStatus}
                </Badge>
                <Badge variant={brand.isActive ? "default" : "secondary"}>
                  {brand.isActive ? "Active" : "Inactive"}
                </Badge>
              </div>
            </div>
          </div>
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Main Profile Information */}
          <div className="lg:col-span-2 space-y-6">
            {/* Basic Information */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Building className="h-5 w-5" />
                  <span>Company Information</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {brand.description && (
                  <div>
                    <h4 className="font-medium text-gray-900 mb-2">
                      Description
                    </h4>
                    <p className="text-gray-600">{brand.description}</p>
                  </div>
                )}

                {brand.website && (
                  <div className="flex items-center space-x-2">
                    <Globe className="h-4 w-4 text-gray-500" />
                    <a
                      href={
                        brand.website.startsWith("http")
                          ? brand.website
                          : `https://${brand.website}`
                      }
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-blue-600 hover:underline flex items-center space-x-1"
                    >
                      <span>{brand.website}</span>
                      <ExternalLink className="h-3 w-3" />
                    </a>
                  </div>
                )}

                {brand.location?.headquarters && (
                  <div className="flex items-center space-x-2">
                    <MapPin className="h-4 w-4 text-gray-500" />
                    <span className="text-gray-600">
                      {[
                        brand.location.headquarters.city,
                        brand.location.headquarters.country,
                      ]
                        .filter(Boolean)
                        .join(", ")}
                    </span>
                  </div>
                )}

                {brand.teamSize && (
                  <div className="flex items-center space-x-2">
                    <Users className="h-4 w-4 text-gray-500" />
                    <span className="text-gray-600">
                      {brand.teamSize} employees
                    </span>
                  </div>
                )}

                {brand.founded && (
                  <div className="flex items-center space-x-2">
                    <Calendar className="h-4 w-4 text-gray-500" />
                    <span className="text-gray-600">
                      Founded in {brand.founded}
                    </span>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Contact Information */}
            {brand.contact && (
              <Card>
                <CardHeader>
                  <CardTitle>Contact Information</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {brand.contact.email && (
                    <div className="flex items-center space-x-2">
                      <Mail className="h-4 w-4 text-gray-500" />
                      <a
                        href={`mailto:${brand.contact.email}`}
                        className="text-blue-600 hover:underline"
                      >
                        {brand.contact.email}
                      </a>
                    </div>
                  )}

                  {brand.contact.phone && (
                    <div className="flex items-center space-x-2">
                      <Phone className="h-4 w-4 text-gray-500" />
                      <a
                        href={`tel:${brand.contact.phone}`}
                        className="text-blue-600 hover:underline"
                      >
                        {brand.contact.phone}
                      </a>
                    </div>
                  )}

                  {brand.contact.socialMedia && (
                    <div>
                      <h4 className="font-medium text-gray-900 mb-2">
                        Social Media
                      </h4>
                      <div className="flex flex-wrap gap-2">
                        {brand.contact.socialMedia.instagram && (
                          <a
                            href={brand.contact.socialMedia.instagram}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="flex items-center space-x-1 text-pink-600 hover:underline"
                          >
                            <Instagram className="h-4 w-4" />
                            <span>Instagram</span>
                          </a>
                        )}
                        {brand.contact.socialMedia.twitter && (
                          <a
                            href={brand.contact.socialMedia.twitter}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="flex items-center space-x-1 text-blue-500 hover:underline"
                          >
                            <Twitter className="h-4 w-4" />
                            <span>Twitter</span>
                          </a>
                        )}
                        {brand.contact.socialMedia.linkedin && (
                          <a
                            href={brand.contact.socialMedia.linkedin}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="flex items-center space-x-1 text-blue-700 hover:underline"
                          >
                            <Linkedin className="h-4 w-4" />
                            <span>LinkedIn</span>
                          </a>
                        )}
                        {brand.contact.socialMedia.facebook && (
                          <a
                            href={brand.contact.socialMedia.facebook}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="flex items-center space-x-1 text-blue-600 hover:underline"
                          >
                            <Facebook className="h-4 w-4" />
                            <span>Facebook</span>
                          </a>
                        )}
                        {brand.contact.socialMedia.youtube && (
                          <a
                            href={brand.contact.socialMedia.youtube}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="flex items-center space-x-1 text-red-600 hover:underline"
                          >
                            <Youtube className="h-4 w-4" />
                            <span>YouTube</span>
                          </a>
                        )}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            )}

            {/* Budget Information */}
            {brand.budget && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <DollarSign className="h-5 w-5" />
                    <span>Budget Information</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {brand.budget.monthlyInfluencerBudget && (
                    <div>
                      <h4 className="font-medium text-gray-900 mb-2">
                        Monthly Influencer Budget
                      </h4>
                      <p className="text-gray-600">
                        {getBudgetLabel(brand.budget.monthlyInfluencerBudget)}
                      </p>
                    </div>
                  )}

                  {brand.budget.campaignBudgetRange && (
                    <div>
                      <h4 className="font-medium text-gray-900 mb-2">
                        Campaign Budget Range
                      </h4>
                      <p className="text-gray-600">
                        $
                        {brand.budget.campaignBudgetRange.min?.toLocaleString() ||
                          0}{" "}
                        - $
                        {brand.budget.campaignBudgetRange.max?.toLocaleString() ||
                          0}
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>
            )}
          </div>

          {/* Sidebar Information */}
          <div className="space-y-6">
            {/* User Information */}
            <Card>
              <CardHeader>
                <CardTitle>Account Owner</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div>
                    <h4 className="font-medium text-gray-900">
                      {brand.user.name}
                    </h4>
                    <p className="text-sm text-gray-600">{brand.user.email}</p>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Badge variant="outline">{brand.user.role}</Badge>
                    <Badge
                      variant={
                        brand.user.isEmailVerified ? "default" : "secondary"
                      }
                    >
                      {brand.user.isEmailVerified ? "Verified" : "Unverified"}
                    </Badge>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Metrics */}
            {brand.metrics && (
              <Card>
                <CardHeader>
                  <CardTitle>Performance Metrics</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">
                      Total Campaigns
                    </span>
                    <span className="font-medium">
                      {brand.metrics.totalCampaigns}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">
                      Active Campaigns
                    </span>
                    <span className="font-medium">
                      {brand.metrics.activeCampaigns}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">
                      Completed Campaigns
                    </span>
                    <span className="font-medium">
                      {brand.metrics.completedCampaigns}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">
                      Influencers Worked With
                    </span>
                    <span className="font-medium">
                      {brand.metrics.totalInfluencersWorkedWith}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">
                      Average Rating
                    </span>
                    <span className="font-medium">
                      {brand.metrics.averageCampaignRating.toFixed(1)}/5.0
                    </span>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Preferences */}
            {brand.preferences && (
              <Card>
                <CardHeader>
                  <CardTitle>Preferences</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {brand.preferences.preferredInfluencerTypes && (
                    <div>
                      <h4 className="font-medium text-gray-900 mb-2">
                        Preferred Influencer Types
                      </h4>
                      <div className="flex flex-wrap gap-1">
                        {brand.preferences.preferredInfluencerTypes.map(
                          (type) => (
                            <Badge
                              key={type}
                              variant="outline"
                              className="text-xs"
                            >
                              {type}
                            </Badge>
                          )
                        )}
                      </div>
                    </div>
                  )}

                  {brand.preferences.preferredCategories && (
                    <div>
                      <h4 className="font-medium text-gray-900 mb-2">
                        Preferred Categories
                      </h4>
                      <div className="flex flex-wrap gap-1">
                        {brand.preferences.preferredCategories.map(
                          (category) => (
                            <Badge
                              key={category}
                              variant="outline"
                              className="text-xs"
                            >
                              {category}
                            </Badge>
                          )
                        )}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            )}

            {/* Account Details */}
            <Card>
              <CardHeader>
                <CardTitle>Account Details</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-600">Created</span>
                  <span className="font-medium">
                    {new Date(brand.createdAt).toLocaleDateString()}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Last Updated</span>
                  <span className="font-medium">
                    {new Date(brand.updatedAt).toLocaleDateString()}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Status</span>
                  <Badge variant={brand.isActive ? "default" : "secondary"}>
                    {brand.isActive ? "Active" : "Inactive"}
                  </Badge>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminBrandProfile;
