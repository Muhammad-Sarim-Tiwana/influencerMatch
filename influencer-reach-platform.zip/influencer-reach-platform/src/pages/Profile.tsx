import { useState, useEffect } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { useAuthStore } from "@/store/authStore";
import { toast } from "@/hooks/use-toast";
import {
  User,
  Mail,
  Building,
  MapPin,
  Users,
  Edit,
  Calendar,
  Shield,
  Instagram,
  Youtube,
  Twitter,
  Facebook,
  Linkedin,
  Camera,
  Globe,
  Phone,
  DollarSign,
  Tag,
} from "lucide-react";

const Profile = () => {
  const { user, updateProfile } = useAuthStore();
  const [isEditing, setIsEditing] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [formData, setFormData] = useState({
    name: user?.name || "",
    email: user?.email || "",
    bio: user?.bio || "",
    location: user?.location || "",
    // Brand-specific fields
    companyName: user?.brandProfile?.companyName || "",
    industry: user?.brandProfile?.industry || "",
    companyType: user?.brandProfile?.companyType || "",
    description: user?.brandProfile?.description || "",
    website: user?.brandProfile?.website || "",
    teamSize: user?.brandProfile?.teamSize || "",
    founded: user?.brandProfile?.founded?.toString() || "",
    headquarters: {
      country: user?.brandProfile?.location?.headquarters?.country || "",
      city: user?.brandProfile?.location?.headquarters?.city || "",
      address: user?.brandProfile?.location?.headquarters?.address || "",
    },
    contact: {
      phone: user?.brandProfile?.contact?.phone || "",
      email: user?.brandProfile?.contact?.email || "",
    },
    socialMedia: {
      instagram: user?.brandProfile?.contact?.socialMedia?.instagram || "",
      twitter: user?.brandProfile?.contact?.socialMedia?.twitter || "",
      linkedin: user?.brandProfile?.contact?.socialMedia?.linkedin || "",
      facebook: user?.brandProfile?.contact?.socialMedia?.facebook || "",
      youtube: user?.brandProfile?.contact?.socialMedia?.youtube || "",
    },
    monthlyInfluencerBudget:
      user?.brandProfile?.budget?.monthlyInfluencerBudget || "",
  });

  // Update form data when user data changes
  useEffect(() => {
    if (user) {
      setFormData({
        name: user.name || "",
        email: user.email || "",
        bio: user.bio || "",
        location: user.location || "",
        // Brand-specific fields
        companyName: user.brandProfile?.companyName || "",
        industry: user.brandProfile?.industry || "",
        companyType: user.brandProfile?.companyType || "",
        description: user.brandProfile?.description || "",
        website: user.brandProfile?.website || "",
        teamSize: user.brandProfile?.teamSize || "",
        founded: user.brandProfile?.founded?.toString() || "",
        headquarters: {
          country: user.brandProfile?.location?.headquarters?.country || "",
          city: user.brandProfile?.location?.headquarters?.city || "",
          address: user.brandProfile?.location?.headquarters?.address || "",
        },
        contact: {
          phone: user.brandProfile?.contact?.phone || "",
          email: user.brandProfile?.contact?.email || "",
        },
        socialMedia: {
          instagram: user.brandProfile?.contact?.socialMedia?.instagram || "",
          twitter: user.brandProfile?.contact?.socialMedia?.twitter || "",
          linkedin: user.brandProfile?.contact?.socialMedia?.linkedin || "",
          facebook: user.brandProfile?.contact?.socialMedia?.facebook || "",
          youtube: user.brandProfile?.contact?.socialMedia?.youtube || "",
        },
        monthlyInfluencerBudget:
          user.brandProfile?.budget?.monthlyInfluencerBudget || "",
      });
    }
  }, [user]);

  const handleSave = async () => {
    setIsLoading(true);
    try {
      if (user?.role === "brand" && user.brandProfile) {
        // Import brand service for direct brand profile updates
        const { default: brandService } = await import(
          "@/services/brandService"
        );

        // Update brand profile data using the correct method for current user
        await brandService.updateMyProfile({
          companyName: formData.companyName,
          industry: formData.industry,
          companyType: formData.companyType as
            | "startup"
            | "small-brand"
            | "medium-brand"
            | "enterprise"
            | "agency"
            | "nonprofit",
          description: formData.description,
          website: formData.website,
          teamSize: formData.teamSize as
            | "1-10"
            | "11-50"
            | "51-200"
            | "201-500"
            | "501-1000"
            | "1000+",
          founded: formData.founded ? parseInt(formData.founded) : undefined,
          location: {
            headquarters: {
              country: formData.headquarters.country,
              city: formData.headquarters.city,
              address: formData.headquarters.address,
            },
          },
          contact: {
            phone: formData.contact.phone,
            email: formData.contact.email,
            socialMedia: {
              instagram: formData.socialMedia.instagram,
              twitter: formData.socialMedia.twitter,
              linkedin: formData.socialMedia.linkedin,
              facebook: formData.socialMedia.facebook,
              youtube: formData.socialMedia.youtube,
            },
          },
          budget: {
            monthlyInfluencerBudget: formData.monthlyInfluencerBudget as
              | "under-1k"
              | "1k-5k"
              | "5k-10k"
              | "10k-25k"
              | "25k-50k"
              | "50k-100k"
              | "100k+",
          },
        });

        // Also update basic user data
        await updateProfile({
          name: formData.name,
          email: formData.email,
        });
      } else {
        // Update influencer/user profile data
        await updateProfile({
          name: formData.name,
          email: formData.email,
          bio: formData.bio,
          location: formData.location,
        });
      }

      toast({
        title: "Profile updated!",
        description: "Your profile has been successfully updated.",
      });

      setIsEditing(false);
    } catch (error) {
      console.error("Failed to update profile:", error);
      toast({
        title: "Update failed",
        description: "Failed to update your profile. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleCancel = () => {
    setFormData({
      name: user?.name || "",
      email: user?.email || "",
      bio: user?.bio || "",
      location: user?.location || "",
      // Brand-specific fields
      companyName: user?.brandProfile?.companyName || "",
      industry: user?.brandProfile?.industry || "",
      companyType: user?.brandProfile?.companyType || "",
      description: user?.brandProfile?.description || "",
      website: user?.brandProfile?.website || "",
      teamSize: user?.brandProfile?.teamSize || "",
      founded: user?.brandProfile?.founded?.toString() || "",
      headquarters: {
        country: user?.brandProfile?.location?.headquarters?.country || "",
        city: user?.brandProfile?.location?.headquarters?.city || "",
        address: user?.brandProfile?.location?.headquarters?.address || "",
      },
      contact: {
        phone: user?.brandProfile?.contact?.phone || "",
        email: user?.brandProfile?.contact?.email || "",
      },
      socialMedia: {
        instagram: user?.brandProfile?.contact?.socialMedia?.instagram || "",
        twitter: user?.brandProfile?.contact?.socialMedia?.twitter || "",
        linkedin: user?.brandProfile?.contact?.socialMedia?.linkedin || "",
        facebook: user?.brandProfile?.contact?.socialMedia?.facebook || "",
        youtube: user?.brandProfile?.contact?.socialMedia?.youtube || "",
      },
      monthlyInfluencerBudget:
        user?.brandProfile?.budget?.monthlyInfluencerBudget || "",
    });
    setIsEditing(false);
  };

  const formatDate = (date: Date | string | undefined) => {
    if (!date) return "Not available";

    try {
      const dateObj = typeof date === "string" ? new Date(date) : date;

      // Check if date is valid
      if (isNaN(dateObj.getTime())) {
        return "Not available";
      }

      return dateObj.toLocaleDateString("en-US", {
        year: "numeric",
        month: "long",
        day: "numeric",
      });
    } catch (error) {
      console.error("Error formatting date:", error);
      return "Not available";
    }
  };

  const getSocialPlatformIcon = (platform: string) => {
    switch (platform.toLowerCase()) {
      case "instagram":
        return <Instagram className="h-4 w-4" />;
      case "youtube":
        return <Youtube className="h-4 w-4" />;
      case "twitter":
        return <Twitter className="h-4 w-4" />;
      case "facebook":
        return <Facebook className="h-4 w-4" />;
      case "linkedin":
        return <Linkedin className="h-4 w-4" />;
      default:
        return <Camera className="h-4 w-4" />;
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-semibold text-gray-900 mb-2">
            Please log in to view your profile
          </h2>
          <p className="text-gray-600">
            You need to be authenticated to access this page.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="container mx-auto px-4 max-w-4xl">
        {/* Main Profile Card */}
        <Card className="mb-6">
          <CardHeader className="text-center">
            <div className="flex justify-center mb-4">
              <Avatar className="w-24 h-24">
                <AvatarImage
                  src={user.avatar || user.profileImage}
                  alt={user.name}
                />
                <AvatarFallback className="text-2xl">
                  {user.name
                    .split(" ")
                    .map((n) => n[0])
                    .join("")}
                </AvatarFallback>
              </Avatar>
            </div>
            <CardTitle className="text-2xl">{user.name}</CardTitle>
            <CardDescription className="flex items-center justify-center gap-2">
              <Badge
                variant={
                  user.role === "superadmin"
                    ? "default"
                    : user.role === "brand"
                    ? "secondary"
                    : "outline"
                }
              >
                {user.role === "superadmin"
                  ? "Super Admin"
                  : user.role === "brand"
                  ? "Brand"
                  : "Influencer"}
              </Badge>
              {user.verificationStatus === "verified" && (
                <Badge variant="default" className="bg-green-500">
                  <Shield className="h-3 w-3 mr-1" />
                  Verified
                </Badge>
              )}
            </CardDescription>
            <div className="flex justify-center mt-4">
              <Button
                onClick={() => setIsEditing(!isEditing)}
                variant={isEditing ? "secondary" : "default"}
                className={
                  !isEditing
                    ? "bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700"
                    : ""
                }
                disabled={isLoading}
              >
                <Edit className="mr-2 h-4 w-4" />
                {isEditing ? "Cancel Edit" : "Edit Profile"}
              </Button>
            </div>
          </CardHeader>

          <CardContent className="space-y-6">
            {/* Basic Information */}
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="name" className="flex items-center">
                  <User className="mr-2 h-4 w-4" />
                  Full Name
                </Label>
                {isEditing ? (
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) =>
                      setFormData({ ...formData, name: e.target.value })
                    }
                    disabled={isLoading}
                  />
                ) : (
                  <p className="p-2 bg-gray-50 rounded-md">{user.name}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="email" className="flex items-center">
                  <Mail className="mr-2 h-4 w-4" />
                  Email
                </Label>
                {isEditing ? (
                  <Input
                    id="email"
                    type="email"
                    value={formData.email}
                    onChange={(e) =>
                      setFormData({ ...formData, email: e.target.value })
                    }
                    disabled={isLoading}
                  />
                ) : (
                  <p className="p-2 bg-gray-50 rounded-md">{user.email}</p>
                )}
              </div>

              {user.role === "brand" && (
                <>
                  {/* Company Name */}
                  <div className="space-y-2">
                    <Label htmlFor="companyName" className="flex items-center">
                      <Building className="mr-2 h-4 w-4" />
                      Company Name
                    </Label>
                    {isEditing ? (
                      <Input
                        id="companyName"
                        value={formData.companyName}
                        onChange={(e) =>
                          setFormData({
                            ...formData,
                            companyName: e.target.value,
                          })
                        }
                        placeholder="Your company name"
                        disabled={isLoading}
                      />
                    ) : (
                      <p className="p-2 bg-gray-50 rounded-md">
                        {user.brandProfile?.companyName || "Not specified"}
                      </p>
                    )}
                  </div>

                  {/* Industry */}
                  <div className="space-y-2">
                    <Label htmlFor="industry" className="flex items-center">
                      <Tag className="mr-2 h-4 w-4" />
                      Industry
                    </Label>
                    {isEditing ? (
                      <Select
                        value={formData.industry}
                        onValueChange={(value) =>
                          setFormData({ ...formData, industry: value })
                        }
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select industry" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="fashion">Fashion</SelectItem>
                          <SelectItem value="beauty">Beauty</SelectItem>
                          <SelectItem value="technology">Technology</SelectItem>
                          <SelectItem value="food-beverage">
                            Food & Beverage
                          </SelectItem>
                          <SelectItem value="travel-hospitality">
                            Travel & Hospitality
                          </SelectItem>
                          <SelectItem value="fitness-health">
                            Fitness & Health
                          </SelectItem>
                          <SelectItem value="automotive">Automotive</SelectItem>
                          <SelectItem value="finance">Finance</SelectItem>
                          <SelectItem value="education">Education</SelectItem>
                          <SelectItem value="entertainment">
                            Entertainment
                          </SelectItem>
                          <SelectItem value="gaming">Gaming</SelectItem>
                          <SelectItem value="home-garden">
                            Home & Garden
                          </SelectItem>
                          <SelectItem value="pets">Pets</SelectItem>
                          <SelectItem value="sports">Sports</SelectItem>
                          <SelectItem value="nonprofit">Nonprofit</SelectItem>
                          <SelectItem value="b2b-services">
                            B2B Services
                          </SelectItem>
                          <SelectItem value="ecommerce">E-commerce</SelectItem>
                          <SelectItem value="media">Media</SelectItem>
                          <SelectItem value="healthcare">Healthcare</SelectItem>
                          <SelectItem value="real-estate">
                            Real Estate
                          </SelectItem>
                          <SelectItem value="other">Other</SelectItem>
                        </SelectContent>
                      </Select>
                    ) : (
                      <p className="p-2 bg-gray-50 rounded-md capitalize">
                        {user.brandProfile?.industry?.replace("-", " ") ||
                          "Not specified"}
                      </p>
                    )}
                  </div>

                  {/* Company Type */}
                  <div className="space-y-2">
                    <Label htmlFor="companyType" className="flex items-center">
                      <Building className="mr-2 h-4 w-4" />
                      Company Type
                    </Label>
                    {isEditing ? (
                      <Select
                        value={formData.companyType}
                        onValueChange={(value) =>
                          setFormData({ ...formData, companyType: value })
                        }
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select company type" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="startup">Startup</SelectItem>
                          <SelectItem value="small-brand">
                            Small Brand
                          </SelectItem>
                          <SelectItem value="medium-brand">
                            Medium Brand
                          </SelectItem>
                          <SelectItem value="enterprise">Enterprise</SelectItem>
                          <SelectItem value="agency">Agency</SelectItem>
                          <SelectItem value="nonprofit">Nonprofit</SelectItem>
                        </SelectContent>
                      </Select>
                    ) : (
                      <p className="p-2 bg-gray-50 rounded-md capitalize">
                        {user.brandProfile?.companyType?.replace("-", " ") ||
                          "Not specified"}
                      </p>
                    )}
                  </div>

                  {/* Company Description */}
                  <div className="space-y-2">
                    <Label htmlFor="description">Company Description</Label>
                    {isEditing ? (
                      <Textarea
                        id="description"
                        value={formData.description}
                        onChange={(e) =>
                          setFormData({
                            ...formData,
                            description: e.target.value,
                          })
                        }
                        placeholder="Describe your company..."
                        rows={4}
                        disabled={isLoading}
                      />
                    ) : (
                      <p className="p-2 bg-gray-50 rounded-md min-h-[100px]">
                        {user.brandProfile?.description ||
                          "No description provided"}
                      </p>
                    )}
                  </div>

                  {/* Website */}
                  <div className="space-y-2">
                    <Label htmlFor="website" className="flex items-center">
                      <Globe className="mr-2 h-4 w-4" />
                      Website
                    </Label>
                    {isEditing ? (
                      <Input
                        id="website"
                        type="url"
                        value={formData.website}
                        onChange={(e) =>
                          setFormData({ ...formData, website: e.target.value })
                        }
                        placeholder="https://yourcompany.com"
                        disabled={isLoading}
                      />
                    ) : (
                      <p className="p-2 bg-gray-50 rounded-md">
                        {user.brandProfile?.website ? (
                          <a
                            href={user.brandProfile.website}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-blue-600 hover:underline"
                          >
                            {user.brandProfile.website}
                          </a>
                        ) : (
                          "Not specified"
                        )}
                      </p>
                    )}
                  </div>

                  {/* Team Size */}
                  <div className="space-y-2">
                    <Label htmlFor="teamSize" className="flex items-center">
                      <Users className="mr-2 h-4 w-4" />
                      Team Size
                    </Label>
                    {isEditing ? (
                      <Select
                        value={formData.teamSize}
                        onValueChange={(value) =>
                          setFormData({ ...formData, teamSize: value })
                        }
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select team size" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="1-10">1-10 employees</SelectItem>
                          <SelectItem value="11-50">11-50 employees</SelectItem>
                          <SelectItem value="51-200">
                            51-200 employees
                          </SelectItem>
                          <SelectItem value="201-500">
                            201-500 employees
                          </SelectItem>
                          <SelectItem value="501-1000">
                            501-1000 employees
                          </SelectItem>
                          <SelectItem value="1000+">1000+ employees</SelectItem>
                        </SelectContent>
                      </Select>
                    ) : (
                      <p className="p-2 bg-gray-50 rounded-md">
                        {user.brandProfile?.teamSize
                          ? `${user.brandProfile.teamSize} employees`
                          : "Not specified"}
                      </p>
                    )}
                  </div>

                  {/* Founded Year */}
                  <div className="space-y-2">
                    <Label htmlFor="founded" className="flex items-center">
                      <Calendar className="mr-2 h-4 w-4" />
                      Founded Year
                    </Label>
                    {isEditing ? (
                      <Input
                        id="founded"
                        type="number"
                        min="1800"
                        max={new Date().getFullYear()}
                        value={formData.founded}
                        onChange={(e) =>
                          setFormData({ ...formData, founded: e.target.value })
                        }
                        placeholder="e.g., 2020"
                        disabled={isLoading}
                      />
                    ) : (
                      <p className="p-2 bg-gray-50 rounded-md">
                        {user.brandProfile?.founded || "Not specified"}
                      </p>
                    )}
                  </div>

                  {/* Monthly Influencer Budget */}
                  <div className="space-y-2">
                    <Label
                      htmlFor="monthlyInfluencerBudget"
                      className="flex items-center"
                    >
                      <DollarSign className="mr-2 h-4 w-4" />
                      Monthly Influencer Budget
                    </Label>
                    {isEditing ? (
                      <Select
                        value={formData.monthlyInfluencerBudget}
                        onValueChange={(value) =>
                          setFormData({
                            ...formData,
                            monthlyInfluencerBudget: value,
                          })
                        }
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select budget range" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="under-1k">Under $1,000</SelectItem>
                          <SelectItem value="1k-5k">$1,000 - $5,000</SelectItem>
                          <SelectItem value="5k-10k">
                            $5,000 - $10,000
                          </SelectItem>
                          <SelectItem value="10k-25k">
                            $10,000 - $25,000
                          </SelectItem>
                          <SelectItem value="25k-50k">
                            $25,000 - $50,000
                          </SelectItem>
                          <SelectItem value="50k-100k">
                            $50,000 - $100,000
                          </SelectItem>
                          <SelectItem value="100k+">$100,000+</SelectItem>
                        </SelectContent>
                      </Select>
                    ) : (
                      <p className="p-2 bg-gray-50 rounded-md">
                        {user.brandProfile?.budget?.monthlyInfluencerBudget
                          ? user.brandProfile.budget.monthlyInfluencerBudget
                              .replace("-", " - ")
                              .replace("k", ",000")
                              .replace("+", "+")
                          : "Not specified"}
                      </p>
                    )}
                  </div>

                  {/* Contact Information */}
                  <div className="space-y-4 border-t pt-4">
                    <h4 className="font-semibold text-md">
                      Contact Information
                    </h4>

                    {/* Contact Phone */}
                    <div className="space-y-2">
                      <Label
                        htmlFor="contactPhone"
                        className="flex items-center"
                      >
                        <Phone className="mr-2 h-4 w-4" />
                        Contact Phone
                      </Label>
                      {isEditing ? (
                        <Input
                          id="contactPhone"
                          type="tel"
                          value={formData.contact.phone}
                          onChange={(e) =>
                            setFormData({
                              ...formData,
                              contact: {
                                ...formData.contact,
                                phone: e.target.value,
                              },
                            })
                          }
                          placeholder="e.g., +1 (555) 123-4567"
                          disabled={isLoading}
                        />
                      ) : (
                        <p className="p-2 bg-gray-50 rounded-md">
                          {user.brandProfile?.contact?.phone || "Not specified"}
                        </p>
                      )}
                    </div>

                    {/* Contact Email */}
                    <div className="space-y-2">
                      <Label
                        htmlFor="contactEmail"
                        className="flex items-center"
                      >
                        <Mail className="mr-2 h-4 w-4" />
                        Contact Email
                      </Label>
                      {isEditing ? (
                        <Input
                          id="contactEmail"
                          type="email"
                          value={formData.contact.email}
                          onChange={(e) =>
                            setFormData({
                              ...formData,
                              contact: {
                                ...formData.contact,
                                email: e.target.value,
                              },
                            })
                          }
                          placeholder="contact@yourcompany.com"
                          disabled={isLoading}
                        />
                      ) : (
                        <p className="p-2 bg-gray-50 rounded-md">
                          {user.brandProfile?.contact?.email || "Not specified"}
                        </p>
                      )}
                    </div>
                  </div>

                  {/* Social Media */}
                  <div className="space-y-4 border-t pt-4">
                    <h4 className="font-semibold text-md">
                      Social Media Accounts
                    </h4>

                    {/* Instagram */}
                    <div className="space-y-2">
                      <Label htmlFor="instagram" className="flex items-center">
                        <Instagram className="mr-2 h-4 w-4" />
                        Instagram
                      </Label>
                      {isEditing ? (
                        <Input
                          id="instagram"
                          value={formData.socialMedia.instagram}
                          onChange={(e) =>
                            setFormData({
                              ...formData,
                              socialMedia: {
                                ...formData.socialMedia,
                                instagram: e.target.value,
                              },
                            })
                          }
                          placeholder="@yourcompany or https://instagram.com/yourcompany"
                          disabled={isLoading}
                        />
                      ) : (
                        <p className="p-2 bg-gray-50 rounded-md">
                          {user.brandProfile?.contact?.socialMedia
                            ?.instagram ? (
                            <a
                              href={
                                user.brandProfile.contact.socialMedia.instagram.startsWith(
                                  "http"
                                )
                                  ? user.brandProfile.contact.socialMedia
                                      .instagram
                                  : `https://instagram.com/${user.brandProfile.contact.socialMedia.instagram.replace(
                                      "@",
                                      ""
                                    )}`
                              }
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-blue-600 hover:underline"
                            >
                              {user.brandProfile.contact.socialMedia.instagram}
                            </a>
                          ) : (
                            "Not specified"
                          )}
                        </p>
                      )}
                    </div>

                    {/* Twitter */}
                    <div className="space-y-2">
                      <Label htmlFor="twitter" className="flex items-center">
                        <Twitter className="mr-2 h-4 w-4" />
                        Twitter
                      </Label>
                      {isEditing ? (
                        <Input
                          id="twitter"
                          value={formData.socialMedia.twitter}
                          onChange={(e) =>
                            setFormData({
                              ...formData,
                              socialMedia: {
                                ...formData.socialMedia,
                                twitter: e.target.value,
                              },
                            })
                          }
                          placeholder="@yourcompany or https://twitter.com/yourcompany"
                          disabled={isLoading}
                        />
                      ) : (
                        <p className="p-2 bg-gray-50 rounded-md">
                          {user.brandProfile?.contact?.socialMedia?.twitter ? (
                            <a
                              href={
                                user.brandProfile.contact.socialMedia.twitter.startsWith(
                                  "http"
                                )
                                  ? user.brandProfile.contact.socialMedia
                                      .twitter
                                  : `https://twitter.com/${user.brandProfile.contact.socialMedia.twitter.replace(
                                      "@",
                                      ""
                                    )}`
                              }
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-blue-600 hover:underline"
                            >
                              {user.brandProfile.contact.socialMedia.twitter}
                            </a>
                          ) : (
                            "Not specified"
                          )}
                        </p>
                      )}
                    </div>

                    {/* LinkedIn */}
                    <div className="space-y-2">
                      <Label htmlFor="linkedin" className="flex items-center">
                        <Linkedin className="mr-2 h-4 w-4" />
                        LinkedIn
                      </Label>
                      {isEditing ? (
                        <Input
                          id="linkedin"
                          value={formData.socialMedia.linkedin}
                          onChange={(e) =>
                            setFormData({
                              ...formData,
                              socialMedia: {
                                ...formData.socialMedia,
                                linkedin: e.target.value,
                              },
                            })
                          }
                          placeholder="https://linkedin.com/company/yourcompany"
                          disabled={isLoading}
                        />
                      ) : (
                        <p className="p-2 bg-gray-50 rounded-md">
                          {user.brandProfile?.contact?.socialMedia?.linkedin ? (
                            <a
                              href={
                                user.brandProfile.contact.socialMedia.linkedin.startsWith(
                                  "http"
                                )
                                  ? user.brandProfile.contact.socialMedia
                                      .linkedin
                                  : `https://linkedin.com/company/${user.brandProfile.contact.socialMedia.linkedin}`
                              }
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-blue-600 hover:underline"
                            >
                              {user.brandProfile.contact.socialMedia.linkedin}
                            </a>
                          ) : (
                            "Not specified"
                          )}
                        </p>
                      )}
                    </div>

                    {/* Facebook */}
                    <div className="space-y-2">
                      <Label htmlFor="facebook" className="flex items-center">
                        <Facebook className="mr-2 h-4 w-4" />
                        Facebook
                      </Label>
                      {isEditing ? (
                        <Input
                          id="facebook"
                          value={formData.socialMedia.facebook}
                          onChange={(e) =>
                            setFormData({
                              ...formData,
                              socialMedia: {
                                ...formData.socialMedia,
                                facebook: e.target.value,
                              },
                            })
                          }
                          placeholder="https://facebook.com/yourcompany"
                          disabled={isLoading}
                        />
                      ) : (
                        <p className="p-2 bg-gray-50 rounded-md">
                          {user.brandProfile?.contact?.socialMedia?.facebook ? (
                            <a
                              href={
                                user.brandProfile.contact.socialMedia.facebook.startsWith(
                                  "http"
                                )
                                  ? user.brandProfile.contact.socialMedia
                                      .facebook
                                  : `https://facebook.com/${user.brandProfile.contact.socialMedia.facebook}`
                              }
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-blue-600 hover:underline"
                            >
                              {user.brandProfile.contact.socialMedia.facebook}
                            </a>
                          ) : (
                            "Not specified"
                          )}
                        </p>
                      )}
                    </div>

                    {/* YouTube */}
                    <div className="space-y-2">
                      <Label htmlFor="youtube" className="flex items-center">
                        <Youtube className="mr-2 h-4 w-4" />
                        YouTube
                      </Label>
                      {isEditing ? (
                        <Input
                          id="youtube"
                          value={formData.socialMedia.youtube}
                          onChange={(e) =>
                            setFormData({
                              ...formData,
                              socialMedia: {
                                ...formData.socialMedia,
                                youtube: e.target.value,
                              },
                            })
                          }
                          placeholder="https://youtube.com/@yourcompany"
                          disabled={isLoading}
                        />
                      ) : (
                        <p className="p-2 bg-gray-50 rounded-md">
                          {user.brandProfile?.contact?.socialMedia?.youtube ? (
                            <a
                              href={
                                user.brandProfile.contact.socialMedia.youtube.startsWith(
                                  "http"
                                )
                                  ? user.brandProfile.contact.socialMedia
                                      .youtube
                                  : `https://youtube.com/@${user.brandProfile.contact.socialMedia.youtube.replace(
                                      "@",
                                      ""
                                    )}`
                              }
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-blue-600 hover:underline"
                            >
                              {user.brandProfile.contact.socialMedia.youtube}
                            </a>
                          ) : (
                            "Not specified"
                          )}
                        </p>
                      )}
                    </div>
                  </div>

                  {/* Headquarters Location */}
                  <div className="space-y-4 border-t pt-4">
                    <h4 className="font-semibold text-md">
                      Headquarters Location
                    </h4>

                    {/* Country */}
                    <div className="space-y-2">
                      <Label htmlFor="hqCountry" className="flex items-center">
                        <MapPin className="mr-2 h-4 w-4" />
                        Country
                      </Label>
                      {isEditing ? (
                        <Input
                          id="hqCountry"
                          value={formData.headquarters.country}
                          onChange={(e) =>
                            setFormData({
                              ...formData,
                              headquarters: {
                                ...formData.headquarters,
                                country: e.target.value,
                              },
                            })
                          }
                          placeholder="e.g., United States"
                          disabled={isLoading}
                        />
                      ) : (
                        <p className="p-2 bg-gray-50 rounded-md">
                          {user.brandProfile?.location?.headquarters?.country ||
                            "Not specified"}
                        </p>
                      )}
                    </div>

                    {/* City */}
                    <div className="space-y-2">
                      <Label htmlFor="hqCity" className="flex items-center">
                        <MapPin className="mr-2 h-4 w-4" />
                        City
                      </Label>
                      {isEditing ? (
                        <Input
                          id="hqCity"
                          value={formData.headquarters.city}
                          onChange={(e) =>
                            setFormData({
                              ...formData,
                              headquarters: {
                                ...formData.headquarters,
                                city: e.target.value,
                              },
                            })
                          }
                          placeholder="e.g., New York"
                          disabled={isLoading}
                        />
                      ) : (
                        <p className="p-2 bg-gray-50 rounded-md">
                          {user.brandProfile?.location?.headquarters?.city ||
                            "Not specified"}
                        </p>
                      )}
                    </div>

                    {/* Address */}
                    <div className="space-y-2">
                      <Label htmlFor="hqAddress" className="flex items-center">
                        <MapPin className="mr-2 h-4 w-4" />
                        Address
                      </Label>
                      {isEditing ? (
                        <Input
                          id="hqAddress"
                          value={formData.headquarters.address}
                          onChange={(e) =>
                            setFormData({
                              ...formData,
                              headquarters: {
                                ...formData.headquarters,
                                address: e.target.value,
                              },
                            })
                          }
                          placeholder="e.g., 123 Business Ave, Suite 100"
                          disabled={isLoading}
                        />
                      ) : (
                        <p className="p-2 bg-gray-50 rounded-md">
                          {user.brandProfile?.location?.headquarters?.address ||
                            "Not specified"}
                        </p>
                      )}
                    </div>
                  </div>
                </>
              )}

              {user.role === "influencer" && (
                <>
                  <div className="space-y-2">
                    <Label htmlFor="location" className="flex items-center">
                      <MapPin className="mr-2 h-4 w-4" />
                      Location
                    </Label>
                    {isEditing ? (
                      <Input
                        id="location"
                        value={formData.location}
                        onChange={(e) =>
                          setFormData({ ...formData, location: e.target.value })
                        }
                        placeholder="e.g., New York, NY"
                        disabled={isLoading}
                      />
                    ) : (
                      <p className="p-2 bg-gray-50 rounded-md">
                        {user.location || "Not specified"}
                      </p>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="bio">Bio</Label>
                    {isEditing ? (
                      <Textarea
                        id="bio"
                        value={formData.bio}
                        onChange={(e) =>
                          setFormData({ ...formData, bio: e.target.value })
                        }
                        placeholder="Tell us about yourself..."
                        rows={4}
                        disabled={isLoading}
                      />
                    ) : (
                      <p className="p-2 bg-gray-50 rounded-md min-h-[100px]">
                        {user.bio || "No bio provided"}
                      </p>
                    )}
                  </div>
                </>
              )}
            </div>

            {/* Save/Cancel Buttons */}
            {isEditing && (
              <div className="flex space-x-4 pt-4">
                <Button
                  onClick={handleSave}
                  className="flex-1 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700"
                  disabled={isLoading}
                >
                  {isLoading ? "Saving..." : "Save Changes"}
                </Button>
                <Button
                  onClick={handleCancel}
                  variant="outline"
                  className="flex-1"
                  disabled={isLoading}
                >
                  Cancel
                </Button>
              </div>
            )}

            {/* Account Information */}
            <div className="border-t pt-4">
              <h3 className="font-semibold mb-4 flex items-center">
                <Calendar className="mr-2 h-4 w-4" />
                Account Information
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                <div>
                  <p className="text-gray-500">Account Type</p>
                  <p className="capitalize font-medium">{user.role}</p>
                </div>
                <div>
                  <p className="text-gray-500">Member Since</p>
                  <p className="font-medium">{formatDate(user.createdAt)}</p>
                </div>
                <div>
                  <p className="text-gray-500">Status</p>
                  <p
                    className={`font-medium ${
                      user.isActive ? "text-green-600" : "text-red-600"
                    }`}
                  >
                    {user.isActive ? "Active" : "Inactive"}
                  </p>
                </div>
                <div>
                  <p className="text-gray-500">Email Verified</p>
                  <p
                    className={`font-medium ${
                      user.isEmailVerified ? "text-green-600" : "text-amber-600"
                    }`}
                  >
                    {user.isEmailVerified ? "Yes" : "Pending"}
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Brand Metrics (for brands) */}
        {user.role === "brand" && user.brandProfile?.metrics && (
          <Card className="mb-6">
            <CardHeader>
              <CardTitle className="text-lg">Brand Performance</CardTitle>
              <CardDescription>
                Your campaign statistics and performance metrics
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="text-center p-4 border rounded-lg">
                  <p className="text-2xl font-bold text-blue-600">
                    {user.brandProfile.metrics.totalCampaigns}
                  </p>
                  <p className="text-sm text-gray-600">Total Campaigns</p>
                </div>
                <div className="text-center p-4 border rounded-lg">
                  <p className="text-2xl font-bold text-green-600">
                    {user.brandProfile.metrics.activeCampaigns}
                  </p>
                  <p className="text-sm text-gray-600">Active Campaigns</p>
                </div>
                <div className="text-center p-4 border rounded-lg">
                  <p className="text-2xl font-bold text-purple-600">
                    {user.brandProfile.metrics.completedCampaigns}
                  </p>
                  <p className="text-sm text-gray-600">Completed Campaigns</p>
                </div>
                <div className="text-center p-4 border rounded-lg">
                  <p className="text-2xl font-bold text-orange-600">
                    {user.brandProfile.metrics.totalInfluencersWorkedWith}
                  </p>
                  <p className="text-sm text-gray-600">
                    Influencers Worked With
                  </p>
                </div>
              </div>
              {user.brandProfile.metrics.averageCampaignRating > 0 && (
                <div className="mt-4 text-center">
                  <div className="flex items-center justify-center space-x-2">
                    <span className="text-lg font-semibold">
                      Average Rating:
                    </span>
                    <div className="flex items-center">
                      <span className="text-xl font-bold text-yellow-600">
                        {user.brandProfile.metrics.averageCampaignRating.toFixed(
                          1
                        )}
                      </span>
                      <span className="text-yellow-600 ml-1">★</span>
                    </div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        )}

        {/* Brand Subscription (for brands) */}
        {user.role === "brand" && user.brandProfile?.subscription && (
          <Card className="mb-6">
            <CardHeader>
              <CardTitle className="text-lg">Subscription Plan</CardTitle>
              <CardDescription>
                Your current subscription details and features
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <p className="text-sm text-gray-500">Current Plan</p>
                  <Badge
                    variant={
                      user.brandProfile.subscription.plan === "enterprise"
                        ? "default"
                        : user.brandProfile.subscription.plan === "premium"
                        ? "secondary"
                        : "outline"
                    }
                    className="capitalize"
                  >
                    {user.brandProfile.subscription.plan}
                  </Badge>
                </div>
                {user.brandProfile.subscription.startDate && (
                  <div className="space-y-2">
                    <p className="text-sm text-gray-500">Start Date</p>
                    <p className="font-medium">
                      {formatDate(user.brandProfile.subscription.startDate)}
                    </p>
                  </div>
                )}
                {user.brandProfile.subscription.endDate && (
                  <div className="space-y-2">
                    <p className="text-sm text-gray-500">End Date</p>
                    <p className="font-medium">
                      {formatDate(user.brandProfile.subscription.endDate)}
                    </p>
                  </div>
                )}
              </div>
              {user.brandProfile.subscription.features &&
                user.brandProfile.subscription.features.length > 0 && (
                  <div className="mt-4">
                    <p className="text-sm text-gray-500 mb-2">
                      Included Features
                    </p>
                    <div className="flex flex-wrap gap-2">
                      {user.brandProfile.subscription.features.map(
                        (feature, index) => (
                          <Badge
                            key={index}
                            variant="outline"
                            className="text-xs"
                          >
                            {feature}
                          </Badge>
                        )
                      )}
                    </div>
                  </div>
                )}
            </CardContent>
          </Card>
        )}

        {/* Social Platforms (for influencers) */}
        {user.role === "influencer" &&
          user.socialPlatforms &&
          user.socialPlatforms.length > 0 && (
            <Card className="mb-6">
              <CardHeader>
                <CardTitle className="text-lg">
                  Social Media Platforms
                </CardTitle>
                <CardDescription>
                  Your connected social media accounts
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {user.socialPlatforms.map((platform, index) => (
                    <div
                      key={index}
                      className="flex items-center justify-between p-3 border rounded-lg"
                    >
                      <div className="flex items-center space-x-3">
                        {getSocialPlatformIcon(platform.platform)}
                        <div>
                          <p className="font-medium capitalize">
                            {platform.platform}
                          </p>
                          <p className="text-sm text-gray-600">
                            @{platform.username}
                          </p>
                        </div>
                      </div>
                      {platform.followerCount && (
                        <div className="text-right">
                          <p className="font-medium">
                            {platform.followerCount.toLocaleString()}
                          </p>
                          <p className="text-xs text-gray-500">followers</p>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

        {/* Categories and Tags (for influencers) */}
        {user.role === "influencer" && (user.categories || user.tags) && (
          <Card className="mb-6">
            <CardHeader>
              <CardTitle className="text-lg">Interests & Categories</CardTitle>
              <CardDescription>
                Your content categories and expertise areas
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {user.categories && user.categories.length > 0 && (
                <div>
                  <Label className="text-sm font-medium">Categories</Label>
                  <div className="flex flex-wrap gap-2 mt-2">
                    {user.categories.map((category, index) => (
                      <Badge key={index} variant="secondary">
                        {category}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}
              {user.tags && user.tags.length > 0 && (
                <div>
                  <Label className="text-sm font-medium">Tags</Label>
                  <div className="flex flex-wrap gap-2 mt-2">
                    {user.tags.map((tag, index) => (
                      <Badge key={index} variant="outline">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        )}

        {/* Metrics (for influencers) */}
        {user.role === "influencer" && user.metrics && (
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Performance Metrics</CardTitle>
              <CardDescription>
                Your account performance and statistics
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {user.metrics.totalFollowers && (
                  <div className="text-center p-3 bg-gray-50 rounded-lg">
                    <p className="text-2xl font-bold text-indigo-600">
                      {user.metrics.totalFollowers.toLocaleString()}
                    </p>
                    <p className="text-sm text-gray-600">Total Followers</p>
                  </div>
                )}
                {user.metrics.averageEngagement && (
                  <div className="text-center p-3 bg-gray-50 rounded-lg">
                    <p className="text-2xl font-bold text-purple-600">
                      {(user.metrics.averageEngagement * 100).toFixed(1)}%
                    </p>
                    <p className="text-sm text-gray-600">Avg Engagement</p>
                  </div>
                )}
                {user.metrics.completedCampaigns !== undefined && (
                  <div className="text-center p-3 bg-gray-50 rounded-lg">
                    <p className="text-2xl font-bold text-green-600">
                      {user.metrics.completedCampaigns}
                    </p>
                    <p className="text-sm text-gray-600">Campaigns Done</p>
                  </div>
                )}
                {user.metrics.rating && (
                  <div className="text-center p-3 bg-gray-50 rounded-lg">
                    <p className="text-2xl font-bold text-yellow-600">
                      {user.metrics.rating.toFixed(1)}★
                    </p>
                    <p className="text-sm text-gray-600">Rating</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
};

export default Profile;
