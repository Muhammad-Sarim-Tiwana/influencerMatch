import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { CheckCircle, MessageSquare, Users, Zap, TestTube } from "lucide-react";
import { firebaseChatService } from "@/services/firebaseChatService";
import { useAuthStore } from "@/store/authStore";
import { useToast } from "@/hooks/use-toast";

const ChatSystemDemo: React.FC = () => {
  const { user } = useAuthStore();
  const { toast } = useToast();
  const [isTestingConnection, setIsTestingConnection] = useState(false);

  const testFirebaseConnection = async () => {
    if (!user) {
      toast({
        title: "Error",
        description: "Please log in first to test the connection.",
        variant: "destructive",
      });
      return;
    }

    setIsTestingConnection(true);
    try {
      console.log("🧪 Testing Firebase connection...");

      // Test 1: Try to get user conversations
      console.log("📋 Testing getUserConversations...");
      const conversations = await firebaseChatService.getUserConversations(
        user.id
      );
      console.log("✅ getUserConversations successful:", conversations);

      // Test 2: Try to create a test conversation
      console.log("💬 Testing createOrGetConversation...");
      const testConversationId =
        await firebaseChatService.createOrGetConversation(
          user.id,
          user.name,
          user.role as "influencer" | "brand" | "superadmin",
          "test-user-123",
          "Test User",
          "brand"
        );
      console.log("✅ createOrGetConversation successful:", testConversationId);

      toast({
        title: "Success",
        description: "Firebase connection test passed!",
      });
    } catch (error) {
      console.error("❌ Firebase connection test failed:", error);
      toast({
        title: "Connection Test Failed",
        description:
          error instanceof Error ? error.message : "Unknown error occurred",
        variant: "destructive",
      });
    } finally {
      setIsTestingConnection(false);
    }
  };
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold tracking-tight mb-2">
          New Chat System Overview
        </h1>
        <p className="text-muted-foreground">
          Firebase Realtime Database-powered messaging system with user ID-based
          conversations
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              Real-time Messaging
            </CardTitle>
            <Zap className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">
              <CheckCircle className="h-6 w-6 inline mr-2" />
              Active
            </div>
            <p className="text-xs text-muted-foreground">
              Messages sync instantly via Firebase
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              User-based Conversations
            </CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">
              <CheckCircle className="h-6 w-6 inline mr-2" />
              Enabled
            </div>
            <p className="text-xs text-muted-foreground">
              Direct messaging between any users
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              Backend API Removed
            </CardTitle>
            <MessageSquare className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-600">
              <CheckCircle className="h-6 w-6 inline mr-2" />
              Complete
            </div>
            <p className="text-xs text-muted-foreground">
              All messaging via Firebase only
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Test Firebase Connection */}
      <Card className="mb-8">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <TestTube className="h-5 w-5" />
            <span>Test Firebase Connection</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <p className="text-muted-foreground">
              Click the button below to test if Firebase is properly connected
              and working.
            </p>
            <Button
              onClick={testFirebaseConnection}
              disabled={isTestingConnection || !user}
              className="w-full sm:w-auto"
            >
              {isTestingConnection ? "Testing..." : "Test Firebase Connection"}
            </Button>
            {!user && (
              <p className="text-sm text-muted-foreground">
                Please log in to test the Firebase connection.
              </p>
            )}
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <Card>
          <CardHeader>
            <CardTitle>✅ What's Been Implemented</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <h4 className="font-semibold text-green-600">Backend Changes</h4>
              <ul className="space-y-1 text-sm">
                <li>• Removed message API routes</li>
                <li>• Removed message controllers</li>
                <li>• Removed message services</li>
                <li>• Removed message models</li>
                <li>• Removed message validations</li>
                <li>• Removed message documentation</li>
              </ul>
            </div>

            <div className="space-y-2">
              <h4 className="font-semibold text-blue-600">Frontend Updates</h4>
              <ul className="space-y-1 text-sm">
                <li>• New Firebase chat service with user IDs</li>
                <li>• Updated Chat component</li>
                <li>• New ChatList component</li>
                <li>• Updated Messages page</li>
                <li>• Added chat utilities</li>
                <li>• Removed old message API calls</li>
              </ul>
            </div>

            <div className="space-y-2">
              <h4 className="font-semibold text-purple-600">Integration</h4>
              <ul className="space-y-1 text-sm">
                <li>• BrandDashboard "Message" buttons updated</li>
                <li>• Navigation state handling</li>
                <li>• Conversation initiation utilities</li>
              </ul>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>🚀 How to Use</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <h4 className="font-semibold">For Brands</h4>
              <p className="text-sm text-muted-foreground">
                Click "Message" button on any influencer in your dashboard to
                start a conversation.
              </p>
            </div>

            <div className="space-y-2">
              <h4 className="font-semibold">For All Users</h4>
              <ul className="space-y-1 text-sm text-muted-foreground">
                <li>• Go to Messages page to view all conversations</li>
                <li>• Select a conversation to start chatting</li>
                <li>• Messages sync in real-time</li>
                <li>• Unread counts are tracked</li>
              </ul>
            </div>

            <div className="space-y-2">
              <h4 className="font-semibold">Technical Details</h4>
              <div className="space-y-1">
                <Badge variant="outline">Firebase Realtime Database</Badge>
                <Badge variant="outline">User ID-based conversations</Badge>
                <Badge variant="outline">Real-time sync</Badge>
                <Badge variant="outline">No backend API needed</Badge>
              </div>
            </div>

            <div className="p-4 bg-muted rounded-lg">
              <h5 className="font-semibold mb-2">Conversation ID Format</h5>
              <code className="text-sm">{"{userId1}_{userId2}"}</code>
              <p className="text-xs text-muted-foreground mt-1">
                User IDs are sorted alphabetically to ensure consistent
                conversation IDs
              </p>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="mt-8">
        <CardHeader>
          <CardTitle>📁 File Structure Changes</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h4 className="font-semibold text-red-600 mb-2">
                🗑️ Removed Files
              </h4>
              <ul className="text-sm space-y-1 text-muted-foreground">
                <li>backend/src/models/message.model.js</li>
                <li>backend/src/controllers/message.controller.js</li>
                <li>backend/src/services/message.service.js</li>
                <li>backend/src/routes/v1/message.route.js</li>
                <li>backend/src/validations/message.validation.js</li>
                <li>backend/src/docs/messages.yml</li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold text-green-600 mb-2">
                ✨ New/Updated Files
              </h4>
              <ul className="text-sm space-y-1 text-muted-foreground">
                <li>frontend/src/services/firebaseChatService.ts (updated)</li>
                <li>frontend/src/components/ChatNew.tsx (new)</li>
                <li>frontend/src/components/ChatListNew.tsx (new)</li>
                <li>frontend/src/pages/MessagesNew.tsx (updated)</li>
                <li>frontend/src/utils/chatUtils.ts (new)</li>
                <li>frontend/src/lib/api.ts (cleaned up)</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default ChatSystemDemo;
