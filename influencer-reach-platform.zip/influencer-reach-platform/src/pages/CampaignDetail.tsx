import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { useAuthStore } from "@/store/authStore";
import { campaignService, Campaign } from "@/services/campaignService";
import { firebaseChatService } from "@/services/firebaseChatService";
import { initiateCampaignConversation } from "@/utils/chatUtils";
import { toast } from "@/hooks/use-toast";
import ChatNew from "@/components/ChatNew";
import RecommendedInfluencers from "@/components/RecommendedInfluencersV2";
import {
  ArrowLeft,
  DollarSign,
  Calendar,
  Building,
  Users,
  Target,
  MapPin,
  Clock,
  MessageCircle,
  AlertTriangle,
} from "lucide-react";
import AllInfluencers from "@/components/AllInfluencers";

const CampaignDetail = () => {
  const { campaignId } = useParams<{ campaignId: string }>();
  const navigate = useNavigate();
  const { user } = useAuthStore();
  const [campaign, setCampaign] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [showChat, setShowChat] = useState(false);
  const [conversationId, setConversationId] = useState<string | null>(null);

  useEffect(() => {
    if (campaignId) {
      loadCampaign();
    }
  }, [campaignId]);

  const loadCampaign = async () => {
    if (!campaignId) return;

    setIsLoading(true);
    try {
      console.log("Loading campaign with ID:", campaignId);
      const response = await campaignService.getCampaign(campaignId);
      console.log("Campaign API response:", response);

      // The API client returns the data directly, so response IS the campaign data
      const campaignData = response.data || response;
      console.log("Campaign data:", campaignData);

      setCampaign(campaignData as any); // Cast to any to avoid type issues

      // Log brand info for debugging
      const campaign = campaignData as any;
      if (campaign?.brand) {
        console.log("Brand info loaded:", {
          id: campaign.brand.id,
          companyName: campaign.brand.companyName,
          user: campaign.brand.user,
        });
      } else {
        console.warn("No brand information found in campaign data");
      }
    } catch (error) {
      console.error("Failed to load campaign:", error);
      toast({
        title: "Error",
        description: "Failed to load campaign details.",
        variant: "destructive",
      });
      navigate("/campaigns");
    } finally {
      setIsLoading(false);
    }
  };

  const handleStartChat = async () => {
    if (!user || !campaign) return;

    try {
      console.log("🚀 Starting conversation for campaign:", campaign);
      console.log("Current user:", {
        id: user.id,
        name: user.name,
        role: user.role,
      });

      let currentCampaign = campaign;

      // Check if we have brand user info, with better validation
      const hasBrandUser =
        currentCampaign.brand?.user?.id &&
        currentCampaign.brand?.user?.name &&
        currentCampaign.brand?.user?.id !== null;

      if (!hasBrandUser) {
        console.warn(
          "Brand user information is missing or incomplete, attempting to reload campaign..."
        );

        toast({
          title: "Loading...",
          description: "Getting brand contact information...",
        });

        // Try to reload the campaign to get complete data
        try {
          const response = await campaignService.getCampaign(campaignId!);
          const freshCampaignData = response.data || response;
          currentCampaign = freshCampaignData as any;
          setCampaign(currentCampaign);
          console.log("Reloaded campaign data:", currentCampaign);
        } catch (reloadError) {
          console.error("Failed to reload campaign:", reloadError);
          toast({
            title: "Error",
            description:
              "Failed to load campaign data. Please try refreshing the page.",
            variant: "destructive",
          });
          return;
        }

        // Check again after reload
        const hasValidBrandUser =
          currentCampaign?.brand?.user?.id &&
          currentCampaign?.brand?.user?.name &&
          currentCampaign?.brand?.user?.id !== null;

        if (!hasValidBrandUser) {
          console.error("Campaign brand user data after reload:", {
            brand: currentCampaign?.brand,
            user: currentCampaign?.brand?.user,
          });

          // Use fallback information from brand contact if available
          const fallbackBrandInfo = {
            id: currentCampaign?.brand?.id || "unknown",
            name:
              currentCampaign?.brand?.companyName ||
              currentCampaign?.brand?.contact?.email ||
              "Brand Representative",
            role: "brand" as const,
          };

          // If we have at least a brand ID or contact info, try to proceed with fallback
          if (
            currentCampaign?.brand?.id ||
            currentCampaign?.brand?.contact?.email
          ) {
            console.warn(
              "Using fallback brand information:",
              fallbackBrandInfo
            );

            toast({
              title: "Using Contact Information",
              description:
                "We'll use the brand's contact information for this conversation.",
              variant: "default",
            });

            try {
              const conversationId = await initiateCampaignConversation(
                {
                  id: user.id,
                  name: user.name,
                  role: user.role as "influencer" | "brand" | "superadmin",
                },
                fallbackBrandInfo,
                {
                  id: currentCampaign.id,
                  title: currentCampaign.title,
                }
              );

              console.log(
                "✅ Campaign conversation created with fallback info:",
                conversationId
              );
              setConversationId(conversationId);
              setShowChat(true);
              return;
            } catch (fallbackError) {
              console.error("Failed even with fallback:", fallbackError);
            }
          }

          // If all else fails, show the error
          toast({
            title: "Contact Information Unavailable",
            description:
              "Brand contact information is not available. This appears to be a data issue. Please try refreshing the page or contact support.",
            variant: "destructive",
          });
          return;
        }
      }

      // Create campaign-specific conversation between current user and brand owner
      const conversationId = await initiateCampaignConversation(
        {
          id: user.id,
          name: user.name,
          role: user.role as "influencer" | "brand" | "superadmin",
        },
        {
          id: currentCampaign.brand.user.id,
          name: currentCampaign.brand.user.name,
          role: "brand",
        },
        {
          id: currentCampaign.id,
          title: currentCampaign.title,
        }
      );

      console.log("✅ Campaign conversation created/synced:", conversationId);

      setConversationId(conversationId);
      setShowChat(true);

      toast({
        title: "Chat started!",
        description: `You can now chat with ${currentCampaign.brand.user.name} from ${currentCampaign.brand.companyName}.`,
      });
    } catch (error) {
      console.error("❌ Failed to start conversation:", error);
      toast({
        title: "Error",
        description:
          error.message || "Failed to start conversation. Please try again.",
        variant: "destructive",
      });
    }
  };

  const getStatusColor = (status: Campaign["status"]) => {
    switch (status) {
      case "active":
        return "bg-green-100 text-green-800";
      case "draft":
        return "bg-yellow-100 text-yellow-800";
      case "completed":
        return "bg-blue-100 text-blue-800";
      case "paused":
        return "bg-orange-100 text-orange-800";
      case "cancelled":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const formatBudget = (budget: Campaign["budget"]) => {
    if (!budget.amount) return "Negotiable";

    const { min, max } = budget.amount;
    if (min && max) {
      return `${
        budget.currency
      } ${min.toLocaleString()} - ${max.toLocaleString()}`;
    } else if (min) {
      return `${budget.currency} ${min.toLocaleString()}+`;
    } else if (max) {
      return `${budget.currency} ${max.toLocaleString()} max`;
    }
    return "Negotiable";
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading campaign details...</p>
        </div>
      </div>
    );
  }

  if (!campaign) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <AlertTriangle className="mx-auto h-12 w-12 text-red-500 mb-4" />
          <p className="text-gray-600">Campaign not found</p>
          <Button onClick={() => navigate("/campaigns")} className="mt-4">
            Back to Campaigns
          </Button>
        </div>
      </div>
    );
  }

  // If showing chat, render the chat component
  if (showChat) {
    return (
      <div className="min-h-screen bg-gray-50">
        <div className="container mx-auto px-4 py-8">
          <Button
            variant="ghost"
            onClick={() => setShowChat(false)}
            className="mb-4"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Campaign Details
          </Button>

          <ChatNew
            conversationId={conversationId || undefined}
            recipientId={campaign.brand?.user?.id}
            recipientName={campaign.brand?.user?.name}
            recipientRole="brand"
            onBack={() => setShowChat(false)}
          />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-6">
          <Button
            variant="ghost"
            onClick={() => navigate("/campaigns")}
            className="mb-4"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Campaigns
          </Button>

          <div className="flex items-start justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900 mb-2">
                {campaign.title}
              </h1>
              <div className="flex items-center space-x-4 mb-4">
                <Badge className={getStatusColor(campaign.status)}>
                  {campaign.status}
                </Badge>

                <span className="flex items-center text-green-600 font-semibold">
                  <DollarSign className="h-4 w-4 mr-1" />
                  {formatBudget(campaign.budget)}
                </span>
              </div>
            </div>

            {user?.role === "influencer" && campaign.status === "active" && (
              <div className="flex flex-col space-y-2">
                <Button
                  onClick={handleStartChat}
                  className="bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700"
                >
                  <MessageCircle className="h-4 w-4 mr-2" />
                  {campaign.brand?.user?.id &&
                  campaign.brand?.user?.name &&
                  campaign.brand.user.id !== null
                    ? "Start Conversation"
                    : "Contact Brand"}
                </Button>
                {(!campaign.brand?.user?.id ||
                  !campaign.brand?.user?.name ||
                  campaign.brand.user.id === null) && (
                  <p className="text-xs text-gray-500 text-center">
                    We'll load the contact information when you click
                  </p>
                )}
              </div>
            )}
          </div>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Campaign Details */}
          <div className="lg:col-span-2 space-y-6">
            {/* Description */}
            <Card>
              <CardHeader>
                <CardTitle>Campaign Description</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-700 whitespace-pre-wrap">
                  {campaign.description}
                </p>

                {/* Objectives */}
                {campaign.objectives && campaign.objectives.length > 0 && (
                  <div className="mt-4">
                    <h4 className="font-medium mb-2">Campaign Objectives:</h4>
                    <div className="flex flex-wrap gap-2">
                      {campaign.objectives.map((objective, index) => (
                        <Badge key={index} variant="secondary">
                          {objective.replace("-", " ")}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}

                {/* Tags */}
                {campaign.tags && campaign.tags.length > 0 && (
                  <div className="mt-4">
                    <h4 className="font-medium mb-2">Tags:</h4>
                    <div className="flex flex-wrap gap-2">
                      {campaign.tags.map((tag, index) => (
                        <Badge key={index} variant="outline">
                          #{tag}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Product Information */}
            {campaign.productInfo && (
              <Card>
                <CardHeader>
                  <CardTitle>Product Information</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {campaign.productInfo.name && (
                    <div>
                      <h4 className="font-medium mb-1">Product Name:</h4>
                      <p className="text-gray-700">
                        {campaign.productInfo.name}
                      </p>
                    </div>
                  )}

                  {campaign.productInfo.description && (
                    <div>
                      <h4 className="font-medium mb-1">Description:</h4>
                      <p className="text-gray-700">
                        {campaign.productInfo.description}
                      </p>
                    </div>
                  )}

                  {campaign.productInfo.price && (
                    <div>
                      <h4 className="font-medium mb-1">Price:</h4>
                      <p className="text-gray-700 font-semibold">
                        {campaign.budget?.currency || "USD"}{" "}
                        {campaign.productInfo.price}
                      </p>
                    </div>
                  )}

                  {campaign.productInfo.urls &&
                    campaign.productInfo.urls.length > 0 && (
                      <div>
                        <h4 className="font-medium mb-2">Product Links:</h4>
                        <div className="space-y-1">
                          {campaign.productInfo.urls.map((url, index) => (
                            <a
                              key={index}
                              href={url}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-blue-600 hover:underline block"
                            >
                              {url}
                            </a>
                          ))}
                        </div>
                      </div>
                    )}
                </CardContent>
              </Card>
            )}

            {/* Requirements */}
            {campaign.requirements && (
              <Card>
                <CardHeader>
                  <CardTitle>Requirements</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {campaign.requirements.platforms &&
                    campaign.requirements.platforms.length > 0 && (
                      <div>
                        <h4 className="font-medium mb-2">Platforms:</h4>
                        <div className="flex flex-wrap gap-2">
                          {campaign.requirements.platforms.map(
                            (platform, index) => (
                              <Badge key={index} variant="secondary">
                                {platform}
                              </Badge>
                            )
                          )}
                        </div>
                      </div>
                    )}

                  {campaign.requirements.influencerTypes &&
                    campaign.requirements.influencerTypes.length > 0 && (
                      <div>
                        <h4 className="font-medium mb-2">Influencer Types:</h4>
                        <div className="flex flex-wrap gap-2">
                          {campaign.requirements.influencerTypes.map(
                            (type, index) => (
                              <Badge key={index} variant="secondary">
                                {type.charAt(0).toUpperCase() + type.slice(1)}
                              </Badge>
                            )
                          )}
                        </div>
                      </div>
                    )}

                  {campaign.requirements.followerRange &&
                    (campaign.requirements.followerRange.min ||
                      campaign.requirements.followerRange.max) && (
                      <div>
                        <h4 className="font-medium mb-2">Follower Range:</h4>
                        <p className="text-gray-700">
                          {campaign.requirements.followerRange.min
                            ? campaign.requirements.followerRange.min.toLocaleString()
                            : "0"}{" "}
                          -{" "}
                          {campaign.requirements.followerRange.max
                            ? campaign.requirements.followerRange.max.toLocaleString()
                            : "unlimited"}
                        </p>
                      </div>
                    )}

                  {campaign.requirements.demographics && (
                    <div>
                      <h4 className="font-medium mb-2">Target Demographics:</h4>
                      <div className="space-y-2">
                        {campaign.requirements.demographics.ageGroups &&
                          campaign.requirements.demographics.ageGroups.length >
                            0 && (
                            <div>
                              <span className="text-gray-700">
                                Age Groups:{" "}
                              </span>
                              <div className="flex flex-wrap gap-1 mt-1">
                                {campaign.requirements.demographics.ageGroups.map(
                                  (ageGroup, index) => (
                                    <Badge key={index} variant="outline">
                                      {ageGroup}
                                    </Badge>
                                  )
                                )}
                              </div>
                            </div>
                          )}
                        {campaign.requirements.demographics.genders &&
                          campaign.requirements.demographics.genders.length >
                            0 && (
                            <div>
                              <span className="text-gray-700">Genders: </span>
                              <div className="flex flex-wrap gap-1 mt-1">
                                {campaign.requirements.demographics.genders.map(
                                  (gender, index) => (
                                    <Badge key={index} variant="outline">
                                      {gender.charAt(0).toUpperCase() +
                                        gender.slice(1)}
                                    </Badge>
                                  )
                                )}
                              </div>
                            </div>
                          )}
                        {campaign.requirements.demographics.locations &&
                          campaign.requirements.demographics.locations.length >
                            0 && (
                            <div>
                              <span className="text-gray-700">Locations: </span>
                              <div className="flex flex-wrap gap-1 mt-1">
                                {campaign.requirements.demographics.locations.map(
                                  (location, index) => (
                                    <Badge key={index} variant="outline">
                                      {location}
                                    </Badge>
                                  )
                                )}
                              </div>
                            </div>
                          )}
                      </div>
                    </div>
                  )}

                  {campaign.requirements.engagementRate &&
                    (campaign.requirements.engagementRate.min ||
                      campaign.requirements.engagementRate.max) && (
                      <div>
                        <h4 className="font-medium mb-2">Engagement Rate:</h4>
                        <p className="text-gray-700">
                          {campaign.requirements.engagementRate.min || 0}% -{" "}
                          {campaign.requirements.engagementRate.max || 100}%
                        </p>
                      </div>
                    )}

                  {campaign.requirements.languages &&
                    campaign.requirements.languages.length > 0 && (
                      <div>
                        <h4 className="font-medium mb-2">Languages:</h4>
                        <div className="flex flex-wrap gap-2">
                          {campaign.requirements.languages.map(
                            (language, index) => (
                              <Badge key={index} variant="secondary">
                                {language}
                              </Badge>
                            )
                          )}
                        </div>
                      </div>
                    )}

                  {campaign.requirements.excludeCompetitors && (
                    <div className="flex items-center gap-2">
                      <Badge variant="destructive">
                        Excludes Competitor Influencers
                      </Badge>
                    </div>
                  )}
                </CardContent>
              </Card>
            )}

            {/* Deliverables */}
            {campaign.deliverables && campaign.deliverables.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle>Deliverables</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {campaign.deliverables.map((deliverable, index) => (
                      <div
                        key={index}
                        className="border rounded-lg p-4 bg-gray-50"
                      >
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center gap-2">
                            <Badge variant="outline">
                              {deliverable.quantity}x {deliverable.type}
                            </Badge>
                            <Badge variant="secondary">
                              {deliverable.platform}
                            </Badge>
                          </div>
                        </div>

                        {deliverable.specifications && (
                          <div className="space-y-2 text-sm">
                            {deliverable.specifications.duration && (
                              <p className="text-gray-600">
                                <strong>Duration:</strong>{" "}
                                {deliverable.specifications.duration} seconds
                              </p>
                            )}

                            {deliverable.specifications.dimensions && (
                              <p className="text-gray-600">
                                <strong>Dimensions:</strong>{" "}
                                {deliverable.specifications.dimensions}
                              </p>
                            )}

                            {deliverable.specifications.hashtags &&
                              deliverable.specifications.hashtags.length >
                                0 && (
                                <div className="text-gray-600">
                                  <strong>Required Hashtags:</strong>
                                  <div className="flex flex-wrap gap-1 mt-1">
                                    {deliverable.specifications.hashtags.map(
                                      (hashtag, i) => (
                                        <Badge
                                          key={i}
                                          variant="outline"
                                          className="text-xs"
                                        >
                                          #{hashtag}
                                        </Badge>
                                      )
                                    )}
                                  </div>
                                </div>
                              )}

                            {deliverable.specifications.mentions &&
                              deliverable.specifications.mentions.length >
                                0 && (
                                <div className="text-gray-600">
                                  <strong>Required Mentions:</strong>
                                  <div className="flex flex-wrap gap-1 mt-1">
                                    {deliverable.specifications.mentions.map(
                                      (mention, i) => (
                                        <Badge
                                          key={i}
                                          variant="outline"
                                          className="text-xs"
                                        >
                                          @{mention}
                                        </Badge>
                                      )
                                    )}
                                  </div>
                                </div>
                              )}

                            {deliverable.specifications.guidelines && (
                              <div className="text-gray-600">
                                <strong>Guidelines:</strong>
                                <p className="mt-1 text-gray-700 whitespace-pre-wrap">
                                  {deliverable.specifications.guidelines}
                                </p>
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Application Questions */}
            {campaign.application &&
              campaign.application.questions &&
              campaign.application.questions.length > 0 && (
                <Card>
                  <CardHeader>
                    <CardTitle>Application Questions</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {campaign.application.questions.map((question, index) => (
                        <div
                          key={index}
                          className="border-l-4 border-blue-200 pl-4"
                        >
                          <div className="flex items-center gap-2 mb-1">
                            <Badge
                              variant={
                                question.required ? "default" : "secondary"
                              }
                            >
                              {question.required ? "Required" : "Optional"}
                            </Badge>
                            <Badge variant="outline">{question.type}</Badge>
                          </div>
                          <p className="text-gray-700 font-medium mb-2">
                            {question.question}
                          </p>
                          {question.options && question.options.length > 0 && (
                            <div>
                              <p className="text-sm text-gray-600 mb-1">
                                Options:
                              </p>
                              <div className="flex flex-wrap gap-1">
                                {question.options.map((option, optIndex) => (
                                  <Badge
                                    key={optIndex}
                                    variant="outline"
                                    className="text-xs"
                                  >
                                    {option}
                                  </Badge>
                                ))}
                              </div>
                            </div>
                          )}
                        </div>
                      ))}

                      {campaign.application.autoApprove && (
                        <div className="mt-4 p-3 bg-green-50 border border-green-200 rounded-lg">
                          <p className="text-green-800 text-sm font-medium">
                            ✓ Auto-approval enabled for qualified influencers
                          </p>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              )}

            {/* Attachments */}
            {campaign.attachments && campaign.attachments.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle>Attachments</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {campaign.attachments.map((attachment, index) => (
                      <a
                        key={index}
                        href={attachment.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center gap-2 p-2 rounded-lg border hover:bg-gray-50 transition-colors"
                      >
                        <div className="flex-1">
                          <p className="font-medium text-sm">
                            {attachment.name}
                          </p>
                          <p className="text-xs text-gray-500">
                            {attachment.type}
                          </p>
                        </div>
                        <Badge variant="outline" className="text-xs">
                          Download
                        </Badge>
                      </a>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Budget Details */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <DollarSign className="h-5 w-5 mr-2" />
                  Budget & Payment
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-gray-600">Budget Type:</span>
                  <Badge variant="outline">
                    {campaign.budget?.type || "Negotiable"}
                  </Badge>
                </div>

                {campaign.budget?.amount && (
                  <>
                    {campaign.budget.amount.min && (
                      <div className="flex justify-between">
                        <span className="text-gray-600">Minimum:</span>
                        <span className="font-medium">
                          {campaign.budget.currency || "USD"}{" "}
                          {campaign.budget.amount.min.toLocaleString()}
                        </span>
                      </div>
                    )}
                    {campaign.budget.amount.max && (
                      <div className="flex justify-between">
                        <span className="text-gray-600">Maximum:</span>
                        <span className="font-medium">
                          {campaign.budget.currency || "USD"}{" "}
                          {campaign.budget.amount.max.toLocaleString()}
                        </span>
                      </div>
                    )}
                  </>
                )}

                {campaign.budget?.paymentTerms && (
                  <div className="pt-2 border-t">
                    <span className="text-gray-600 text-sm">
                      Payment Terms:
                    </span>
                    <p className="text-sm mt-1">
                      {campaign.budget.paymentTerms}
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Timeline */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Clock className="h-5 w-5 mr-2" />
                  Timeline
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-gray-600">Application Deadline:</span>
                  <span className="font-medium text-sm">
                    {new Date(
                      campaign.timeline.applicationDeadline
                    ).toLocaleDateString()}
                  </span>
                </div>

                {campaign.timeline.contentDeadline && (
                  <div className="flex justify-between">
                    <span className="text-gray-600">Content Deadline:</span>
                    <span className="font-medium text-sm">
                      {new Date(
                        campaign.timeline.contentDeadline
                      ).toLocaleDateString()}
                    </span>
                  </div>
                )}

                <div className="flex justify-between">
                  <span className="text-gray-600">Campaign Start:</span>
                  <span className="font-medium text-sm">
                    {new Date(
                      campaign.timeline.campaignStart
                    ).toLocaleDateString()}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Campaign End:</span>
                  <span className="font-medium text-sm">
                    {new Date(
                      campaign.timeline.campaignEnd
                    ).toLocaleDateString()}
                  </span>
                </div>
              </CardContent>
            </Card>

            {/* Campaign Metrics */}
            {campaign.metrics && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Target className="h-5 w-5 mr-2" />
                    Campaign Metrics
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Views:</span>
                    <span className="font-medium">
                      {campaign.metrics.views.toLocaleString()}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Applications:</span>
                    <span className="font-medium">
                      {campaign.metrics.applications.toLocaleString()}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Accepted:</span>
                    <span className="font-medium">
                      {campaign.metrics.accepted.toLocaleString()}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Completed:</span>
                    <span className="font-medium">
                      {campaign.metrics.completed.toLocaleString()}
                    </span>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Brand Info */}
            {campaign.brand && (
              <Card>
                <CardHeader>
                  <CardTitle>About the Brand</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center space-x-3 mb-4">
                    <Avatar className="h-12 w-12">
                      <AvatarImage
                        src=""
                        alt={campaign.brand.companyName || "Brand"}
                      />
                      <AvatarFallback>
                        {campaign.brand.companyName
                          ? campaign.brand.companyName
                              .split(" ")
                              .map((n) => n[0])
                              .join("")
                          : "B"}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <h4 className="font-semibold">
                        {campaign.brand.companyName || "Brand"}
                      </h4>
                      {campaign.brand.industry && (
                        <p className="text-sm text-gray-600">
                          {campaign.brand.industry}
                        </p>
                      )}
                    </div>
                  </div>

                  {campaign.brand.description && (
                    <p className="text-gray-700 text-sm mb-4">
                      {campaign.brand.description}
                    </p>
                  )}
                </CardContent>
              </Card>
            )}
          </div>
        </div>

        {/* Recommended Influencers Carousel */}
        {campaignId && user.role === "brand" && (
          <RecommendedInfluencers campaignId={campaignId} />
        )}
        {/* all influencers */}
        {/* {campaignId && user.role === "brand" && (
          <AllInfluencers campaignId={campaignId} />
        )} */}
      </div>
    </div>
  );
};

export default CampaignDetail;
