import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { toast } from "@/components/ui/use-toast";
import userService, { BackendUser } from "@/services/userService";
import {
  User,
  MapPin,
  Users,
  Calendar,
  DollarSign,
  ArrowLeft,
  ExternalLink,
  Mail,
  Phone,
  Instagram,
  Youtube,
  Twitter,
  Facebook,
  Linkedin,
  TrendingUp,
  Star,
  Eye,
  Heart,
  MessageCircle,
  Share,
  Loader2,
  Globe,
} from "lucide-react";

const AdminInfluencerProfile = () => {
  const { influencerId } = useParams<{ influencerId: string }>();
  const navigate = useNavigate();
  const [influencer, setInfluencer] = useState<BackendUser | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchInfluencerProfile = async () => {
      if (!influencerId) {
        setError("Influencer ID is required");
        setIsLoading(false);
        return;
      }

      try {
        setIsLoading(true);
        setError(null);
        const influencerData = await userService.getUserById(influencerId);
        setInfluencer(influencerData);
      } catch (err) {
        console.error("Failed to fetch influencer profile:", err);
        setError("Failed to load influencer profile");
        toast({
          variant: "destructive",
          title: "Error",
          description: "Failed to load influencer profile",
        });
      } finally {
        setIsLoading(false);
      }
    };

    fetchInfluencerProfile();
  }, [influencerId]);

  const getPlatformIcon = (platform: string) => {
    switch (platform.toLowerCase()) {
      case "instagram":
        return Instagram;
      case "youtube":
        return Youtube;
      case "twitter":
        return Twitter;
      case "facebook":
        return Facebook;
      case "linkedin":
        return Linkedin;
      case "tiktok":
        return () => <div className="h-4 w-4 bg-black rounded-sm" />;
      default:
        return Globe;
    }
  };

  const getPlatformColor = (platform: string) => {
    switch (platform.toLowerCase()) {
      case "instagram":
        return "text-pink-600";
      case "youtube":
        return "text-red-600";
      case "twitter":
        return "text-blue-500";
      case "facebook":
        return "text-blue-600";
      case "linkedin":
        return "text-blue-700";
      case "tiktok":
        return "text-black";
      default:
        return "text-gray-600";
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active":
        return "bg-green-100 text-green-800";
      case "pending":
        return "bg-yellow-100 text-yellow-800";
      case "rejected":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const formatNumber = (num: number) => {
    if (num >= 1000000) {
      return (num / 1000000).toFixed(1) + "M";
    }
    if (num >= 1000) {
      return (num / 1000).toFixed(1) + "K";
    }
    return num.toString();
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="h-8 w-8 animate-spin mx-auto mb-4" />
          <p className="text-gray-600">Loading influencer profile...</p>
        </div>
      </div>
    );
  }

  if (error || !influencer) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <p className="text-red-600 mb-4">{error || "Influencer not found"}</p>
          <Button onClick={() => navigate("/admin")} variant="outline">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Admin Dashboard
          </Button>
        </div>
      </div>
    );
  }

  const totalFollowers =
    influencer.socialPlatforms?.reduce(
      (total, platform) => total + platform.followerCount,
      0
    ) || 0;

  const averageEngagement = influencer.socialPlatforms?.length
    ? influencer.socialPlatforms.reduce(
        (total, platform) => total + (platform.engagementRate || 0),
        0
      ) / influencer.socialPlatforms.length
    : 0;

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-6">
          <Button
            onClick={() => navigate("/admin")}
            variant="outline"
            className="mb-4"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Admin Dashboard
          </Button>
          <div className="flex items-center space-x-4">
            <Avatar className="h-16 w-16">
              <AvatarImage
                src={influencer.profileImage}
                alt={influencer.name}
              />
              <AvatarFallback className="text-lg">
                {influencer.name.charAt(0)}
              </AvatarFallback>
            </Avatar>
            <div>
              <h1 className="text-3xl font-bold text-gray-900">
                {influencer.name}
              </h1>
              <div className="flex items-center space-x-2 mt-2">
                <Badge variant="outline">{influencer.role}</Badge>
                <Badge className={getStatusColor("active")}>
                  {influencer.isActive ? "Active" : "Inactive"}
                </Badge>
                <Badge
                  variant={influencer.isEmailVerified ? "default" : "secondary"}
                >
                  {influencer.isEmailVerified ? "Verified" : "Unverified"}
                </Badge>
              </div>
              {influencer.location && (
                <div className="flex items-center space-x-1 mt-1 text-gray-600">
                  <MapPin className="h-4 w-4" />
                  <span>
                    {[influencer.location.city, influencer.location.country]
                      .filter(Boolean)
                      .join(", ")}
                  </span>
                </div>
              )}
            </div>
          </div>
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Main Profile Information */}
          <div className="lg:col-span-2 space-y-6">
            {/* Basic Information */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <User className="h-5 w-5" />
                  <span>Profile Information</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h4 className="font-medium text-gray-900 mb-2">Email</h4>
                  <p className="text-gray-600">{influencer.email}</p>
                </div>

                {influencer.bio && (
                  <div>
                    <h4 className="font-medium text-gray-900 mb-2">Bio</h4>
                    <p className="text-gray-600">{influencer.bio}</p>
                  </div>
                )}

                {influencer.categories && influencer.categories.length > 0 && (
                  <div>
                    <h4 className="font-medium text-gray-900 mb-2">
                      Categories
                    </h4>
                    <div className="flex flex-wrap gap-2">
                      {influencer.categories.map((category) => (
                        <Badge key={category} variant="outline">
                          {category}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}

                {influencer.tags && influencer.tags.length > 0 && (
                  <div>
                    <h4 className="font-medium text-gray-900 mb-2">Tags</h4>
                    <div className="flex flex-wrap gap-2">
                      {influencer.tags.map((tag) => (
                        <Badge key={tag} variant="outline" className="text-xs">
                          {tag}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}

                {influencer.languages && influencer.languages.length > 0 && (
                  <div>
                    <h4 className="font-medium text-gray-900 mb-2">
                      Languages
                    </h4>
                    <div className="flex flex-wrap gap-2">
                      {influencer.languages.map((language) => (
                        <Badge
                          key={language}
                          variant="outline"
                          className="text-xs"
                        >
                          {language}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Social Platforms */}
            {influencer.socialPlatforms &&
              influencer.socialPlatforms.length > 0 && (
                <Card>
                  <CardHeader>
                    <CardTitle>Social Media Platforms</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid gap-4">
                      {influencer.socialPlatforms.map((platform, index) => {
                        const PlatformIcon = getPlatformIcon(platform.platform);
                        return (
                          <div
                            key={index}
                            className="flex items-center justify-between p-4 border rounded-lg"
                          >
                            <div className="flex items-center space-x-3">
                              <PlatformIcon
                                className={`h-6 w-6 ${getPlatformColor(
                                  platform.platform
                                )}`}
                              />
                              <div>
                                <h4 className="font-medium capitalize">
                                  {platform.platform}
                                </h4>
                                <p className="text-sm text-gray-600">
                                  @{platform.username}
                                </p>
                                {platform.profileUrl && (
                                  <a
                                    href={platform.profileUrl}
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    className="text-blue-600 hover:underline text-sm flex items-center space-x-1"
                                  >
                                    <span>View Profile</span>
                                    <ExternalLink className="h-3 w-3" />
                                  </a>
                                )}
                              </div>
                            </div>
                            <div className="text-right">
                              <div className="flex items-center space-x-1">
                                <Users className="h-4 w-4 text-gray-500" />
                                <span className="font-medium">
                                  {formatNumber(platform.followerCount)}
                                </span>
                              </div>
                              {platform.engagementRate && (
                                <div className="flex items-center space-x-1 text-sm text-gray-600">
                                  <TrendingUp className="h-3 w-3" />
                                  <span>
                                    {platform.engagementRate.toFixed(1)}%
                                  </span>
                                </div>
                              )}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </CardContent>
                </Card>
              )}

            {/* Content Types */}
            {influencer.contentTypes && influencer.contentTypes.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle>Content Types</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-2">
                    {influencer.contentTypes.map((type) => (
                      <Badge key={type} variant="outline">
                        {type.replace("-", " ")}
                      </Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Collaboration Types */}
            {influencer.collaborationTypes &&
              influencer.collaborationTypes.length > 0 && (
                <Card>
                  <CardHeader>
                    <CardTitle>Collaboration Types</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex flex-wrap gap-2">
                      {influencer.collaborationTypes.map((type) => (
                        <Badge key={type} variant="outline">
                          {type.replace("-", " ")}
                        </Badge>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}

            {/* Past Brands */}
            {influencer.pastBrands && influencer.pastBrands.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle>Past Brand Collaborations</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {influencer.pastBrands.map((brand, index) => (
                      <div
                        key={index}
                        className="flex items-center justify-between p-3 bg-gray-50 rounded-lg"
                      >
                        <div>
                          <h4 className="font-medium">{brand.name}</h4>
                          <p className="text-sm text-gray-600">
                            {brand.category} • {brand.collaborationType}
                          </p>
                        </div>
                        <span className="text-sm text-gray-500">
                          {brand.year}
                        </span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Sidebar Information */}
          <div className="space-y-6">
            {/* Quick Stats */}
            <Card>
              <CardHeader>
                <CardTitle>Quick Stats</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">Total Followers</span>
                  <span className="font-medium">
                    {formatNumber(totalFollowers)}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">Avg. Engagement</span>
                  <span className="font-medium">
                    {averageEngagement.toFixed(1)}%
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">Platforms</span>
                  <span className="font-medium">
                    {influencer.socialPlatforms?.length || 0}
                  </span>
                </div>
              </CardContent>
            </Card>

            {/* Performance Metrics */}
            {influencer.metrics && (
              <Card>
                <CardHeader>
                  <CardTitle>Performance Metrics</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">
                      Completed Campaigns
                    </span>
                    <span className="font-medium">
                      {influencer.metrics.completedCampaigns}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Rating</span>
                    <div className="flex items-center space-x-1">
                      <Star className="h-4 w-4 text-yellow-400 fill-current" />
                      <span className="font-medium">
                        {influencer.metrics.rating.toFixed(1)}/5.0
                      </span>
                    </div>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Response Rate</span>
                    <span className="font-medium">
                      {influencer.metrics.responseRate.toFixed(1)}%
                    </span>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Demographics */}
            {influencer.demographics && (
              <Card>
                <CardHeader>
                  <CardTitle>Demographics</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {influencer.demographics.ageGroup && (
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-600">Age Group</span>
                      <span className="font-medium">
                        {influencer.demographics.ageGroup}
                      </span>
                    </div>
                  )}
                  {influencer.demographics.gender && (
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-600">Gender</span>
                      <span className="font-medium capitalize">
                        {influencer.demographics.gender}
                      </span>
                    </div>
                  )}
                  {influencer.demographics.primaryAudience && (
                    <div>
                      <h4 className="font-medium text-gray-900 mb-2">
                        Primary Audience
                      </h4>
                      <div className="space-y-2 text-sm">
                        {influencer.demographics.primaryAudience.ageGroup && (
                          <div className="flex justify-between">
                            <span className="text-gray-600">Age</span>
                            <span>
                              {influencer.demographics.primaryAudience.ageGroup}
                            </span>
                          </div>
                        )}
                        {influencer.demographics.primaryAudience.gender && (
                          <div className="flex justify-between">
                            <span className="text-gray-600">Gender</span>
                            <span className="capitalize">
                              {influencer.demographics.primaryAudience.gender}
                            </span>
                          </div>
                        )}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            )}

            {/* Account Details */}
            <Card>
              <CardHeader>
                <CardTitle>Account Details</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-600">Joined</span>
                  <span className="font-medium">
                    {new Date(influencer.createdAt).toLocaleDateString()}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Last Updated</span>
                  <span className="font-medium">
                    {new Date(influencer.updatedAt).toLocaleDateString()}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Status</span>
                  <Badge
                    variant={influencer.isActive ? "default" : "secondary"}
                  >
                    {influencer.isActive ? "Active" : "Inactive"}
                  </Badge>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminInfluencerProfile;
