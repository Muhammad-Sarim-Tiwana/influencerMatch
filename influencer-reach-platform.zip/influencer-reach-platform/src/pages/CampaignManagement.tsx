import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Checkbox } from "@/components/ui/checkbox";
import { useAuthStore } from "@/store/authStore";
import {
  campaignService,
  Campaign as ApiCampaign,
  CreateCampaignData,
} from "@/services/campaignService";
import { toast } from "@/hooks/use-toast";
import {
  ArrowLeft,
  Save,
  Edit,
  Calendar,
  DollarSign,
  Users,
  Eye,
  BarChart3,
  Settings,
  Target,
  Clock,
  MapPin,
  Plus,
  X,
} from "lucide-react";

const CampaignManagement = () => {
  const { campaignId } = useParams<{ campaignId: string }>();
  const navigate = useNavigate();
  const { user } = useAuthStore();
  const [campaign, setCampaign] = useState<ApiCampaign | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [editMode, setEditMode] = useState(false);
  const [formData, setFormData] = useState<Partial<CreateCampaignData>>({});

  useEffect(() => {
    if (campaignId) {
      loadCampaign();
    }
  }, [campaignId]);

  const loadCampaign = async () => {
    if (!campaignId) return;

    setIsLoading(true);
    try {
      const response = await campaignService.getCampaign(campaignId);
      const campaignData = (response as any).data || response; // Handle both structures
      setCampaign(campaignData as ApiCampaign);
      setFormData({
        title: (campaignData as any).title,
        description: (campaignData as any).description,
        category: (campaignData as any).category,
        objectives: (campaignData as any).objectives,
        timeline: (campaignData as any).timeline,
        budget: (campaignData as any).budget,
        requirements: (campaignData as any).requirements,
        visibility: (campaignData as any).visibility,
        deliverables: (campaignData as any).deliverables,
        productInfo: (campaignData as any).productInfo,
        tags: (campaignData as any).tags,
      });
    } catch (error) {
      console.error("Failed to load campaign:", error);
      toast({
        title: "Error",
        description: "Failed to load campaign details.",
        variant: "destructive",
      });
      navigate("/dashboard");
    } finally {
      setIsLoading(false);
    }
  };

  const handleStatusChange = async (newStatus: ApiCampaign["status"]) => {
    if (!campaign) return;

    try {
      await campaignService.updateCampaign(campaign.id, {
        status: newStatus,
      } as any);
      setCampaign({ ...campaign, status: newStatus });
      toast({
        title: "Success",
        description: `Campaign status updated to ${newStatus}`,
      });
    } catch (error) {
      console.error("Failed to update campaign status:", error);
      toast({
        title: "Error",
        description: "Failed to update campaign status",
        variant: "destructive",
      });
    }
  };

  const handleSaveChanges = async () => {
    if (!campaign) return;

    setIsSaving(true);
    try {
      const updateData = {
        ...formData,
        updatedAt: new Date().toISOString(),
      };

      await campaignService.updateCampaign(campaign.id, updateData);
      setCampaign({ ...campaign, ...updateData } as ApiCampaign);
      setEditMode(false);
      toast({
        title: "Success",
        description: "Campaign updated successfully",
      });
    } catch (error) {
      console.error("Failed to update campaign:", error);
      toast({
        title: "Error",
        description: "Failed to update campaign",
        variant: "destructive",
      });
    } finally {
      setIsSaving(false);
    }
  };

  const handleArrayUpdate = (
    field: string,
    value: any,
    index?: number,
    action: "add" | "remove" | "update" = "update"
  ) => {
    const currentArray = (formData as any)[field] || [];
    let newArray = [...currentArray];

    switch (action) {
      case "add":
        newArray.push(value);
        break;
      case "remove":
        newArray.splice(index!, 1);
        break;
      case "update":
        if (index !== undefined) {
          newArray[index] = value;
        }
        break;
    }

    setFormData({ ...formData, [field]: newArray });
  };

  const handleObjectUpdate = (field: string, subField: string, value: any) => {
    const currentObject = (formData as any)[field] || {};
    setFormData({
      ...formData,
      [field]: {
        ...currentObject,
        [subField]: value,
      },
    });
  };

  const handleNestedObjectUpdate = (
    field: string,
    subField: string,
    nestedField: string,
    value: any
  ) => {
    const currentObject = (formData as any)[field] || {};
    const currentSubObject = currentObject[subField] || {};
    setFormData({
      ...formData,
      [field]: {
        ...currentObject,
        [subField]: {
          ...currentSubObject,
          [nestedField]: value,
        },
      },
    });
  };

  const getStatusColor = (status: ApiCampaign["status"]) => {
    switch (status) {
      case "active":
        return "bg-green-100 text-green-800";
      case "draft":
        return "bg-yellow-100 text-yellow-800";
      case "completed":
        return "bg-blue-100 text-blue-800";
      case "paused":
        return "bg-orange-100 text-orange-800";
      case "cancelled":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const formatBudget = (budget: ApiCampaign["budget"]) => {
    if (!budget.amount) return "Negotiable";

    const { min, max } = budget.amount;
    if (min && max) {
      return `${
        budget.currency
      } ${min.toLocaleString()} - ${max.toLocaleString()}`;
    } else if (min) {
      return `${budget.currency} ${min.toLocaleString()}+`;
    } else if (max) {
      return `${budget.currency} ${max.toLocaleString()} max`;
    }
    return "Negotiable";
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading campaign...</p>
        </div>
      </div>
    );
  }

  if (!campaign) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <p className="text-gray-600 mb-4">Campaign not found</p>
          <Button onClick={() => navigate("/dashboard")}>
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Dashboard
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center">
            <Button
              variant="outline"
              onClick={() => navigate("/dashboard")}
              className="mr-4"
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Dashboard
            </Button>
            <div>
              <h1 className="text-3xl font-bold text-gray-900">
                Campaign Management
              </h1>
              <p className="text-gray-600">
                Manage and edit your campaign details
              </p>
            </div>
          </div>
          <div className="flex items-center space-x-3">
            <Badge className={getStatusColor(campaign.status)}>
              {campaign.status}
            </Badge>
            {!editMode ? (
              <Button onClick={() => setEditMode(true)}>
                <Edit className="mr-2 h-4 w-4" />
                Edit Campaign
              </Button>
            ) : (
              <div className="flex space-x-2">
                <Button variant="outline" onClick={() => setEditMode(false)}>
                  Cancel
                </Button>
                <Button onClick={handleSaveChanges} disabled={isSaving}>
                  <Save className="mr-2 h-4 w-4" />
                  {isSaving ? "Saving..." : "Save Changes"}
                </Button>
              </div>
            )}
          </div>
        </div>

        {/* Campaign Status Management */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Settings className="mr-2 h-5 w-5" />
              Campaign Status
            </CardTitle>
            <CardDescription>
              Change your campaign status to control its visibility and state
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center space-x-4">
              <div>
                <Label htmlFor="status">Current Status</Label>
                <Select
                  value={campaign.status}
                  onValueChange={handleStatusChange}
                >
                  <SelectTrigger className="w-48">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="draft">Draft</SelectItem>
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="paused">Paused</SelectItem>
                    <SelectItem value="completed">Completed</SelectItem>
                    <SelectItem value="cancelled">Cancelled</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="text-sm text-gray-600">
                <div className="font-medium mb-1">Status Guide:</div>
                <div>
                  <span className="font-medium">Draft:</span> Hidden from
                  influencers, editable
                </div>
                <div>
                  <span className="font-medium">Active:</span> Visible to
                  influencers, accepting applications
                </div>
                <div>
                  <span className="font-medium">Paused:</span> Visible but not
                  accepting new applications
                </div>
                <div>
                  <span className="font-medium">Completed:</span> Campaign
                  finished successfully
                </div>
                <div>
                  <span className="font-medium">Cancelled:</span> Campaign
                  terminated early
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Campaign Stats */}
        <div className="grid md:grid-cols-5 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Views</CardTitle>
              <Eye className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{campaign.metrics.views}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                Applications
              </CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {campaign.metrics.applications}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Accepted</CardTitle>
              <Target className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {campaign.metrics.accepted}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Completed</CardTitle>
              <BarChart3 className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {campaign.metrics.completed}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Budget</CardTitle>
              <DollarSign className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-xl font-bold">
                {formatBudget(campaign.budget)}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Campaign Details Tabs */}
        <Tabs defaultValue="details" className="w-full">
          <TabsList className="grid w-full grid-cols-6">
            <TabsTrigger value="details">Campaign Details</TabsTrigger>
            <TabsTrigger value="product">Product Info</TabsTrigger>
            <TabsTrigger value="requirements">Requirements</TabsTrigger>
            <TabsTrigger value="timeline">Timeline</TabsTrigger>
            <TabsTrigger value="budget">Budget</TabsTrigger>
            <TabsTrigger value="deliverables">Deliverables</TabsTrigger>
          </TabsList>

          <TabsContent value="details" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Basic Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="title">Campaign Title</Label>
                  {editMode ? (
                    <Input
                      id="title"
                      value={formData.title || ""}
                      onChange={(e) =>
                        setFormData({ ...formData, title: e.target.value })
                      }
                    />
                  ) : (
                    <p className="text-lg font-medium">{campaign.title}</p>
                  )}
                </div>

                <div>
                  <Label htmlFor="description">Description</Label>
                  {editMode ? (
                    <Textarea
                      id="description"
                      value={formData.description || ""}
                      onChange={(e) =>
                        setFormData({
                          ...formData,
                          description: e.target.value,
                        })
                      }
                      rows={4}
                    />
                  ) : (
                    <p className="text-gray-700">{campaign.description}</p>
                  )}
                </div>

                <div>
                  <Label htmlFor="category">Category</Label>
                  {editMode ? (
                    <Select
                      value={formData.category || campaign.category}
                      onValueChange={(value) =>
                        setFormData({ ...formData, category: value as any })
                      }
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="lifestyle">Lifestyle</SelectItem>
                        <SelectItem value="fashion">Fashion</SelectItem>
                        <SelectItem value="beauty">Beauty</SelectItem>
                        <SelectItem value="fitness">Fitness</SelectItem>
                        <SelectItem value="food">Food</SelectItem>
                        <SelectItem value="travel">Travel</SelectItem>
                        <SelectItem value="technology">Technology</SelectItem>
                        <SelectItem value="brand">Brand</SelectItem>
                        <SelectItem value="entertainment">
                          Entertainment
                        </SelectItem>
                        <SelectItem value="other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                  ) : (
                    <Badge variant="secondary" className="capitalize">
                      {campaign.category}
                    </Badge>
                  )}
                </div>

                <div>
                  <Label>Visibility</Label>
                  {editMode ? (
                    <Select
                      value={formData.visibility || campaign.visibility}
                      onValueChange={(value) =>
                        setFormData({ ...formData, visibility: value as any })
                      }
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="public">Public</SelectItem>
                        <SelectItem value="private">Private</SelectItem>
                        <SelectItem value="invited-only">
                          Invited Only
                        </SelectItem>
                      </SelectContent>
                    </Select>
                  ) : (
                    <Badge variant="outline" className="capitalize">
                      {campaign.visibility}
                    </Badge>
                  )}
                </div>

                <div>
                  <Label>Campaign Objectives</Label>
                  {editMode ? (
                    <div className="space-y-2">
                      <div className="flex flex-wrap gap-2">
                        {[
                          "brand-awareness",
                          "lead-generation",
                          "sales-conversion",
                          "engagement",
                          "content-creation",
                          "event-promotion",
                          "product-launch",
                          "app-downloads",
                          "website-traffic",
                          "social-media-growth",
                        ].map((objective) => (
                          <div
                            key={objective}
                            className="flex items-center space-x-2"
                          >
                            <Checkbox
                              id={objective}
                              checked={(formData.objectives || []).includes(
                                objective as any
                              )}
                              onCheckedChange={(checked) => {
                                const currentObjectives =
                                  formData.objectives || [];
                                if (checked) {
                                  setFormData({
                                    ...formData,
                                    objectives: [
                                      ...currentObjectives,
                                      objective as any,
                                    ],
                                  });
                                } else {
                                  setFormData({
                                    ...formData,
                                    objectives: currentObjectives.filter(
                                      (obj) => obj !== objective
                                    ),
                                  });
                                }
                              }}
                            />
                            <Label
                              htmlFor={objective}
                              className="text-sm capitalize"
                            >
                              {objective.replace("-", " ")}
                            </Label>
                          </div>
                        ))}
                      </div>
                    </div>
                  ) : (
                    <div className="flex flex-wrap gap-2 mt-2">
                      {campaign.objectives && campaign.objectives.length > 0 ? (
                        campaign.objectives.map((objective, index) => (
                          <Badge
                            key={index}
                            variant="secondary"
                            className="capitalize"
                          >
                            {objective.replace("-", " ")}
                          </Badge>
                        ))
                      ) : (
                        <p className="text-gray-500">No objectives specified</p>
                      )}
                    </div>
                  )}
                </div>

                <div>
                  <Label>Tags</Label>
                  {editMode ? (
                    <div className="space-y-2">
                      {(formData.tags || []).map((tag, index) => (
                        <div key={index} className="flex gap-2">
                          <Input
                            value={tag}
                            onChange={(e) => {
                              const newTags = [...(formData.tags || [])];
                              newTags[index] = e.target.value;
                              setFormData({ ...formData, tags: newTags });
                            }}
                            placeholder="Enter tag"
                          />
                          <Button
                            type="button"
                            variant="outline"
                            size="sm"
                            onClick={() => {
                              const newTags = [...(formData.tags || [])];
                              newTags.splice(index, 1);
                              setFormData({ ...formData, tags: newTags });
                            }}
                          >
                            <X className="h-4 w-4" />
                          </Button>
                        </div>
                      ))}
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          const newTags = [...(formData.tags || []), ""];
                          setFormData({ ...formData, tags: newTags });
                        }}
                      >
                        <Plus className="h-4 w-4 mr-2" />
                        Add Tag
                      </Button>
                    </div>
                  ) : (
                    <div className="flex flex-wrap gap-2 mt-2">
                      {campaign.tags && campaign.tags.length > 0 ? (
                        campaign.tags.map((tag, index) => (
                          <Badge key={index} variant="outline">
                            {tag}
                          </Badge>
                        ))
                      ) : (
                        <p className="text-gray-500">No tags specified</p>
                      )}
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="product" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Product Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label>Product Name</Label>
                  {editMode ? (
                    <Input
                      value={formData.productInfo?.name || ""}
                      onChange={(e) =>
                        handleObjectUpdate(
                          "productInfo",
                          "name",
                          e.target.value
                        )
                      }
                      placeholder="Enter product name"
                    />
                  ) : (
                    <p className="text-lg font-medium">
                      {campaign.productInfo?.name || "Not specified"}
                    </p>
                  )}
                </div>

                <div>
                  <Label>Product Description</Label>
                  {editMode ? (
                    <Textarea
                      value={formData.productInfo?.description || ""}
                      onChange={(e) =>
                        handleObjectUpdate(
                          "productInfo",
                          "description",
                          e.target.value
                        )
                      }
                      placeholder="Enter product description"
                      rows={3}
                    />
                  ) : (
                    <p className="text-gray-700">
                      {campaign.productInfo?.description || "Not specified"}
                    </p>
                  )}
                </div>

                <div>
                  <Label>Price</Label>
                  {editMode ? (
                    <Input
                      type="number"
                      value={formData.productInfo?.price || ""}
                      onChange={(e) =>
                        handleObjectUpdate(
                          "productInfo",
                          "price",
                          parseFloat(e.target.value) || 0
                        )
                      }
                      placeholder="Enter price"
                    />
                  ) : (
                    <p className="text-lg font-medium">
                      {campaign.productInfo?.price
                        ? `$${campaign.productInfo.price}`
                        : "Not specified"}
                    </p>
                  )}
                </div>

                <div>
                  <Label>Product URLs</Label>
                  {editMode ? (
                    <div className="space-y-2">
                      {(formData.productInfo?.urls || []).map((url, index) => (
                        <div key={index} className="flex gap-2">
                          <Input
                            value={url}
                            onChange={(e) => {
                              const newUrls = [
                                ...(formData.productInfo?.urls || []),
                              ];
                              newUrls[index] = e.target.value;
                              handleObjectUpdate(
                                "productInfo",
                                "urls",
                                newUrls
                              );
                            }}
                            placeholder="Enter URL"
                          />
                          <Button
                            type="button"
                            variant="outline"
                            size="sm"
                            onClick={() => {
                              const newUrls = [
                                ...(formData.productInfo?.urls || []),
                              ];
                              newUrls.splice(index, 1);
                              handleObjectUpdate(
                                "productInfo",
                                "urls",
                                newUrls
                              );
                            }}
                          >
                            <X className="h-4 w-4" />
                          </Button>
                        </div>
                      ))}
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          const newUrls = [
                            ...(formData.productInfo?.urls || []),
                            "",
                          ];
                          handleObjectUpdate("productInfo", "urls", newUrls);
                        }}
                      >
                        <Plus className="h-4 w-4 mr-2" />
                        Add URL
                      </Button>
                    </div>
                  ) : (
                    <div className="space-y-2 mt-2">
                      {campaign.productInfo?.urls &&
                      campaign.productInfo.urls.length > 0 ? (
                        campaign.productInfo.urls.map((url, index) => (
                          <a
                            key={index}
                            href={url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-blue-600 hover:underline block"
                          >
                            {url}
                          </a>
                        ))
                      ) : (
                        <p className="text-gray-500">No URLs specified</p>
                      )}
                    </div>
                  )}
                </div>

                <div>
                  <Label>Product Images</Label>
                  {editMode ? (
                    <div className="space-y-2">
                      {(formData.productInfo?.images || []).map(
                        (image, index) => (
                          <div key={index} className="flex gap-2">
                            <Input
                              value={image}
                              onChange={(e) => {
                                const newImages = [
                                  ...(formData.productInfo?.images || []),
                                ];
                                newImages[index] = e.target.value;
                                handleObjectUpdate(
                                  "productInfo",
                                  "images",
                                  newImages
                                );
                              }}
                              placeholder="Enter image URL"
                            />
                            <Button
                              type="button"
                              variant="outline"
                              size="sm"
                              onClick={() => {
                                const newImages = [
                                  ...(formData.productInfo?.images || []),
                                ];
                                newImages.splice(index, 1);
                                handleObjectUpdate(
                                  "productInfo",
                                  "images",
                                  newImages
                                );
                              }}
                            >
                              <X className="h-4 w-4" />
                            </Button>
                          </div>
                        )
                      )}
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          const newImages = [
                            ...(formData.productInfo?.images || []),
                            "",
                          ];
                          handleObjectUpdate(
                            "productInfo",
                            "images",
                            newImages
                          );
                        }}
                      >
                        <Plus className="h-4 w-4 mr-2" />
                        Add Image URL
                      </Button>
                    </div>
                  ) : (
                    <div>
                      {campaign.productInfo?.images &&
                      campaign.productInfo.images.length > 0 ? (
                        <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mt-2">
                          {campaign.productInfo.images.map((image, index) => (
                            <img
                              key={index}
                              src={image}
                              alt={`Product image ${index + 1}`}
                              className="w-full h-32 object-cover rounded-lg border"
                            />
                          ))}
                        </div>
                      ) : (
                        <p className="text-gray-500">No images specified</p>
                      )}
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="requirements" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Influencer Requirements</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <Label>Platforms</Label>
                    {editMode ? (
                      <div className="space-y-2">
                        <div className="flex flex-wrap gap-2">
                          {[
                            "instagram",
                            "tiktok",
                            "youtube",
                            "twitter",
                            "facebook",
                            "linkedin",
                            "twitch",
                            "snapchat",
                          ].map((platform) => (
                            <div
                              key={platform}
                              className="flex items-center space-x-2"
                            >
                              <Checkbox
                                id={platform}
                                checked={(
                                  formData.requirements?.platforms || []
                                ).includes(platform as any)}
                                onCheckedChange={(checked) => {
                                  const currentPlatforms =
                                    formData.requirements?.platforms || [];
                                  if (checked) {
                                    handleNestedObjectUpdate(
                                      "requirements",
                                      "platforms",
                                      "",
                                      [...currentPlatforms, platform as any]
                                    );
                                  } else {
                                    handleNestedObjectUpdate(
                                      "requirements",
                                      "platforms",
                                      "",
                                      currentPlatforms.filter(
                                        (p) => p !== platform
                                      )
                                    );
                                  }
                                }}
                              />
                              <Label
                                htmlFor={platform}
                                className="text-sm capitalize"
                              >
                                {platform}
                              </Label>
                            </div>
                          ))}
                        </div>
                      </div>
                    ) : (
                      <div className="flex flex-wrap gap-2 mt-2">
                        {campaign.requirements?.platforms?.map(
                          (platform, index) => (
                            <Badge key={index} variant="secondary">
                              {platform}
                            </Badge>
                          )
                        )}
                      </div>
                    )}
                  </div>

                  <div>
                    <Label>Follower Range</Label>
                    {editMode ? (
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="min-followers" className="text-sm">
                            Minimum
                          </Label>
                          <Input
                            id="min-followers"
                            type="number"
                            value={
                              formData.requirements?.followerRange?.min || ""
                            }
                            onChange={(e) =>
                              handleNestedObjectUpdate(
                                "requirements",
                                "followerRange",
                                "min",
                                parseInt(e.target.value) || undefined
                              )
                            }
                            placeholder="Min followers"
                          />
                        </div>
                        <div>
                          <Label htmlFor="max-followers" className="text-sm">
                            Maximum
                          </Label>
                          <Input
                            id="max-followers"
                            type="number"
                            value={
                              formData.requirements?.followerRange?.max || ""
                            }
                            onChange={(e) =>
                              handleNestedObjectUpdate(
                                "requirements",
                                "followerRange",
                                "max",
                                parseInt(e.target.value) || undefined
                              )
                            }
                            placeholder="Max followers"
                          />
                        </div>
                      </div>
                    ) : (
                      campaign.requirements?.followerRange && (
                        <p className="text-sm text-gray-600 mt-1">
                          {campaign.requirements.followerRange.min?.toLocaleString()}{" "}
                          {campaign.requirements.followerRange.max
                            ? `- ${campaign.requirements.followerRange.max.toLocaleString()}`
                            : "+ followers"}
                        </p>
                      )
                    )}
                  </div>

                  <div>
                    <Label>Influencer Types</Label>
                    {editMode ? (
                      <div className="space-y-2">
                        <div className="flex flex-wrap gap-2">
                          {["nano", "micro", "macro", "mega"].map((type) => (
                            <div
                              key={type}
                              className="flex items-center space-x-2"
                            >
                              <Checkbox
                                id={type}
                                checked={(
                                  formData.requirements?.influencerTypes || []
                                ).includes(type as any)}
                                onCheckedChange={(checked) => {
                                  const currentTypes =
                                    formData.requirements?.influencerTypes ||
                                    [];
                                  if (checked) {
                                    handleNestedObjectUpdate(
                                      "requirements",
                                      "influencerTypes",
                                      "",
                                      [...currentTypes, type as any]
                                    );
                                  } else {
                                    handleNestedObjectUpdate(
                                      "requirements",
                                      "influencerTypes",
                                      "",
                                      currentTypes.filter((t) => t !== type)
                                    );
                                  }
                                }}
                              />
                              <Label
                                htmlFor={type}
                                className="text-sm capitalize"
                              >
                                {type}
                              </Label>
                            </div>
                          ))}
                        </div>
                      </div>
                    ) : (
                      campaign.requirements?.influencerTypes && (
                        <div className="flex flex-wrap gap-2 mt-2">
                          {campaign.requirements.influencerTypes.map(
                            (type, index) => (
                              <Badge key={index} variant="outline">
                                {type}
                              </Badge>
                            )
                          )}
                        </div>
                      )
                    )}
                  </div>

                  <div>
                    <Label>Languages</Label>
                    {editMode ? (
                      <div className="space-y-2">
                        {(formData.requirements?.languages || []).map(
                          (language, index) => (
                            <div key={index} className="flex gap-2">
                              <Input
                                value={language}
                                onChange={(e) => {
                                  const newLanguages = [
                                    ...(formData.requirements?.languages || []),
                                  ];
                                  newLanguages[index] = e.target.value;
                                  handleNestedObjectUpdate(
                                    "requirements",
                                    "languages",
                                    "",
                                    newLanguages
                                  );
                                }}
                                placeholder="Enter language"
                              />
                              <Button
                                type="button"
                                variant="outline"
                                size="sm"
                                onClick={() => {
                                  const newLanguages = [
                                    ...(formData.requirements?.languages || []),
                                  ];
                                  newLanguages.splice(index, 1);
                                  handleNestedObjectUpdate(
                                    "requirements",
                                    "languages",
                                    "",
                                    newLanguages
                                  );
                                }}
                              >
                                <X className="h-4 w-4" />
                              </Button>
                            </div>
                          )
                        )}
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={() => {
                            const newLanguages = [
                              ...(formData.requirements?.languages || []),
                              "",
                            ];
                            handleNestedObjectUpdate(
                              "requirements",
                              "languages",
                              "",
                              newLanguages
                            );
                          }}
                        >
                          <Plus className="h-4 w-4 mr-2" />
                          Add Language
                        </Button>
                      </div>
                    ) : (
                      campaign.requirements?.languages &&
                      campaign.requirements.languages.length > 0 && (
                        <div className="flex flex-wrap gap-2 mt-2">
                          {campaign.requirements.languages.map(
                            (language, index) => (
                              <Badge key={index} variant="outline">
                                {language}
                              </Badge>
                            )
                          )}
                        </div>
                      )
                    )}
                  </div>

                  {campaign.requirements?.demographics && (
                    <div className="space-y-3">
                      <Label>Demographics</Label>

                      {campaign.requirements.demographics.ageGroups &&
                        campaign.requirements.demographics.ageGroups.length >
                          0 && (
                          <div>
                            <Label className="text-sm">Age Groups</Label>
                            <div className="flex flex-wrap gap-2 mt-1">
                              {campaign.requirements.demographics.ageGroups.map(
                                (age, index) => (
                                  <Badge
                                    key={index}
                                    variant="outline"
                                    className="text-xs"
                                  >
                                    {age}
                                  </Badge>
                                )
                              )}
                            </div>
                          </div>
                        )}

                      {campaign.requirements.demographics.genders &&
                        campaign.requirements.demographics.genders.length >
                          0 && (
                          <div>
                            <Label className="text-sm">Genders</Label>
                            <div className="flex flex-wrap gap-2 mt-1">
                              {campaign.requirements.demographics.genders.map(
                                (gender, index) => (
                                  <Badge
                                    key={index}
                                    variant="outline"
                                    className="text-xs capitalize"
                                  >
                                    {gender}
                                  </Badge>
                                )
                              )}
                            </div>
                          </div>
                        )}
                    </div>
                  )}

                  <div>
                    <Label>Verification Required</Label>
                    {editMode ? (
                      <div className="flex items-center space-x-2 mt-2">
                        <Checkbox
                          id="verification-required"
                          checked={
                            formData.requirements?.verificationRequired || false
                          }
                          onCheckedChange={(checked) =>
                            handleNestedObjectUpdate(
                              "requirements",
                              "verificationRequired",
                              "",
                              checked
                            )
                          }
                        />
                        <Label
                          htmlFor="verification-required"
                          className="text-sm"
                        >
                          Require verified influencers
                        </Label>
                      </div>
                    ) : (
                      campaign.requirements?.verificationRequired && (
                        <Badge variant="secondary" className="ml-2">
                          Yes
                        </Badge>
                      )
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="timeline" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Calendar className="mr-2 h-5 w-5" />
                  Campaign Timeline
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
                    <div>
                      <Label>Application Deadline</Label>
                      {editMode ? (
                        <Input
                          type="datetime-local"
                          value={
                            formData.timeline?.applicationDeadline
                              ? new Date(formData.timeline.applicationDeadline)
                                  .toISOString()
                                  .slice(0, 16)
                              : ""
                          }
                          onChange={(e) =>
                            handleObjectUpdate(
                              "timeline",
                              "applicationDeadline",
                              new Date(e.target.value).toISOString()
                            )
                          }
                        />
                      ) : (
                        <div className="flex items-center mt-1">
                          <Clock className="mr-2 h-4 w-4 text-gray-500" />
                          <span className="text-sm">
                            {new Date(
                              campaign.timeline.applicationDeadline
                            ).toLocaleDateString()}
                          </span>
                        </div>
                      )}
                    </div>

                    <div>
                      <Label>Campaign Start</Label>
                      {editMode ? (
                        <Input
                          type="datetime-local"
                          value={
                            formData.timeline?.campaignStart
                              ? new Date(formData.timeline.campaignStart)
                                  .toISOString()
                                  .slice(0, 16)
                              : ""
                          }
                          onChange={(e) =>
                            handleObjectUpdate(
                              "timeline",
                              "campaignStart",
                              new Date(e.target.value).toISOString()
                            )
                          }
                        />
                      ) : (
                        <div className="flex items-center mt-1">
                          <Calendar className="mr-2 h-4 w-4 text-gray-500" />
                          <span className="text-sm">
                            {new Date(
                              campaign.timeline.campaignStart
                            ).toLocaleDateString()}
                          </span>
                        </div>
                      )}
                    </div>

                    <div>
                      <Label>Campaign End</Label>
                      {editMode ? (
                        <Input
                          type="datetime-local"
                          value={
                            formData.timeline?.campaignEnd
                              ? new Date(formData.timeline.campaignEnd)
                                  .toISOString()
                                  .slice(0, 16)
                              : ""
                          }
                          onChange={(e) =>
                            handleObjectUpdate(
                              "timeline",
                              "campaignEnd",
                              new Date(e.target.value).toISOString()
                            )
                          }
                        />
                      ) : (
                        <div className="flex items-center mt-1">
                          <Calendar className="mr-2 h-4 w-4 text-gray-500" />
                          <span className="text-sm">
                            {new Date(
                              campaign.timeline.campaignEnd
                            ).toLocaleDateString()}
                          </span>
                        </div>
                      )}
                    </div>

                    <div>
                      <Label>Content Deadline</Label>
                      {editMode ? (
                        <Input
                          type="datetime-local"
                          value={
                            formData.timeline?.contentDeadline
                              ? new Date(formData.timeline.contentDeadline)
                                  .toISOString()
                                  .slice(0, 16)
                              : ""
                          }
                          onChange={(e) =>
                            handleObjectUpdate(
                              "timeline",
                              "contentDeadline",
                              e.target.value
                                ? new Date(e.target.value).toISOString()
                                : undefined
                            )
                          }
                        />
                      ) : (
                        campaign.timeline.contentDeadline && (
                          <div className="flex items-center mt-1">
                            <Clock className="mr-2 h-4 w-4 text-gray-500" />
                            <span className="text-sm">
                              {new Date(
                                campaign.timeline.contentDeadline
                              ).toLocaleDateString()}
                            </span>
                          </div>
                        )
                      )}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="budget" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <DollarSign className="mr-2 h-5 w-5" />
                  Budget Information
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <Label>Budget Type</Label>
                    {editMode ? (
                      <Select
                        value={formData.budget?.type || campaign.budget.type}
                        onValueChange={(value) =>
                          handleObjectUpdate(
                            "budget",
                            "type",
                            value as "fixed" | "negotiable" | "performance"
                          )
                        }
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="fixed">Fixed</SelectItem>
                          <SelectItem value="negotiable">Negotiable</SelectItem>
                          <SelectItem value="performance">
                            Performance
                          </SelectItem>
                        </SelectContent>
                      </Select>
                    ) : (
                      <Badge variant="secondary" className="ml-2 capitalize">
                        {campaign.budget.type}
                      </Badge>
                    )}
                  </div>

                  <div>
                    <Label>Currency</Label>
                    {editMode ? (
                      <Select
                        value={
                          formData.budget?.currency || campaign.budget.currency
                        }
                        onValueChange={(value) =>
                          handleObjectUpdate("budget", "currency", value)
                        }
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="USD">USD</SelectItem>
                          <SelectItem value="EUR">EUR</SelectItem>
                          <SelectItem value="GBP">GBP</SelectItem>
                          <SelectItem value="CAD">CAD</SelectItem>
                        </SelectContent>
                      </Select>
                    ) : (
                      <p className="text-sm text-gray-600 mt-1">
                        {campaign.budget.currency}
                      </p>
                    )}
                  </div>

                  <div>
                    <Label>Amount</Label>
                    {editMode ? (
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="min-amount" className="text-sm">
                            Minimum
                          </Label>
                          <Input
                            id="min-amount"
                            type="number"
                            value={formData.budget?.amount?.min || ""}
                            onChange={(e) =>
                              handleNestedObjectUpdate(
                                "budget",
                                "amount",
                                "min",
                                parseFloat(e.target.value) || undefined
                              )
                            }
                            placeholder="Min amount"
                          />
                        </div>
                        <div>
                          <Label htmlFor="max-amount" className="text-sm">
                            Maximum
                          </Label>
                          <Input
                            id="max-amount"
                            type="number"
                            value={formData.budget?.amount?.max || ""}
                            onChange={(e) =>
                              handleNestedObjectUpdate(
                                "budget",
                                "amount",
                                "max",
                                parseFloat(e.target.value) || undefined
                              )
                            }
                            placeholder="Max amount"
                          />
                        </div>
                      </div>
                    ) : (
                      <p className="text-lg font-medium mt-1">
                        {formatBudget(campaign.budget)}
                      </p>
                    )}
                  </div>

                  <div>
                    <Label>Payment Terms</Label>
                    {editMode ? (
                      <Textarea
                        value={formData.budget?.paymentTerms || ""}
                        onChange={(e) =>
                          handleObjectUpdate(
                            "budget",
                            "paymentTerms",
                            e.target.value
                          )
                        }
                        placeholder="Enter payment terms"
                        rows={2}
                      />
                    ) : (
                      campaign.budget.paymentTerms && (
                        <p className="text-sm text-gray-600 mt-1">
                          {campaign.budget.paymentTerms}
                        </p>
                      )
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="deliverables" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Campaign Deliverables</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {campaign.deliverables && campaign.deliverables.length > 0 ? (
                    campaign.deliverables.map((deliverable, index) => (
                      <div key={index} className="border rounded-lg p-4">
                        <div className="flex items-center justify-between mb-3">
                          <div>
                            <Badge variant="secondary" className="capitalize">
                              {deliverable.type}
                            </Badge>
                            <Badge
                              variant="outline"
                              className="ml-2 capitalize"
                            >
                              {deliverable.platform}
                            </Badge>
                          </div>
                          <div className="text-sm text-gray-600">
                            Quantity: {deliverable.quantity}
                          </div>
                        </div>

                        {deliverable.specifications && (
                          <div className="space-y-2">
                            <Label className="text-sm font-medium">
                              Specifications
                            </Label>
                            <div className="grid grid-cols-2 gap-4 text-sm">
                              {deliverable.specifications.dimensions && (
                                <div>
                                  <span className="font-medium">
                                    Dimensions:
                                  </span>{" "}
                                  {deliverable.specifications.dimensions}
                                </div>
                              )}
                              {deliverable.specifications.guidelines && (
                                <div>
                                  <span className="font-medium">
                                    Guidelines:
                                  </span>{" "}
                                  {deliverable.specifications.guidelines}
                                </div>
                              )}
                              {deliverable.specifications.hashtags &&
                                deliverable.specifications.hashtags.length >
                                  0 && (
                                  <div className="col-span-2">
                                    <span className="font-medium">
                                      Hashtags:
                                    </span>
                                    <div className="flex flex-wrap gap-1 mt-1">
                                      {deliverable.specifications.hashtags.map(
                                        (hashtag, idx) => (
                                          <span
                                            key={idx}
                                            className="text-blue-600"
                                          >
                                            #{hashtag}
                                          </span>
                                        )
                                      )}
                                    </div>
                                  </div>
                                )}
                              {deliverable.specifications.mentions &&
                                deliverable.specifications.mentions.length >
                                  0 && (
                                  <div className="col-span-2">
                                    <span className="font-medium">
                                      Mentions:
                                    </span>
                                    <div className="flex flex-wrap gap-1 mt-1">
                                      {deliverable.specifications.mentions.map(
                                        (mention, idx) => (
                                          <span
                                            key={idx}
                                            className="text-blue-600"
                                          >
                                            @{mention}
                                          </span>
                                        )
                                      )}
                                    </div>
                                  </div>
                                )}
                            </div>
                          </div>
                        )}
                      </div>
                    ))
                  ) : (
                    <p className="text-gray-500">No deliverables specified</p>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default CampaignManagement;
