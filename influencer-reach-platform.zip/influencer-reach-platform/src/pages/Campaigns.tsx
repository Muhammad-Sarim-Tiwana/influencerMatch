import { useState, useEffect } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useAuthStore } from "@/store/authStore";
import {
  campaignService,
  Campaign,
  CampaignQueryParams,
} from "@/services/campaignService";
import { toast } from "@/hooks/use-toast";
import {
  Search,
  Filter,
  Calendar,
  DollarSign,
  Building,
  Eye,
  Users,
  Target,
  Clock,
  TrendingUp,
  Plus,
  Settings,
  Edit,
  MoreHorizontal,
} from "lucide-react";
import { useNavigate } from "react-router-dom";

const Campaigns = () => {
  const { user } = useAuthStore();
  const navigate = useNavigate();
  const [campaigns, setCampaigns] = useState<Campaign[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [filters, setFilters] = useState<CampaignQueryParams>({
    status: undefined,
    category: undefined,
    sortBy: "createdAt:desc",
    page: 1,
    limit: 12,
  });
  const [totalPages, setTotalPages] = useState(1);

  useEffect(() => {
    loadCampaigns();
  }, [filters]);

  const loadCampaigns = async () => {
    setIsLoading(true);
    try {
      let response;
      if (user?.role === "brand") {
        // Brand users see only their own campaigns
        response = await campaignService.getMyCampaigns({
          sortBy: filters.sortBy,
          limit: filters.limit,
          page: filters.page,
        });
      } else {
        // Other users (influencers, etc.) see public campaigns
        response = await campaignService.getCampaigns(filters);
      }
      setCampaigns(response.results);
      setTotalPages(response.totalPages);
    } catch (error) {
      console.error("Failed to load campaigns:", error);
      toast({
        title: "Error",
        description: "Failed to load campaigns. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleFilterChange = (key: keyof CampaignQueryParams, value: any) => {
    setFilters((prev) => ({
      ...prev,
      [key]: value,
      page: 1, // Reset to first page when filtering
    }));
  };

  const handlePageChange = (page: number) => {
    setFilters((prev) => ({ ...prev, page }));
  };

  const handleStatusChange = async (
    campaignId: string,
    newStatus: Campaign["status"]
  ) => {
    if (user?.role !== "brand") return;

    try {
      await campaignService.updateCampaign(campaignId, {
        status: newStatus,
      } as any);
      setCampaigns(
        campaigns.map((campaign) =>
          campaign.id === campaignId
            ? { ...campaign, status: newStatus }
            : campaign
        )
      );
      toast({
        title: "Success",
        description: `Campaign status updated to ${newStatus}`,
      });
    } catch (error) {
      console.error("Failed to update campaign status:", error);
      toast({
        title: "Error",
        description: "Failed to update campaign status",
        variant: "destructive",
      });
    }
  };

  const getStatusColor = (status: Campaign["status"]) => {
    switch (status) {
      case "active":
        return "bg-green-100 text-green-800";
      case "draft":
        return "bg-yellow-100 text-yellow-800";
      case "completed":
        return "bg-blue-100 text-blue-800";
      case "paused":
        return "bg-orange-100 text-orange-800";
      case "cancelled":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getCategoryColor = (category: string) => {
    const colors = {
      fashion: "bg-pink-100 text-pink-800",
      beauty: "bg-purple-100 text-purple-800",
      fitness: "bg-green-100 text-green-800",
      food: "bg-orange-100 text-orange-800",
      travel: "bg-blue-100 text-blue-800",
      lifestyle: "bg-indigo-100 text-indigo-800",
      technology: "bg-gray-100 text-gray-800",
      gaming: "bg-red-100 text-red-800",
    };
    return (
      colors[category as keyof typeof colors] || "bg-gray-100 text-gray-800"
    );
  };

  const formatBudget = (budget: Campaign["budget"]) => {
    if (!budget.amount) return "Negotiable";

    const { min, max } = budget.amount;
    if (min && max) {
      return `${
        budget.currency
      } ${min.toLocaleString()} - ${max.toLocaleString()}`;
    } else if (min) {
      return `${budget.currency} ${min.toLocaleString()}+`;
    } else if (max) {
      return `${budget.currency} ${max.toLocaleString()} max`;
    }
    return "Negotiable";
  };

  const formatDate = (dateString: string | undefined | null) => {
    if (!dateString) return "Not set";

    try {
      const date = new Date(dateString);
      // Check if the date is valid
      if (isNaN(date.getTime())) return "Invalid date";

      return date.toLocaleDateString();
    } catch (error) {
      return "Invalid date";
    }
  };

  const filteredCampaigns = campaigns.filter((campaign) => {
    // Text search filter
    const matchesSearch =
      campaign.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      campaign.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      campaign.brand.companyName
        .toLowerCase()
        .includes(searchTerm.toLowerCase());

    // Status filter (only for brand users since they use getMyCampaigns)
    const matchesStatus =
      user?.role === "brand"
        ? !filters.status || campaign.status === filters.status
        : true;

    // Category filter (only for brand users since they use getMyCampaigns)
    const matchesCategory =
      user?.role === "brand"
        ? !filters.category || campaign.category === filters.category
        : true;

    return matchesSearch && matchesStatus && matchesCategory;
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading campaigns...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">
              {user?.role === "brand" ? "My Campaigns" : "Available Campaigns"}
            </h1>
            <p className="text-gray-600">
              {user?.role === "brand"
                ? "Manage your influencer marketing campaigns"
                : "Discover exciting collaboration opportunities"}
            </p>
          </div>
          {user?.role === "brand" && (
            <Button
              onClick={() => navigate("/campaigns/create")}
              className="bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700"
            >
              <Plus className="mr-2 h-4 w-4" />
              Create Campaign
            </Button>
          )}
        </div>

        {/* Search and Filters */}
        <Card className="mb-8">
          <CardContent className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <Input
                  placeholder="Search campaigns..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>

              <Select
                value={filters.status || "all"}
                onValueChange={(value) =>
                  handleFilterChange(
                    "status",
                    value === "all" ? undefined : value
                  )
                }
              >
                <SelectTrigger>
                  <SelectValue placeholder="Filter by status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="draft">Draft</SelectItem>
                  <SelectItem value="completed">Completed</SelectItem>
                  <SelectItem value="paused">Paused</SelectItem>
                  <SelectItem value="cancelled">Cancelled</SelectItem>
                </SelectContent>
              </Select>

              <Select
                value={filters.category || "all"}
                onValueChange={(value) =>
                  handleFilterChange(
                    "category",
                    value === "all" ? undefined : value
                  )
                }
              >
                <SelectTrigger>
                  <SelectValue placeholder="Filter by category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Categories</SelectItem>
                  <SelectItem value="fashion">Fashion</SelectItem>
                  <SelectItem value="beauty">Beauty</SelectItem>
                  <SelectItem value="fitness">Fitness</SelectItem>
                  <SelectItem value="food">Food</SelectItem>
                  <SelectItem value="travel">Travel</SelectItem>
                  <SelectItem value="lifestyle">Lifestyle</SelectItem>
                  <SelectItem value="technology">Technology</SelectItem>
                  <SelectItem value="gaming">Gaming</SelectItem>
                </SelectContent>
              </Select>

              <Select
                value={filters.sortBy || "createdAt:desc"}
                onValueChange={(value) => handleFilterChange("sortBy", value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Sort by" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="createdAt:desc">Newest First</SelectItem>
                  <SelectItem value="createdAt:asc">Oldest First</SelectItem>
                  <SelectItem value="title:asc">Title A-Z</SelectItem>
                  <SelectItem value="title:desc">Title Z-A</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Campaign Grid */}
        {filteredCampaigns.length === 0 ? (
          <Card>
            <CardContent className="py-16 text-center">
              <Target className="mx-auto h-12 w-12 mb-4 text-gray-300" />
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                No campaigns found
              </h3>
              <p className="text-gray-600 mb-6">
                {user?.role === "brand"
                  ? "You haven't created any campaigns yet. Start by creating your first campaign!"
                  : "No campaigns match your current filters. Try adjusting your search criteria."}
              </p>
              {user?.role === "brand" && (
                <Button onClick={() => navigate("/campaigns/create")}>
                  <Plus className="mr-2 h-4 w-4" />
                  Create Your First Campaign
                </Button>
              )}
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
            {filteredCampaigns.map((campaign) => (
              <Card
                key={campaign.id}
                className="hover:shadow-lg transition-shadow"
              >
                <CardHeader>
                  <div className="flex items-center justify-between mb-2">
                    <Badge className={getCategoryColor(campaign.category)}>
                      {campaign.category}
                    </Badge>
                    <div className="flex items-center space-x-2">
                      {user?.role === "brand" ? (
                        <Select
                          value={campaign.status}
                          onValueChange={(value) =>
                            handleStatusChange(
                              campaign.id,
                              value as Campaign["status"]
                            )
                          }
                        >
                          <SelectTrigger className="w-28 h-7 text-xs">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="draft">Draft</SelectItem>
                            <SelectItem value="active">Active</SelectItem>
                            <SelectItem value="paused">Paused</SelectItem>
                            <SelectItem value="completed">Completed</SelectItem>
                            <SelectItem value="cancelled">Cancelled</SelectItem>
                          </SelectContent>
                        </Select>
                      ) : (
                        <Badge className={getStatusColor(campaign.status)}>
                          {campaign.status}
                        </Badge>
                      )}
                      {user?.role === "brand" && (
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button
                              variant="ghost"
                              size="sm"
                              className="h-7 w-7 p-0"
                            >
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem
                              onClick={(e) => {
                                e.stopPropagation();
                                navigate(`/campaigns/manage/${campaign.id}`);
                              }}
                            >
                              <Edit className="mr-2 h-4 w-4" />
                              Manage Campaign
                            </DropdownMenuItem>
                            <DropdownMenuItem
                              onClick={(e) => {
                                e.stopPropagation();
                                navigate(`/campaigns/${campaign.id}`);
                              }}
                            >
                              <Eye className="mr-2 h-4 w-4" />
                              View Details
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      )}
                    </div>
                  </div>
                  <CardTitle
                    className="text-lg line-clamp-2 cursor-pointer hover:text-indigo-600"
                    onClick={() => navigate(`/campaigns/${campaign.id}`)}
                  >
                    {campaign.title}
                  </CardTitle>
                  <CardDescription className="line-clamp-3">
                    {campaign.description}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between text-sm">
                      <div className="flex items-center text-gray-600">
                        <Building className="h-4 w-4 mr-1" />
                        {campaign.brand.companyName}
                      </div>
                      <div className="flex items-center text-green-600">
                        <DollarSign className="h-4 w-4 mr-1" />
                        {formatBudget(campaign.budget)}
                      </div>
                    </div>

                    <div className="flex items-center justify-between text-sm">
                      <div className="flex items-center text-gray-600">
                        <Calendar className="h-4 w-4 mr-1" />
                        Due: {formatDate(campaign.timeline.applicationDeadline)}
                      </div>
                      <div className="flex items-center text-blue-600">
                        <Users className="h-4 w-4 mr-1" />
                        {campaign.metrics.applications} applied
                      </div>
                    </div>

                    {campaign.deliverables &&
                      campaign.deliverables.length > 0 && (
                        <div className="flex flex-wrap gap-1">
                          {campaign.deliverables
                            .slice(0, 3)
                            .map((deliverable, index) => (
                              <Badge
                                key={index}
                                variant="outline"
                                className="text-xs"
                              >
                                {deliverable.quantity} {deliverable.type}(s)
                              </Badge>
                            ))}
                          {campaign.deliverables.length > 3 && (
                            <Badge variant="outline" className="text-xs">
                              +{campaign.deliverables.length - 3} more
                            </Badge>
                          )}
                        </div>
                      )}

                    <div className="flex items-center justify-between pt-2">
                      <div className="flex items-center text-gray-500 text-sm">
                        <Eye className="h-4 w-4 mr-1" />
                        {campaign.metrics.views} views
                      </div>
                      <div className="flex items-center text-gray-500 text-sm">
                        <Clock className="h-4 w-4 mr-1" />
                        {formatDate(campaign.createdAt)}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="flex justify-center items-center space-x-2">
            <Button
              variant="outline"
              disabled={filters.page === 1}
              onClick={() => handlePageChange((filters.page || 1) - 1)}
            >
              Previous
            </Button>

            <div className="flex space-x-1">
              {Array.from({ length: totalPages }, (_, i) => i + 1).map(
                (page) => (
                  <Button
                    key={page}
                    variant={page === filters.page ? "default" : "outline"}
                    size="sm"
                    onClick={() => handlePageChange(page)}
                    className="w-8 h-8"
                  >
                    {page}
                  </Button>
                )
              )}
            </div>

            <Button
              variant="outline"
              disabled={filters.page === totalPages}
              onClick={() => handlePageChange((filters.page || 1) + 1)}
            >
              Next
            </Button>
          </div>
        )}
      </div>
    </div>
  );
};

export default Campaigns;
