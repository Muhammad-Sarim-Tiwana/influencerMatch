import { useState, useEffect } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { useAuthStore } from "@/store/authStore";
import {
  campaignService,
  Campaign as ApiCampaign,
} from "@/services/campaignService";
import brandService, { BrandProfile } from "@/services/brandService";
import { toast } from "@/hooks/use-toast";
import {
  Plus,
  TrendingUp,
  Users,
  DollarSign,
  Calendar,
  MapPin,
  Eye,
  MessageCircle,
  Mail,
  Phone,
  Building2,
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import BrandProfileStatus from "@/components/BrandProfileStatus";

const BrandDashboard = () => {
  const { user, users, isAuthenticated } = useAuthStore();
  const navigate = useNavigate();
  const [campaigns, setCampaigns] = useState<ApiCampaign[]>([]);
  const [brandProfile, setBrandProfile] = useState<BrandProfile | null>(null);
  const [hasBrandProfile, setHasBrandProfile] = useState<boolean | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  const influencers = users.filter(
    (u) => u.role === "influencer" && u.isActive
  );

  useEffect(() => {
    // Only check brand profile if user is authenticated
    if (user && isAuthenticated) {
      checkBrandProfile();
    }
  }, [user, isAuthenticated]);

  // Load campaigns when brand profile is set
  useEffect(() => {
    if (hasBrandProfile === true && user && isAuthenticated) {
      loadMyCampaigns();
    }
  }, [hasBrandProfile, user, isAuthenticated]);

  const checkBrandProfile = async () => {
    // Double-check authentication before making API calls
    if (!user || !isAuthenticated) {
      console.log("User not authenticated, skipping brand profile check");
      return;
    }

    setIsLoading(true);
    try {
      const profile = await brandService.getMyProfile();
      setBrandProfile(profile);
      setHasBrandProfile(true);
    } catch (error: any) {
      if (error.code === 401) {
        // Authentication error - redirect to login
        console.error("Authentication failed:", error);
        toast({
          title: "Authentication Required",
          description: "Please log in to access your brand dashboard.",
          variant: "destructive",
        });
        // The ProtectedRoute should handle this, but just in case
        window.location.href = "/auth";
        return;
      } else if (error.code === 404) {
        // No brand profile exists
        setHasBrandProfile(false);
      } else {
        console.error("Failed to check brand profile:", error);
        toast({
          title: "Error",
          description: "Failed to load brand profile. Please try again.",
          variant: "destructive",
        });
      }
    } finally {
      setIsLoading(false);
    }
  };

  const loadMyCampaigns = async (forceLoad: boolean = false) => {
    if ((!hasBrandProfile && !forceLoad) || !user || !isAuthenticated) return;

    try {
      console.log("Loading campaigns...");
      const response = await campaignService.getMyCampaigns();
      console.log("Campaigns response:", response);
      // @ts-ignore
      setCampaigns(response.results || []);
    } catch (error: any) {
      console.error("Failed to load campaigns:", error);
      if (error.code === 401) {
        toast({
          title: "Authentication Error",
          description: "Please log in again to view your campaigns.",
          variant: "destructive",
        });
        window.location.href = "/auth";
      } else {
        toast({
          title: "Error",
          description: "Failed to load your campaigns. Please try again.",
          variant: "destructive",
        });
      }
    }
  };

  const stats = {
    totalCampaigns: campaigns.length,
    activeCampaigns: campaigns.filter((c) => c.status === "active").length,
    totalBudget: campaigns.reduce((sum, c) => {
      const min = c.budget?.amount?.min || 0;
      const max = c.budget?.amount?.max || 0;
      return sum + Math.max(min, max);
    }, 0),
  };

  const getStatusColor = (status: ApiCampaign["status"]) => {
    switch (status) {
      case "active":
        return "bg-green-100 text-green-800";
      case "draft":
        return "bg-yellow-100 text-yellow-800";
      case "completed":
        return "bg-blue-100 text-blue-800";
      case "paused":
        return "bg-orange-100 text-orange-800";
      case "cancelled":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const formatBudget = (budget: ApiCampaign["budget"]) => {
    if (!budget.amount) return "Negotiable";

    const { min, max } = budget.amount;
    if (min && max) {
      return `${
        budget.currency
      } ${min.toLocaleString()} - ${max.toLocaleString()}`;
    } else if (min) {
      return `${budget.currency} ${min.toLocaleString()}+`;
    } else if (max) {
      return `${budget.currency} ${max.toLocaleString()} max`;
    }
    return "Negotiable";
  };

  // Show loading state or redirect if not authenticated
  if (!user || !isAuthenticated) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Verifying authentication...</p>
        </div>
      </div>
    );
  }

  // Show loading state
  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading your dashboard...</p>
        </div>
      </div>
    );
  }

  // Show brand profile creation if no profile exists
  if (hasBrandProfile === false) {
    return (
      <div className="min-h-screen bg-gray-50">
        <div className="container mx-auto px-4 py-8">
          <div className="max-w-2xl mx-auto">
            <Card>
              <CardHeader className="text-center">
                <CardTitle className="text-2xl">
                  Create Your Brand Profile
                </CardTitle>
                <CardDescription>
                  Complete your brand profile to start connecting with
                  influencers
                </CardDescription>
              </CardHeader>
              <CardContent className="text-center space-y-6">
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
                  <div className="flex items-center justify-center mb-4">
                    <Building2 className="h-12 w-12 text-blue-600" />
                  </div>
                  <h3 className="text-lg font-semibold text-blue-900 mb-2">
                    Complete Your Profile Setup
                  </h3>
                  <p className="text-blue-700 mb-4">
                    Tell us about your company and start your influencer
                    marketing journey. Your profile will be reviewed and
                    activated within 1-3 business days.
                  </p>
                </div>
                <div className="flex gap-3 justify-center">
                  <Button
                    onClick={() => navigate("/brand/create-profile")}
                    className="bg-blue-600 hover:bg-blue-700"
                  >
                    <Building2 className="h-4 w-4 mr-2" />
                    Create Brand Profile
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => navigate("/contact")}
                  >
                    Contact Support
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    );
  }

  console.log("!brandProfile", brandProfile);

  // Check if user account is inactive (pending approval)
  if (!user.isActive) {
    // If they have a brand profile, show the waiting page
    if (brandProfile) {
      return (
        <BrandProfileStatus
          status="pending"
          onRetry={() => navigate("/brand/create-profile")}
        />
      );
    }

    // If they don't have a brand profile yet but are inactive,
    // still allow them to create the profile (they start inactive until approved)
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">
              Brand Dashboard
            </h1>
            <p className="text-gray-600">
              Manage your campaigns and connect with influencers.
            </p>
          </div>
          <Button
            onClick={() => navigate("/campaigns/create")}
            className="bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700"
          >
            <Plus className="mr-2 h-4 w-4" />
            Create Campaign
          </Button>
        </div>

        {/* Stats Cards */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                Total Campaigns
              </CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.totalCampaigns}</div>
              <p className="text-xs text-muted-foreground">
                {stats.activeCampaigns} active
              </p>
            </CardContent>
          </Card>

          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                Total Budget
              </CardTitle>
              <DollarSign className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                ${stats.totalBudget.toLocaleString()}
              </div>
              <p className="text-xs text-muted-foreground">
                Across all campaigns
              </p>
            </CardContent>
          </Card>

          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                Available Influencers
              </CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{influencers.length}</div>
              <p className="text-xs text-muted-foreground">Active creators</p>
            </CardContent>
          </Card>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Campaigns */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Your Campaigns</CardTitle>
                  <CardDescription>
                    Manage and track your marketing campaigns
                  </CardDescription>
                </div>
                <Button
                  variant="outline"
                  onClick={() => navigate("/campaigns")}
                >
                  View All
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {isLoading ? (
                  <div className="text-center py-8 text-gray-500">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600 mx-auto mb-4"></div>
                    <p>Loading campaigns...</p>
                  </div>
                ) : campaigns.length === 0 ? (
                  <div className="text-center py-8 text-gray-500">
                    <TrendingUp className="mx-auto h-12 w-12 mb-4 text-gray-300" />
                    <p>No campaigns yet</p>
                    <p className="text-sm">
                      Create your first campaign to get started
                    </p>
                  </div>
                ) : (
                  campaigns.slice(0, 3).map((campaign) => (
                    <div
                      key={campaign.id}
                      className="border rounded-lg p-4 hover:bg-gray-50 transition-colors cursor-pointer"
                      onClick={() => navigate(`/campaigns/${campaign.id}`)}
                    >
                      <div className="flex justify-between items-start mb-2">
                        <h3 className="font-semibold">{campaign.title}</h3>
                        <Badge className={getStatusColor(campaign.status)}>
                          {campaign.status}
                        </Badge>
                      </div>
                      <p className="text-sm text-gray-600 mb-3 line-clamp-2">
                        {campaign.description}
                      </p>
                      <div className="flex items-center justify-between text-sm">
                        <div className="flex items-center space-x-4">
                          <span className="flex items-center text-green-600">
                            <DollarSign className="h-4 w-4 mr-1" />
                            {formatBudget(campaign.budget)}
                          </span>
                          <span className="flex items-center text-blue-600">
                            <Users className="h-4 w-4 mr-1" />
                            {campaign.metrics.applications} applied
                          </span>
                        </div>
                        <span className="flex items-center text-gray-500">
                          <Calendar className="h-4 w-4 mr-1" />
                          {new Date(
                            campaign.timeline.applicationDeadline
                          ).toLocaleDateString()}
                        </span>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default BrandDashboard;
