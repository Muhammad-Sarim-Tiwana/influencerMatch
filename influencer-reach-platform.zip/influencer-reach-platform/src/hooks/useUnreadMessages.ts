import { useState, useEffect } from "react";
import { firebaseChatService } from "@/services/firebaseChatService";
import { useAuthStore } from "@/store/authStore";

export const useUnreadMessages = () => {
  const { user } = useAuthStore();
  const [unreadCount, setUnreadCount] = useState(0);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (!user?.id) {
      setUnreadCount(0);
      setIsLoading(false);
      return;
    }

    // Listen to user's conversations to track unread messages
    const unsubscribe = firebaseChatService.listenToUserConversations(
      user.id,
      (conversations) => {
        const totalUnread = conversations.reduce((total, conv) => {
          return total + (conv.unreadCount[user.id] || 0);
        }, 0);

        setUnreadCount(totalUnread);
        setIsLoading(false);
      }
    );

    return unsubscribe;
  }, [user?.id]);

  const hasUnreadMessages = unreadCount > 0;

  return {
    unreadCount,
    hasUnreadMessages,
    isLoading,
  };
};
