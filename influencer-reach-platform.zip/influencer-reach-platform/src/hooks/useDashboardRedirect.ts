import { useNavigate } from "react-router-dom";
import { UserRole } from "@/store/authStore";

export const useDashboardRedirect = () => {
  const navigate = useNavigate();

  const redirectToDashboard = (role: UserRole) => {
    const getDashboardPath = (userRole: UserRole): string => {
      switch (userRole) {
        case "superadmin":
          return "/admin";
        case "brand":
          return "/brand";
        case "influencer":
          return "/influencer";
        default:
          return "/";
      }
    };

    const dashboardPath = getDashboardPath(role);
    navigate(dashboardPath, { replace: true });
  };

  return { redirectToDashboard };
};
