import React, { useEffect } from "react";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { useAuthStore } from "@/store/authStore";
import Navbar from "./components/Navbar";
import ProtectedRoute from "./components/ProtectedRoute";
import AuthRedirect from "./components/AuthRedirect";
import Home from "./pages/Home";
import About from "./pages/About";
import Contact from "./pages/Contact";
import Auth from "./pages/Auth";
import ForgotPassword from "./pages/ForgotPassword";
import ResetPassword from "./pages/ResetPassword";
import Profile from "./pages/Profile";
import AdminDashboard from "./pages/AdminDashboard";
import AdminBrandProfile from "./pages/AdminBrandProfile";
import AdminInfluencerProfile from "./pages/AdminInfluencerProfile";
import BrandDashboard from "./pages/BrandDashboard";
import BrandProfileForm from "./components/BrandProfileForm";
import InfluencerDashboard from "./pages/InfluencerDashboard";
import InfluencerProfile from "./pages/InfluencerProfile";
import Messages from "./pages/Messages";
import Campaigns from "./pages/Campaigns";
import CreateCampaign from "./pages/CreateCampaign";
import CampaignDetail from "./pages/CampaignDetail";
import CampaignManagement from "./pages/CampaignManagement";
import ApplicationsManagement from "./pages/ApplicationsManagement";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => {
  const { checkAuth, isLoading } = useAuthStore();

  // Initialize authentication on app startup
  useEffect(() => {
    const initializeAuth = async () => {
      console.log("🚀 Initializing authentication...");
      try {
        const isAuthenticated = await checkAuth();
        console.log("🔐 Authentication check result:", isAuthenticated);
      } catch (error) {
        console.error("❌ Authentication initialization failed:", error);
      }
    };

    initializeAuth();
  }, [checkAuth]);

  // Show loading spinner while checking authentication
  if (isLoading) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600"></div>
      </div>
    );
  }

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <div className="min-h-screen bg-white">
            <Navbar />
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/about" element={<About />} />
              <Route path="/contact" element={<Contact />} />

              {/* Auth Routes - Redirect authenticated users away from these */}
              <Route
                path="/auth"
                element={
                  <AuthRedirect>
                    <Auth />
                  </AuthRedirect>
                }
              />
              <Route
                path="/forgot-password"
                element={
                  <AuthRedirect>
                    <ForgotPassword />
                  </AuthRedirect>
                }
              />
              <Route
                path="/reset-password"
                element={
                  <AuthRedirect>
                    <ResetPassword />
                  </AuthRedirect>
                }
              />

              {/* Profile Routes */}
              <Route
                path="/influencer-profile/:id"
                element={<InfluencerProfile />}
              />

              {/* Protected Routes */}
              <Route
                path="/profile"
                element={
                  <ProtectedRoute>
                    <Profile />
                  </ProtectedRoute>
                }
              />

              <Route
                path="/messages"
                element={
                  <ProtectedRoute>
                    <Messages />
                  </ProtectedRoute>
                }
              />

              {/* Dashboard Routes - All protected */}
              <Route
                path="/admin"
                element={
                  <ProtectedRoute allowedRoles={["superadmin"]}>
                    <AdminDashboard />
                  </ProtectedRoute>
                }
              />

              {/* Admin Profile Routes */}
              <Route
                path="/admin/brand/:brandId"
                element={
                  <ProtectedRoute allowedRoles={["superadmin"]}>
                    <AdminBrandProfile />
                  </ProtectedRoute>
                }
              />

              <Route
                path="/admin/influencer/:influencerId"
                element={
                  <ProtectedRoute allowedRoles={["superadmin"]}>
                    <AdminInfluencerProfile />
                  </ProtectedRoute>
                }
              />

              <Route
                path="/brand"
                element={
                  <ProtectedRoute allowedRoles={["brand"]}>
                    <BrandDashboard />
                  </ProtectedRoute>
                }
              />

              <Route
                path="/dashboard"
                element={
                  <ProtectedRoute allowedRoles={["brand"]}>
                    <BrandDashboard />
                  </ProtectedRoute>
                }
              />

              <Route
                path="/influencer"
                element={
                  <ProtectedRoute allowedRoles={["influencer"]}>
                    <InfluencerDashboard />
                  </ProtectedRoute>
                }
              />

              {/* Campaign Routes */}
              <Route
                path="/campaigns"
                element={
                  <ProtectedRoute>
                    <Campaigns />
                  </ProtectedRoute>
                }
              />

              <Route
                path="/campaigns/create"
                element={
                  <ProtectedRoute allowedRoles={["brand"]}>
                    <CreateCampaign />
                  </ProtectedRoute>
                }
              />

              <Route
                path="/campaigns/:campaignId"
                element={
                  <ProtectedRoute>
                    <CampaignDetail />
                  </ProtectedRoute>
                }
              />

              <Route
                path="/campaigns/manage/:campaignId"
                element={
                  <ProtectedRoute allowedRoles={["brand", "superadmin"]}>
                    <CampaignManagement />
                  </ProtectedRoute>
                }
              />

              <Route
                path="/applications"
                element={
                  <ProtectedRoute allowedRoles={["brand"]}>
                    <ApplicationsManagement />
                  </ProtectedRoute>
                }
              />

              <Route
                path="/brand/create-profile"
                element={
                  <ProtectedRoute allowedRoles={["brand"]}>
                    <BrandProfileForm />
                  </ProtectedRoute>
                }
              />

              <Route
                path="/brand/dashboard"
                element={
                  <ProtectedRoute allowedRoles={["brand"]}>
                    <BrandDashboard />
                  </ProtectedRoute>
                }
              />

              {/* Catch-all route */}
              <Route path="*" element={<NotFound />} />
            </Routes>
          </div>
        </BrowserRouter>
      </TooltipProvider>
    </QueryClientProvider>
  );
};

export default App;
