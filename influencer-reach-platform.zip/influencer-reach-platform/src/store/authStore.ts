import { create } from "zustand";
import { persist } from "zustand/middleware";
import { authService, AuthUser, SocialPlatform } from "@/services/authService";
import userService, { BackendUser } from "@/services/userService";
import brandService, { BrandProfile } from "@/services/brandService";

export type UserRole = "superadmin" | "brand" | "influencer";

// Static flag to prevent overlapping fetchBrands calls
let isFetchingBrands = false;
let lastFetchTime = 0;
const FETCH_COOLDOWN = 5000; // 5 seconds cooldown between fetches

export interface User {
  id: string;
  email: string;
  name: string;
  role: UserRole;
  avatar?: string;
  bio?: string;
  company?: string;
  followers?: number;
  location?: string;
  createdAt: Date;
  isActive: boolean;
  isEmailVerified?: boolean;
  brandProfile?: BrandProfile; // Link to brand profile
  // Influencer-specific fields
  profileImage?: string;
  socialPlatforms?: SocialPlatform[];
  tags?: string[];
  categories?: string[];
  demographics?: {
    ageGroup?: string;
    gender?: string;
    primaryAudience?: {
      ageGroup?: string;
      gender?: string;
      locations?: string[];
    };
  };
  metrics?: {
    totalFollowers?: number;
    averageEngagement?: number;
    completedCampaigns?: number;
    rating?: number;
    responseRate?: number;
  };
  pricing?: {
    postPrice?: number;
    storyPrice?: number;
    videoPrice?: number;
    packageDeals?: Array<{
      name: string;
      description: string;
      price: number;
      deliverables: string[];
    }>;
  };
  availability?: {
    status?: "available" | "busy" | "unavailable";
    nextAvailable?: string;
  };
  verificationStatus?: "pending" | "verified" | "rejected";
}

export interface Campaign {
  id: string;
  title: string;
  description: string;
  objectives?: string[];
  category: string;
  budget: {
    type: "fixed" | "negotiable" | "performance";
    amount?: {
      min?: number;
      max?: number;
    };
    currency: string;
    paymentTerms?: string;
  };
  status: "draft" | "active" | "paused" | "completed" | "cancelled";
  visibility: "public" | "private" | "invited-only";
  brandId: string;
  brandName: string;
  requirements?: {
    influencerTypes?: string[];
    followerRange?: {
      min?: number;
      max?: number;
    };
    demographics?: {
      ageGroups?: string[];
      genders?: string[];
      locations?: string[];
    };
    platforms?: string[];
  };
  timeline: {
    applicationDeadline: string;
    campaignStart: string;
    campaignEnd: string;
  };
  metrics: {
    views: number;
    applications: number;
    accepted: number;
    completed: number;
  };
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

interface AuthState {
  user: User | null;
  users: User[];
  brands: BrandProfile[];
  campaigns: Campaign[];
  isAuthenticated: boolean;
  isLoading: boolean;
  hasDataLoaded: boolean; // Flag to track if initial data has been loaded
  error: string | null;
  login: (
    email: string,
    password: string,
    role?: UserRole
  ) => Promise<{
    success: boolean;
    user?: User;
    status?: "active" | "pending_approval" | "deactivated";
    message?: string;
  }>;
  logout: () => Promise<void>;
  signup: (userData: {
    name: string;
    email: string;
    password: string;
    role?: UserRole;
    // Brand-specific fields
    company?: string;
    // Influencer-specific fields
    bio?: string;
    socialPlatforms?: Array<{
      platform:
        | "instagram"
        | "tiktok"
        | "youtube"
        | "twitter"
        | "facebook"
        | "linkedin"
        | "twitch"
        | "snapchat";
      username: string;
      followerCount?: number;
      engagementRate?: number;
      profileUrl?: string;
    }>;
    categories?: string[];
    location?: {
      country?: string;
      city?: string;
    };
    tags?: string[];
    demographics?: {
      ageGroup?: string;
      gender?: string;
      primaryAudience?: {
        ageGroup?: string;
        gender?: string;
        locations?: string[];
        interests?: string[];
        languages?: string[];
      };
    };
    languages?: string[];
    contentTypes?: string[];
    collaborationTypes?: string[];
    pricing?: {
      postPrice?: number;
      storyPrice?: number;
      videoPrice?: number;
      reelPrice?: number;
      currency?: string;
      negotiable?: boolean;
    };
    availability?: {
      status?: string;
      nextAvailable?: string;
    };
    contentStyle?: {
      visualAesthetic?: string;
      toneOfVoice?: string;
      contentFrequency?: string;
    };
  }) => Promise<{ success: boolean; user?: User; message?: string }>;
  checkAuth: () => Promise<boolean>;
  clearError: () => void;
  updateProfile: (userData: Partial<User>) => Promise<void>;
  createCampaign: (
    campaign: Omit<Campaign, "id" | "brandId" | "brandName">
  ) => void;
  updateCampaignStatus: (
    campaignId: string,
    status: Campaign["status"]
  ) => void;
  toggleUserStatus: (userId: string) => Promise<{ message: string; user: any }>;
  updateUserRole: (userId: string, role: UserRole) => void;
  applyCampaign: (campaignId: string, influencerId: string) => void;
  // New methods for fetching data from backend
  fetchUsers: () => Promise<void>;
  fetchBrands: () => Promise<void>;
  linkBrandToUser: (userId: string, brandId: string) => void;
}

const mockCampaigns: Campaign[] = [
  {
    id: "1",
    title: "Sustainable Fashion Launch",
    description:
      "Promote our new eco-friendly clothing line to fashion-conscious audiences",
    objectives: ["brand-awareness", "sales-conversion"],
    category: "fashion",
    budget: {
      type: "negotiable",
      amount: { min: 3000, max: 5000 },
      currency: "USD",
    },
    status: "active",
    visibility: "public",
    brandId: "2",
    brandName: "Tech Startup Inc.",
    requirements: {
      followerRange: { min: 50000 },
      demographics: { ageGroups: ["18-24", "25-34"] },
      platforms: ["instagram", "tiktok"],
    },
    timeline: {
      applicationDeadline: "2024-12-15",
      campaignStart: "2024-12-20",
      campaignEnd: "2024-12-31",
    },
    metrics: {
      views: 150,
      applications: 12,
      accepted: 3,
      completed: 0,
    },
    isActive: true,
    createdAt: "2024-01-01T00:00:00.000Z",
    updatedAt: "2024-01-01T00:00:00.000Z",
  },
  {
    id: "2",
    title: "Gaming Hardware Review",
    description: "Review our latest gaming peripherals for tech audiences",
    objectives: ["product-launch", "content-creation"],
    category: "technology",
    budget: {
      type: "fixed",
      amount: { min: 3000, max: 3000 },
      currency: "USD",
    },
    status: "draft",
    visibility: "public",
    brandId: "2",
    brandName: "Tech Startup Inc.",
    requirements: {
      followerRange: { min: 25000 },
      demographics: { ageGroups: ["18-24", "25-34", "35-44"] },
      platforms: ["youtube", "twitch"],
    },
    timeline: {
      applicationDeadline: "2024-11-15",
      campaignStart: "2024-11-20",
      campaignEnd: "2024-11-30",
    },
    metrics: {
      views: 75,
      applications: 8,
      accepted: 0,
      completed: 0,
    },
    isActive: true,
    createdAt: "2024-01-01T00:00:00.000Z",
    updatedAt: "2024-01-01T00:00:00.000Z",
  },
];

export const useAuthStore = create<AuthState>()(
  persist(
    (set, get) => ({
      user: null,
      users: [], // Start with empty array, will be populated from backend
      brands: [], // Start with empty array, will be populated from backend
      campaigns: mockCampaigns,
      isAuthenticated: false,
      isLoading: false,
      hasDataLoaded: false, // Track if initial data has been loaded
      error: null,

      login: async (email: string, password: string, role?: UserRole) => {
        set({ isLoading: true, error: null });

        try {
          const response = await authService.login({ email, password });

          // Convert backend user to frontend user format
          const user: User = {
            id: response.user.id,
            email: response.user.email,
            name: response.user.name,
            role: response.user.role,
            createdAt: new Date(response.user.createdAt),
            isActive: response.user.isActive || false,
            isEmailVerified: response.user.isEmailVerified,
          };

          set({
            user,
            isAuthenticated: true,
            isLoading: false,
            error: null,
          });

          // Return response with status and message for handling in UI
          return {
            success: true,
            user,
            status: response.status,
            message: response.message,
          };
        } catch (error) {
          const errorMessage =
            error instanceof Error ? error.message : "Login failed";
          set({
            isLoading: false,
            error: errorMessage,
            isAuthenticated: false,
            user: null,
          });
          return { success: false };
        }
      },

      logout: async () => {
        set({ isLoading: true });

        try {
          await authService.logout();
        } catch (error) {
          console.warn("Logout error:", error);
        } finally {
          set({
            user: null,
            isAuthenticated: false,
            isLoading: false,
            error: null,
          });
        }
      },

      signup: async (userData) => {
        set({ isLoading: true, error: null });

        try {
          const response = await authService.register({
            name: userData.name,
            email: userData.email,
            password: userData.password,
            role: userData.role || "influencer",
            // Brand-specific fields
            company: userData.company,
            // Influencer-specific fields
            bio: userData.bio,
            socialPlatforms: userData.socialPlatforms,
            categories: userData.categories,
            location: userData.location,
            tags: userData.tags,
            demographics: userData.demographics,
            languages: userData.languages,
            contentTypes: userData.contentTypes,
            collaborationTypes: userData.collaborationTypes,
            pricing: userData.pricing,
            availability: userData.availability,
            contentStyle: userData.contentStyle,
          });

          // For influencers, they will be inactive and need admin approval
          if (userData.role === "influencer") {
            set({
              isLoading: false,
              error: null,
              isAuthenticated: false,
              user: null,
            });

            return {
              success: true,
              message:
                "Registration successful! Your account is pending admin approval. You will receive an email once your account is activated.",
            };
          }

          // For brands, they can create profile but are inactive until approved
          if (userData.role === "brand") {
            const user: User = {
              id: response.user.id,
              email: response.user.email,
              name: response.user.name,
              role: response.user.role,
              createdAt: new Date(response.user.createdAt),
              isActive: response.user.isActive || false,
              isEmailVerified: response.user.isEmailVerified,
              company: userData.company,
              bio: userData.bio,
            };

            set({
              user,
              isAuthenticated: true,
              isLoading: false,
              error: null,
            });

            return {
              success: true,
              user,
              message:
                "Registration successful! Please create your brand profile to get started.",
            };
          }

          // For other roles, proceed with normal login flow
          const user: User = {
            id: response.user.id,
            email: response.user.email,
            name: response.user.name,
            role: response.user.role,
            createdAt: new Date(response.user.createdAt),
            isActive: response.user.isActive,
            isEmailVerified: response.user.isEmailVerified,
            company: userData.company,
            bio: userData.bio,
          };

          set({
            user,
            isAuthenticated: true,
            isLoading: false,
            error: null,
          });

          return { success: true, user };
        } catch (error) {
          const errorMessage =
            error instanceof Error ? error.message : "Signup failed";
          set({
            isLoading: false,
            error: errorMessage,
            isAuthenticated: false,
            user: null,
          });
          return { success: false, message: errorMessage };
        }
      },

      checkAuth: async () => {
        set({ isLoading: true });

        try {
          const isValid = await authService.checkAuth();

          if (isValid) {
            // Use userService to get complete user profile data
            const backendUser = await userService.getCurrentUser();

            // If user is a brand, try to get their brand profile
            let brandProfile = undefined;
            if (backendUser.role === "brand") {
              try {
                // Get brands and find the one associated with this user
                const brandsResponse = await brandService.getBrands({
                  limit: 100,
                  sortBy: "createdAt:desc",
                });

                if (brandsResponse?.results) {
                  brandProfile = brandsResponse.results.find(
                    (b) => b.user && b.user.id === backendUser.id
                  );
                }
              } catch (error) {
                console.warn("Failed to fetch brand profile:", error);
              }
            }

            const user: User = {
              id: backendUser.id,
              email: backendUser.email,
              name: backendUser.name,
              role: backendUser.role,
              createdAt: new Date(backendUser.createdAt),
              isActive: backendUser.isActive || false,
              isEmailVerified: backendUser.isEmailVerified,
              brandProfile: brandProfile,
              company: brandProfile?.companyName,
              // Influencer-specific fields
              bio: backendUser.bio,
              profileImage: backendUser.profileImage,
              location: backendUser.location
                ? backendUser.location.city && backendUser.location.country
                  ? `${backendUser.location.city}, ${backendUser.location.country}`
                  : backendUser.location.city || backendUser.location.country
                : undefined,
              socialPlatforms: backendUser.socialPlatforms,
              tags: backendUser.tags,
              categories: backendUser.categories,
              demographics: backendUser.demographics,
              metrics: backendUser.metrics,
              pricing: backendUser.pricing,
              availability: backendUser.availability,
              verificationStatus: backendUser.verificationStatus,
              followers: backendUser.metrics?.totalFollowers,
              avatar: backendUser.profileImage,
            };

            set({
              user,
              isAuthenticated: true,
              isLoading: false,
              error: null,
            });
            return true;
          } else {
            set({
              user: null,
              isAuthenticated: false,
              isLoading: false,
              error: null,
            });
            return false;
          }
        } catch (error) {
          console.error("Failed to check auth or load user profile:", error);
          set({
            user: null,
            isAuthenticated: false,
            isLoading: false,
            error: null,
          });
          return false;
        }
      },

      clearError: () => {
        set({ error: null });
      },

      updateProfile: async (userData) => {
        const { user } = get();
        if (!user) return;

        try {
          set({ isLoading: true, error: null });

          // Prepare data for backend API
          const updateData: any = {
            name: userData.name,
            email: userData.email,
            bio: userData.bio,
          };

          // Handle location field - convert string to object if needed
          if (userData.location) {
            if (typeof userData.location === "string") {
              const [city, country] = userData.location.split(", ");
              updateData.location = {
                city: city || userData.location,
                country: country || undefined,
              };
            } else {
              updateData.location = userData.location;
            }
          }

          // Add follower count to metrics for influencers
          if (user.role === "influencer" && userData.followers !== undefined) {
            updateData.metrics = {
              ...user.metrics,
              totalFollowers: userData.followers,
            };
          }

          // For brands, handle company field via brand profile
          if (user.role === "brand" && userData.company && user.brandProfile) {
            try {
              // Update brand profile company name
              await brandService.updateBrand(user.brandProfile.id, {
                companyName: userData.company,
              });
            } catch (error) {
              console.warn("Failed to update brand profile:", error);
            }
          }

          // Update user profile via API
          const updatedBackendUser = await userService.updateUser(
            user.id,
            updateData
          );

          // Rebuild user object with updated data
          const updatedUser: User = {
            ...user,
            name: updatedBackendUser.name,
            email: updatedBackendUser.email,
            bio: updatedBackendUser.bio,
            location: updatedBackendUser.location
              ? updatedBackendUser.location.city &&
                updatedBackendUser.location.country
                ? `${updatedBackendUser.location.city}, ${updatedBackendUser.location.country}`
                : updatedBackendUser.location.city ||
                  updatedBackendUser.location.country
              : undefined,
            followers: updatedBackendUser.metrics?.totalFollowers,
            metrics: updatedBackendUser.metrics,
            avatar: updatedBackendUser.profileImage,
            profileImage: updatedBackendUser.profileImage,
            // Update company if it was provided
            ...(userData.company && { company: userData.company }),
          };

          set((state) => ({
            user: updatedUser,
            users: state.users.map((u) => (u.id === user.id ? updatedUser : u)),
            isLoading: false,
            error: null,
          }));
        } catch (error) {
          console.error("Failed to update profile:", error);
          const errorMessage =
            error instanceof Error ? error.message : "Failed to update profile";
          set({
            isLoading: false,
            error: errorMessage,
          });
          throw error;
        }
      },

      createCampaign: (campaignData) => {
        const { user } = get();
        if (!user || user.role !== "brand") return;

        const newCampaign: Campaign = {
          ...campaignData,
          id: Date.now().toString(),
          brandId: user.id,
          brandName: user.company || user.name,
          metrics: {
            views: 0,
            applications: 0,
            accepted: 0,
            completed: 0,
          },
          isActive: true,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        };

        set((state) => ({
          campaigns: [...state.campaigns, newCampaign],
        }));
      },

      updateCampaignStatus: (campaignId, status) => {
        set((state) => ({
          campaigns: state.campaigns.map((c) =>
            c.id === campaignId ? { ...c, status } : c
          ),
        }));
      },

      toggleUserStatus: async (userId) => {
        try {
          const response = await userService.toggleUserStatus(userId);

          // Update the user in the store with the response from backend
          set((state) => ({
            users: state.users.map((u) =>
              u.id === userId
                ? {
                    ...u,
                    isActive: response.user.isActive,
                    // For influencers, also update verification status
                    ...(response.user.verificationStatus && {
                      verificationStatus: response.user.verificationStatus,
                    }),
                  }
                : u
            ),
          }));

          return response;
        } catch (error) {
          console.error("Failed to toggle user status:", error);
          throw error;
        }
      },

      updateUserRole: (userId, role) => {
        set((state) => ({
          users: state.users.map((u) => (u.id === userId ? { ...u, role } : u)),
        }));
      },

      applyCampaign: (campaignId, influencerId) => {
        set((state) => ({
          campaigns: state.campaigns.map((c) =>
            c.id === campaignId
              ? {
                  ...c,
                  metrics: {
                    ...c.metrics,
                    applications: c.metrics.applications + 1,
                  },
                }
              : c
          ),
        }));
      },

      // Backend data fetching methods
      fetchUsers: async () => {
        const currentState = get();

        // Prevent multiple calls if users are already loaded
        if (currentState.users.length > 0 && !currentState.isLoading) {
          console.log("Users already loaded, skipping fetch");
          return;
        }

        // Prevent concurrent calls
        if (currentState.isLoading) {
          console.log("Users fetch already in progress, skipping");
          return;
        }

        try {
          set({ isLoading: true });
          const response = await userService.getUsers({
            limit: 100,
            sortBy: "createdAt:desc",
          });

          console.log("response", response);

          // Convert backend users to frontend format
          const { brands } = get();
          const users: User[] = response.results.map(
            (backendUser: BackendUser) => {
              // Find associated brand profile (with null checks)
              const brandProfile = brands.find(
                (b) => b.user && b.user.id === backendUser.id
              );

              return {
                id: backendUser.id,
                email: backendUser.email,
                name: backendUser.name,
                role: backendUser.role,
                createdAt: new Date(backendUser.createdAt),
                isActive: backendUser.isActive || false,
                isEmailVerified: backendUser.isEmailVerified,
                brandProfile: brandProfile,
                company: brandProfile?.companyName,
              };
            }
          );

          set({ users, isLoading: false });
        } catch (error) {
          console.error("Failed to fetch users:", error);
          set({
            error:
              error instanceof Error ? error.message : "Failed to fetch users",
            isLoading: false,
          });
        }
      },

      fetchBrands: async () => {
        const now = Date.now();

        // Check cooldown period
        if (now - lastFetchTime < FETCH_COOLDOWN) {
          console.log(
            `fetchBrands: Cooldown active, ${
              FETCH_COOLDOWN - (now - lastFetchTime)
            }ms remaining`
          );
          return;
        }

        // Double protection: static flag + store state
        if (isFetchingBrands) {
          console.log(
            "fetchBrands: Static flag indicates already fetching, skipping call"
          );
          return;
        }

        const currentState = get();

        // Prevent multiple simultaneous calls
        if (currentState.isLoading) {
          console.log(
            "fetchBrands: Store indicates already loading, skipping call"
          );
          return;
        }

        console.log("fetchBrands called - current state:", {
          hasDataLoaded: currentState.hasDataLoaded,
          isLoading: currentState.isLoading,
          usersLength: currentState.users.length,
          brandsLength: currentState.brands.length,
        });

        try {
          isFetchingBrands = true;
          lastFetchTime = now;
          set({ isLoading: true });

          console.log("Calling brandService.getBrands...");
          const response = await brandService.getBrands({
            limit: 100,
            sortBy: "createdAt:desc",
          });

          console.log("Brand service response:", response);

          // Check if response is valid
          if (!response) {
            console.error("No response from brand service");
            throw new Error("No response from brand service");
          }

          if (!response.results) {
            console.error("Response missing results property:", response);
            // If response doesn't have results but has data, try to use it
            if (Array.isArray(response)) {
              console.log("Response is an array, using it directly");
              // Filter out invalid brand records
              const validBrands = response.filter((brand, index) => {
                if (!brand.user) {
                  console.warn(
                    `Brand at index ${index} has no user data:`,
                    brand
                  );
                  return false;
                }
                if (!brand.user.id) {
                  console.warn(
                    `Brand at index ${index} has user with no id:`,
                    brand
                  );
                  return false;
                }
                return true;
              });
              set({
                brands: validBrands,
                hasDataLoaded: true,
                isLoading: false,
              });
              return;
            }
            throw new Error(
              "Invalid response format from brand service - no results property"
            );
          }

          console.log("Brands fetched:", response.results.length);

          // Filter out invalid brand records and log warnings
          const validBrands = response.results.filter((brand, index) => {
            if (!brand.user) {
              console.warn(`Brand at index ${index} has no user data:`, brand);
              return false;
            }
            if (!brand.user.id) {
              console.warn(
                `Brand at index ${index} has user with no id:`,
                brand
              );
              return false;
            }
            return true;
          });

          console.log(
            `Filtered ${
              response.results.length - validBrands.length
            } invalid brand records`
          );
          console.log(`Valid brands: ${validBrands.length}`);

          // After fetching brands, fetch users to link them with brand profiles
          console.log("Calling userService.getUsers...");
          const usersResponse = await userService.getUsers({
            limit: 100,
            sortBy: "createdAt:desc",
          });

          console.log("User service response:", usersResponse);

          // Check if users response is valid
          if (!usersResponse) {
            console.error("No response from user service");
            throw new Error("No response from user service");
          }

          if (!usersResponse.results) {
            console.error(
              "User response missing results property:",
              usersResponse
            );
            // If response doesn't have results but has data, try to use it
            if (Array.isArray(usersResponse)) {
              console.log("User response is an array, using it directly");
              const users = usersResponse.map((backendUser: BackendUser) => ({
                id: backendUser.id,
                email: backendUser.email,
                name: backendUser.name,
                role: backendUser.role,
                createdAt: new Date(backendUser.createdAt),
                isActive: backendUser.isActive || false,
                isEmailVerified: backendUser.isEmailVerified,
              }));
              set({
                brands: validBrands,
                users,
                hasDataLoaded: true,
                isLoading: false,
              });
              return;
            }
            throw new Error(
              "Invalid response format from user service - no results property"
            );
          }

          console.log("Users fetched:", usersResponse.results.length);

          // Convert backend users to frontend format and merge with brand profiles
          const users: User[] = usersResponse.results.map(
            (backendUser: BackendUser) => {
              // Find associated brand profile (with null checks)
              const brandProfile = validBrands.find(
                (b) => b.user && b.user.id === backendUser.id
              );

              return {
                id: backendUser.id,
                email: backendUser.email,
                name: backendUser.name,
                role: backendUser.role,
                createdAt: new Date(backendUser.createdAt),
                isActive:
                  backendUser.isActive !== undefined
                    ? backendUser.isActive
                    : true,
                isEmailVerified: backendUser.isEmailVerified,
                brandProfile: brandProfile,
                company: brandProfile?.companyName,
                // Influencer-specific fields
                bio: backendUser.bio,
                profileImage: backendUser.profileImage,
                location: backendUser.location
                  ? backendUser.location.city && backendUser.location.country
                    ? `${backendUser.location.city}, ${backendUser.location.country}`
                    : backendUser.location.city || backendUser.location.country
                  : undefined,
                socialPlatforms: backendUser.socialPlatforms,
                tags: backendUser.tags,
                categories: backendUser.categories,
                demographics: backendUser.demographics,
                metrics: backendUser.metrics,
                pricing: backendUser.pricing,
                availability: backendUser.availability,
                verificationStatus: backendUser.verificationStatus,
                followers: backendUser.metrics?.totalFollowers,
                avatar: backendUser.profileImage,
              };
            }
          );

          // Set everything in one call to prevent state inconsistencies
          set({
            brands: validBrands,
            users,
            hasDataLoaded: true,
            isLoading: false,
          });

          console.log("Data loaded successfully, hasDataLoaded set to true");
        } catch (error) {
          console.error("Failed to fetch brands:", error);
          set({
            error:
              error instanceof Error ? error.message : "Failed to fetch brands",
            isLoading: false,
            hasDataLoaded: false,
          });
        } finally {
          isFetchingBrands = false;
        }
      },

      linkBrandToUser: (userId: string, brandId: string) => {
        set((state) => {
          const brand = state.brands.find((b) => b.id === brandId);
          if (!brand) return state;

          return {
            users: state.users.map((user) =>
              user.id === userId
                ? {
                    ...user,
                    brandProfile: brand,
                    company: brand.companyName,
                  }
                : user
            ),
          };
        });
      },
    }),
    {
      name: "influencer-match-auth",
      partialize: (state) => ({
        // Only persist user and auth status, not loading/error states
        user: state.user,
        isAuthenticated: state.isAuthenticated,
      }),
    }
  )
);
