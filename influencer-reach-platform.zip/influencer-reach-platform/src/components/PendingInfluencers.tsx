import { useState, useEffect } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { toast } from "@/components/ui/use-toast";
import userService, { BackendUser } from "@/services/userService";
import {
  Users,
  CheckCircle,
  XCircle,
  Eye,
  Instagram,
  Youtube,
  TrendingUp,
  MapPin,
} from "lucide-react";

interface PendingInfluencersProps {
  onStatsUpdate?: () => void;
}

const PendingInfluencers: React.FC<PendingInfluencersProps> = ({
  onStatsUpdate,
}) => {
  const [pendingInfluencers, setPendingInfluencers] = useState<BackendUser[]>(
    []
  );
  const [loading, setLoading] = useState(true);
  const [selectedInfluencer, setSelectedInfluencer] =
    useState<BackendUser | null>(null);
  const [actionLoading, setActionLoading] = useState<string | null>(null);
  const [deactivateReason, setDeactivateReason] = useState("");
  const [showDeactivateDialog, setShowDeactivateDialog] = useState(false);

  const fetchPendingInfluencers = async () => {
    try {
      setLoading(true);
      const response = await userService.getPendingInfluencers({ limit: 50 });
      setPendingInfluencers(response.results);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to fetch pending influencers",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleActivate = async (userId: string) => {
    try {
      setActionLoading(userId);
      await userService.activateInfluencer(userId);

      toast({
        title: "Success",
        description: "Influencer activated successfully",
      });

      // Refresh the list
      fetchPendingInfluencers();
      onStatsUpdate?.();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to activate influencer",
        variant: "destructive",
      });
    } finally {
      setActionLoading(null);
    }
  };

  const handleDeactivate = async (userId: string) => {
    try {
      setActionLoading(userId);
      await userService.deactivateInfluencer(userId, deactivateReason);

      toast({
        title: "Success",
        description: "Influencer rejected successfully",
      });

      // Refresh the list
      fetchPendingInfluencers();
      onStatsUpdate?.();
      setShowDeactivateDialog(false);
      setDeactivateReason("");
      setSelectedInfluencer(null);
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to reject influencer",
        variant: "destructive",
      });
    } finally {
      setActionLoading(null);
    }
  };

  useEffect(() => {
    fetchPendingInfluencers();
  }, []);

  const getPlatformIcon = (platform: string) => {
    switch (platform.toLowerCase()) {
      case "instagram":
        return <Instagram size={16} />;
      case "youtube":
        return <Youtube size={16} />;
      case "tiktok":
        return <TrendingUp size={16} />;
      default:
        return <Users size={16} />;
    }
  };

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Pending Influencer Approvals</CardTitle>
          <CardDescription>Loading...</CardDescription>
        </CardHeader>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Users size={20} />
          Pending Influencer Approvals
        </CardTitle>
        <CardDescription>
          {pendingInfluencers.length} influencers awaiting approval
        </CardDescription>
      </CardHeader>
      <CardContent>
        {pendingInfluencers.length === 0 ? (
          <div className="text-center py-8 text-gray-500">
            No pending influencers
          </div>
        ) : (
          <div className="space-y-4">
            {pendingInfluencers.map((influencer) => (
              <div key={influencer.id} className="border rounded-lg p-4">
                <div className="flex items-start justify-between">
                  <div className="flex items-start gap-4 flex-1">
                    <Avatar>
                      <AvatarImage src={influencer.profileImage} />
                      <AvatarFallback>
                        {influencer.name
                          .split(" ")
                          .map((n) => n[0])
                          .join("")
                          .toUpperCase()}
                      </AvatarFallback>
                    </Avatar>

                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <h3 className="font-semibold">{influencer.name}</h3>
                        <Badge variant="outline">
                          {influencer.verificationStatus || "pending"}
                        </Badge>
                      </div>

                      <p className="text-sm text-gray-600 mb-2">
                        {influencer.email}
                      </p>

                      {influencer.bio && (
                        <p className="text-sm mb-3">{influencer.bio}</p>
                      )}

                      {influencer.location &&
                        (influencer.location.city ||
                          influencer.location.country) && (
                          <div className="flex items-center gap-1 text-sm text-gray-600 mb-3">
                            <MapPin size={14} />
                            {[
                              influencer.location.city,
                              influencer.location.country,
                            ]
                              .filter(Boolean)
                              .join(", ")}
                          </div>
                        )}

                      {/* Social Platforms */}
                      {influencer.socialPlatforms &&
                        influencer.socialPlatforms.length > 0 && (
                          <div className="space-y-2 mb-3">
                            <h4 className="text-sm font-medium">
                              Social Platforms:
                            </h4>
                            {influencer.socialPlatforms.map(
                              (platform, index) => (
                                <div
                                  key={index}
                                  className="flex items-center gap-2 text-sm"
                                >
                                  {getPlatformIcon(platform.platform)}
                                  <span className="font-medium capitalize">
                                    {platform.platform}:
                                  </span>
                                  <span>@{platform.username}</span>
                                  <Badge variant="secondary">
                                    {(
                                      platform.followerCount || 0
                                    ).toLocaleString()}{" "}
                                    followers
                                  </Badge>
                                  {platform.engagementRate && (
                                    <Badge variant="outline">
                                      {platform.engagementRate}% engagement
                                    </Badge>
                                  )}
                                </div>
                              )
                            )}

                            <div className="text-sm font-medium text-green-600">
                              Total:{" "}
                              {influencer.metrics?.totalFollowers?.toLocaleString() ||
                                0}{" "}
                              followers
                            </div>
                          </div>
                        )}

                      {/* Categories */}
                      {influencer.categories &&
                        influencer.categories.length > 0 && (
                          <div className="mb-3">
                            <h4 className="text-sm font-medium mb-1">
                              Categories:
                            </h4>
                            <div className="flex gap-1 flex-wrap">
                              {influencer.categories.map((category, index) => (
                                <Badge
                                  key={index}
                                  variant="outline"
                                  className="text-xs"
                                >
                                  {category}
                                </Badge>
                              ))}
                            </div>
                          </div>
                        )}
                    </div>
                  </div>

                  <div className="flex gap-2 ml-4">
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button variant="outline" size="sm">
                          <Eye size={16} />
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="max-w-2xl">
                        <DialogHeader>
                          <DialogTitle>Influencer Details</DialogTitle>
                          <DialogDescription>
                            Review all information for {influencer.name}
                          </DialogDescription>
                        </DialogHeader>
                        <div className="space-y-4">
                          <div>
                            <strong>Email:</strong> {influencer.email}
                          </div>
                          <div>
                            <strong>Bio:</strong>{" "}
                            {influencer.bio || "No bio provided"}
                          </div>
                          <div>
                            <strong>Location:</strong>{" "}
                            {influencer.location
                              ? [
                                  influencer.location.city,
                                  influencer.location.country,
                                ]
                                  .filter(Boolean)
                                  .join(", ") || "Not specified"
                              : "Not specified"}
                          </div>
                          {influencer.socialPlatforms && (
                            <div>
                              <strong>Social Platforms:</strong>
                              <div className="mt-2 space-y-2">
                                {influencer.socialPlatforms.map(
                                  (platform, index) => (
                                    <div
                                      key={index}
                                      className="flex items-center gap-2 p-2 border rounded"
                                    >
                                      {getPlatformIcon(platform.platform)}
                                      <div>
                                        <div className="font-medium">
                                          {platform.platform}: @
                                          {platform.username}
                                        </div>
                                        <div className="text-sm text-gray-600">
                                          {(
                                            platform.followerCount || 0
                                          ).toLocaleString()}{" "}
                                          followers
                                          {platform.engagementRate &&
                                            ` • ${platform.engagementRate}% engagement`}
                                        </div>
                                        {platform.profileUrl && (
                                          <a
                                            href={platform.profileUrl}
                                            target="_blank"
                                            rel="noopener noreferrer"
                                            className="text-blue-500 text-sm hover:underline"
                                          >
                                            View Profile
                                          </a>
                                        )}
                                      </div>
                                    </div>
                                  )
                                )}
                              </div>
                            </div>
                          )}
                        </div>
                      </DialogContent>
                    </Dialog>

                    <Button
                      size="sm"
                      onClick={() => handleActivate(influencer.id)}
                      disabled={actionLoading === influencer.id}
                      className="bg-green-600 hover:bg-green-700"
                    >
                      {actionLoading === influencer.id ? (
                        "Processing..."
                      ) : (
                        <>
                          <CheckCircle size={16} />
                          Approve
                        </>
                      )}
                    </Button>

                    <Button
                      variant="destructive"
                      size="sm"
                      onClick={() => {
                        setSelectedInfluencer(influencer);
                        setShowDeactivateDialog(true);
                      }}
                      disabled={actionLoading === influencer.id}
                    >
                      <XCircle size={16} />
                      Reject
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Deactivate Dialog */}
        <Dialog
          open={showDeactivateDialog}
          onOpenChange={setShowDeactivateDialog}
        >
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Reject Influencer</DialogTitle>
              <DialogDescription>
                Are you sure you want to reject {selectedInfluencer?.name}? This
                action cannot be undone.
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="reason">Reason for rejection (optional)</Label>
                <Textarea
                  id="reason"
                  placeholder="Enter reason for rejection..."
                  value={deactivateReason}
                  onChange={(e) => setDeactivateReason(e.target.value)}
                />
              </div>
              <div className="flex gap-2 justify-end">
                <Button
                  variant="outline"
                  onClick={() => {
                    setShowDeactivateDialog(false);
                    setDeactivateReason("");
                    setSelectedInfluencer(null);
                  }}
                >
                  Cancel
                </Button>
                <Button
                  variant="destructive"
                  onClick={() =>
                    selectedInfluencer &&
                    handleDeactivate(selectedInfluencer.id)
                  }
                  disabled={actionLoading === selectedInfluencer?.id}
                >
                  {actionLoading === selectedInfluencer?.id
                    ? "Processing..."
                    : "Reject"}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </CardContent>
    </Card>
  );
};

export default PendingInfluencers;
