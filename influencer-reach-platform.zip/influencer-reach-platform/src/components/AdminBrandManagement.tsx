import React, { useState, useEffect, useRef } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import brandService, {
  BrandProfile,
  UpdateBrandData,
  CreateBrandData,
} from "@/services/brandService";
import userService, { BackendUser } from "@/services/userService";
import { useAuthStore } from "@/store/authStore";
import { toast } from "@/hooks/use-toast";
import {
  Building,
  Edit,
  Save,
  X,
  CheckCircle,
  AlertCircle,
  MapPin,
  Globe,
  Phone,
  Mail,
  Instagram,
  Twitter,
  Linkedin,
  Plus,
  Users,
} from "lucide-react";

const AdminBrandManagement = () => {
  const { brands, isLoading } = useAuthStore();
  const [editingBrand, setEditingBrand] = useState<string | null>(null);
  const [editFormData, setEditFormData] = useState<UpdateBrandData>({});
  const [isSaving, setIsSaving] = useState(false);
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [createFormData, setCreateFormData] = useState<CreateBrandData>({
    companyName: "",
  });
  const [isCreating, setIsCreating] = useState(false);
  const [availableUsers, setAvailableUsers] = useState<BackendUser[]>([]);
  const [selectedUserId, setSelectedUserId] = useState<string>("");
  const refreshingRef = useRef(false);

  const loadBrands = async () => {
    if (refreshingRef.current) {
      console.log("Already refreshing brands, skipping...");
      return;
    }

    refreshingRef.current = true;
    try {
      const { fetchBrands } = useAuthStore.getState();
      await fetchBrands();
    } finally {
      refreshingRef.current = false;
    }
  };

  const handleEdit = (brand: BrandProfile) => {
    setEditingBrand(brand.id);
    setEditFormData({
      companyName: brand.companyName,
      description: brand.description || "",
      website: brand.website || "",
      industry: brand.industry || "",
      contactInfo: {
        phone: brand.contactInfo?.phone || "",
        email: brand.contactInfo?.email || "",
      },
      address: {
        street: brand.address?.street || "",
        city: brand.address?.city || "",
        state: brand.address?.state || "",
        country: brand.address?.country || "",
        zipCode: brand.address?.zipCode || "",
      },
      socialMedia: {
        instagram: brand.socialMedia?.instagram || "",
        twitter: brand.socialMedia?.twitter || "",
        facebook: brand.socialMedia?.facebook || "",
        linkedin: brand.socialMedia?.linkedin || "",
        tiktok: brand.socialMedia?.tiktok || "",
        youtube: brand.socialMedia?.youtube || "",
      },
    });
  };

  const handleCancel = () => {
    setEditingBrand(null);
    setEditFormData({});
  };

  const handleSave = async (brandId: string) => {
    setIsSaving(true);
    try {
      // Filter out empty values
      const cleanedData = { ...editFormData };

      // Clean contact info
      if (cleanedData.contactInfo) {
        Object.keys(cleanedData.contactInfo).forEach((key) => {
          if (
            !cleanedData.contactInfo![
              key as keyof typeof cleanedData.contactInfo
            ]
          ) {
            delete cleanedData.contactInfo![
              key as keyof typeof cleanedData.contactInfo
            ];
          }
        });
        if (Object.keys(cleanedData.contactInfo).length === 0) {
          delete cleanedData.contactInfo;
        }
      }

      // Clean address
      if (cleanedData.address) {
        Object.keys(cleanedData.address).forEach((key) => {
          if (!cleanedData.address![key as keyof typeof cleanedData.address]) {
            delete cleanedData.address![
              key as keyof typeof cleanedData.address
            ];
          }
        });
        if (Object.keys(cleanedData.address).length === 0) {
          delete cleanedData.address;
        }
      }

      // Clean social media
      if (cleanedData.socialMedia) {
        Object.keys(cleanedData.socialMedia).forEach((key) => {
          if (
            !cleanedData.socialMedia![
              key as keyof typeof cleanedData.socialMedia
            ]
          ) {
            delete cleanedData.socialMedia![
              key as keyof typeof cleanedData.socialMedia
            ];
          }
        });
        if (Object.keys(cleanedData.socialMedia).length === 0) {
          delete cleanedData.socialMedia;
        }
      }

      await brandService.updateBrand(brandId, cleanedData);

      toast({
        title: "Success",
        description: "Brand profile updated successfully.",
      });

      setEditingBrand(null);
      setEditFormData({});
      await loadBrands(); // Refresh data after update
    } catch (error) {
      console.error("Failed to update brand:", error);
      toast({
        title: "Error",
        description: "Failed to update brand profile. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSaving(false);
    }
  };

  const handleInputChange = (field: string, value: string, nested?: string) => {
    setEditFormData((prev) => {
      if (nested) {
        const nestedObj = prev[nested as keyof typeof prev] || {};
        return {
          ...prev,
          [nested]: {
            ...(typeof nestedObj === "object" ? nestedObj : {}),
            [field]: value,
          },
        };
      }
      return {
        ...prev,
        [field]: value,
      };
    });
  };

  const loadAvailableUsers = async () => {
    try {
      const response = await userService.getUsers({ role: "brand" });
      setAvailableUsers(response.results);
    } catch (error) {
      console.error("Failed to load users:", error);
      toast({
        title: "Error",
        description: "Failed to load users. Please try again.",
        variant: "destructive",
      });
    }
  };
  const handleCreateBrand = async () => {
    if (!createFormData.companyName.trim()) {
      toast({
        title: "Error",
        description: "Company name is required.",
        variant: "destructive",
      });
      return;
    }

    if (!selectedUserId) {
      toast({
        title: "Error",
        description: "Please select a user to create the brand profile for.",
        variant: "destructive",
      });
      return;
    }

    if (!createFormData.industry) {
      toast({
        title: "Error",
        description: "Industry is required.",
        variant: "destructive",
      });
      return;
    }

    if (!createFormData.companyType) {
      toast({
        title: "Error",
        description: "Company type is required.",
        variant: "destructive",
      });
      return;
    }

    setIsCreating(true);
    try {
      await brandService.createBrandForUser(selectedUserId, createFormData);

      toast({
        title: "Success",
        description: "Brand profile created successfully.",
      });

      setIsAddDialogOpen(false);
      setCreateFormData({ companyName: "" });
      setSelectedUserId("");
      await loadBrands(); // Refresh data after creation
    } catch (error) {
      console.error("Failed to create brand:", error);
      toast({
        title: "Error",
        description: "Failed to create brand profile. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsCreating(false);
    }
  };

  const handleCreateInputChange = (
    field: string,
    value: string,
    nested?: string
  ) => {
    setCreateFormData((prev) => {
      if (nested) {
        const nestedObj = prev[nested as keyof typeof prev] || {};
        return {
          ...prev,
          [nested]: {
            ...(typeof nestedObj === "object" ? nestedObj : {}),
            [field]: value,
          },
        };
      }
      return {
        ...prev,
        [field]: value,
      };
    });
  };

  useEffect(() => {
    if (isAddDialogOpen) {
      loadAvailableUsers();
    }
  }, [isAddDialogOpen]);

  if (isLoading) {
    return (
      <div className="text-center py-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600 mx-auto mb-4"></div>
        <p className="text-gray-600">Loading brands...</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">
            Brand Profile Management
          </h2>
          <p className="text-gray-600">Manage and update brand profiles</p>
        </div>
        <div className="flex items-center gap-3">
          <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
            <DialogTrigger asChild>
              <Button className="bg-indigo-600 hover:bg-indigo-700">
                <Plus className="h-4 w-4 mr-2" />
                Add Brand
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Create New Brand Profile</DialogTitle>
                <DialogDescription>
                  Create a new brand profile for a user
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4 mt-4">
                <div>
                  <Label htmlFor="userId">Select User *</Label>
                  <Select
                    value={selectedUserId}
                    onValueChange={setSelectedUserId}
                  >
                    <SelectTrigger className="mt-1">
                      <SelectValue placeholder="Select a user to create brand profile for" />
                    </SelectTrigger>
                    <SelectContent>
                      {availableUsers
                        .filter(
                          (user) =>
                            !brands.some((brand) => brand.user.id === user.id)
                        )
                        .map((user) => (
                          <SelectItem key={user.id} value={user.id}>
                            <div className="flex items-center justify-between w-full">
                              <span>{user.name}</span>
                              <span className="text-sm text-gray-500 ml-2">
                                ({user.email})
                              </span>
                            </div>
                          </SelectItem>
                        ))}
                    </SelectContent>
                  </Select>
                  <p className="text-sm text-gray-500 mt-1">
                    Only users with brand role who don't have a brand profile
                    are shown
                  </p>
                </div>

                <div>
                  <Label htmlFor="companyName">Company Name *</Label>
                  <Input
                    id="companyName"
                    value={createFormData.companyName}
                    onChange={(e) =>
                      handleCreateInputChange("companyName", e.target.value)
                    }
                    placeholder="Enter company name"
                    className="mt-1"
                  />
                </div>

                <div>
                  <Label htmlFor="description">Description</Label>
                  <Textarea
                    id="description"
                    value={createFormData.description || ""}
                    onChange={(e) =>
                      handleCreateInputChange("description", e.target.value)
                    }
                    placeholder="Enter brand description"
                    className="mt-1"
                  />
                </div>

                <div>
                  <Label htmlFor="website">Website</Label>
                  <Input
                    id="website"
                    value={createFormData.website || ""}
                    onChange={(e) =>
                      handleCreateInputChange("website", e.target.value)
                    }
                    placeholder="https://example.com"
                    className="mt-1"
                  />
                </div>

                <div>
                  <Label htmlFor="industry">Industry *</Label>
                  <Select
                    value={createFormData.industry || ""}
                    onValueChange={(value) =>
                      handleCreateInputChange("industry", value)
                    }
                  >
                    <SelectTrigger className="mt-1">
                      <SelectValue placeholder="Select industry" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="fashion">Fashion</SelectItem>
                      <SelectItem value="beauty">Beauty</SelectItem>
                      <SelectItem value="technology">Technology</SelectItem>
                      <SelectItem value="food-beverage">
                        Food & Beverage
                      </SelectItem>
                      <SelectItem value="travel-hospitality">
                        Travel & Hospitality
                      </SelectItem>
                      <SelectItem value="fitness-health">
                        Fitness & Health
                      </SelectItem>
                      <SelectItem value="automotive">Automotive</SelectItem>
                      <SelectItem value="finance">Finance</SelectItem>
                      <SelectItem value="education">Education</SelectItem>
                      <SelectItem value="entertainment">
                        Entertainment
                      </SelectItem>
                      <SelectItem value="gaming">Gaming</SelectItem>
                      <SelectItem value="home-garden">Home & Garden</SelectItem>
                      <SelectItem value="pets">Pets</SelectItem>
                      <SelectItem value="sports">Sports</SelectItem>
                      <SelectItem value="nonprofit">Nonprofit</SelectItem>
                      <SelectItem value="b2b-services">B2B Services</SelectItem>
                      <SelectItem value="ecommerce">E-commerce</SelectItem>
                      <SelectItem value="media">Media</SelectItem>
                      <SelectItem value="healthcare">Healthcare</SelectItem>
                      <SelectItem value="real-estate">Real Estate</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="companyType">Company Type *</Label>
                  <Select
                    value={createFormData.companyType || ""}
                    onValueChange={(value) =>
                      handleCreateInputChange("companyType", value)
                    }
                  >
                    <SelectTrigger className="mt-1">
                      <SelectValue placeholder="Select company type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="startup">Startup</SelectItem>
                      <SelectItem value="small-brand">Small Brand</SelectItem>
                      <SelectItem value="medium-brand">Medium Brand</SelectItem>
                      <SelectItem value="enterprise">Enterprise</SelectItem>
                      <SelectItem value="agency">Agency</SelectItem>
                      <SelectItem value="nonprofit">Nonprofit</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="industry">Industry</Label>
                  <Input
                    id="industry"
                    value={createFormData.industry || ""}
                    onChange={(e) =>
                      handleCreateInputChange("industry", e.target.value)
                    }
                    placeholder="e.g., Technology, Fashion, Food"
                    className="mt-1"
                  />
                </div>

                <div className="flex justify-end gap-3 mt-6">
                  <Button
                    variant="outline"
                    onClick={() => setIsAddDialogOpen(false)}
                    disabled={isCreating}
                  >
                    Cancel
                  </Button>
                  <Button
                    onClick={handleCreateBrand}
                    disabled={
                      isCreating ||
                      !createFormData.companyName.trim() ||
                      !selectedUserId ||
                      !createFormData.industry ||
                      !createFormData.companyType
                    }
                  >
                    {isCreating ? "Creating..." : "Create Brand"}
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
          <Badge variant="secondary" className="text-sm">
            {brands.length} brands
          </Badge>
        </div>
      </div>

      {brands.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <Building className="h-12 w-12 text-gray-400 mb-4" />
            <p className="text-gray-600 text-center">No brand profiles found</p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-6">
          {brands.map((brand) => (
            <Card key={brand.id} className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <Avatar className="h-12 w-12">
                      <AvatarImage src={brand.logo} alt={brand.companyName} />
                      <AvatarFallback>
                        {brand.companyName
                          .split(" ")
                          .map((n) => n[0])
                          .join("")}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <CardTitle className="flex items-center space-x-2">
                        <span>{brand.companyName}</span>
                        {brand.isVerified && (
                          <CheckCircle className="h-5 w-5 text-green-500" />
                        )}
                      </CardTitle>
                      <CardDescription>
                        {brand.industry} • Created{" "}
                        {new Date(brand.createdAt).toLocaleDateString()}
                      </CardDescription>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    {editingBrand === brand.id ? (
                      <>
                        <Button
                          size="sm"
                          onClick={() => handleSave(brand.id)}
                          disabled={isSaving}
                          className="bg-green-600 hover:bg-green-700"
                        >
                          <Save className="h-4 w-4 mr-1" />
                          Save
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={handleCancel}
                          disabled={isSaving}
                        >
                          <X className="h-4 w-4 mr-1" />
                          Cancel
                        </Button>
                      </>
                    ) : (
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleEdit(brand)}
                      >
                        <Edit className="h-4 w-4 mr-1" />
                        Edit
                      </Button>
                    )}
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                {editingBrand === brand.id ? (
                  <Tabs defaultValue="basic" className="w-full">
                    <TabsList className="grid w-full grid-cols-4">
                      <TabsTrigger value="basic">Basic Info</TabsTrigger>
                      <TabsTrigger value="contact">Contact</TabsTrigger>
                      <TabsTrigger value="address">Address</TabsTrigger>
                      <TabsTrigger value="social">Social Media</TabsTrigger>
                    </TabsList>

                    <TabsContent value="basic" className="space-y-4 mt-4">
                      <div className="grid md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="companyName">Company Name</Label>
                          <Input
                            id="companyName"
                            value={editFormData.companyName || ""}
                            onChange={(e) =>
                              handleInputChange("companyName", e.target.value)
                            }
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="industry">Industry</Label>
                          <Input
                            id="industry"
                            value={editFormData.industry || ""}
                            onChange={(e) =>
                              handleInputChange("industry", e.target.value)
                            }
                          />
                        </div>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="description">Description</Label>
                        <Textarea
                          id="description"
                          value={editFormData.description || ""}
                          onChange={(e) =>
                            handleInputChange("description", e.target.value)
                          }
                          rows={3}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="website">Website</Label>
                        <Input
                          id="website"
                          type="url"
                          value={editFormData.website || ""}
                          onChange={(e) =>
                            handleInputChange("website", e.target.value)
                          }
                        />
                      </div>
                    </TabsContent>

                    <TabsContent value="contact" className="space-y-4 mt-4">
                      <div className="grid md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="phone">Phone</Label>
                          <Input
                            id="phone"
                            value={editFormData.contactInfo?.phone || ""}
                            onChange={(e) =>
                              handleInputChange(
                                "phone",
                                e.target.value,
                                "contactInfo"
                              )
                            }
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="email">Contact Email</Label>
                          <Input
                            id="email"
                            type="email"
                            value={editFormData.contactInfo?.email || ""}
                            onChange={(e) =>
                              handleInputChange(
                                "email",
                                e.target.value,
                                "contactInfo"
                              )
                            }
                          />
                        </div>
                      </div>
                    </TabsContent>

                    <TabsContent value="address" className="space-y-4 mt-4">
                      <div className="space-y-2">
                        <Label htmlFor="street">Street Address</Label>
                        <Input
                          id="street"
                          value={editFormData.address?.street || ""}
                          onChange={(e) =>
                            handleInputChange(
                              "street",
                              e.target.value,
                              "address"
                            )
                          }
                        />
                      </div>
                      <div className="grid md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="city">City</Label>
                          <Input
                            id="city"
                            value={editFormData.address?.city || ""}
                            onChange={(e) =>
                              handleInputChange(
                                "city",
                                e.target.value,
                                "address"
                              )
                            }
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="state">State/Province</Label>
                          <Input
                            id="state"
                            value={editFormData.address?.state || ""}
                            onChange={(e) =>
                              handleInputChange(
                                "state",
                                e.target.value,
                                "address"
                              )
                            }
                          />
                        </div>
                      </div>
                      <div className="grid md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="country">Country</Label>
                          <Input
                            id="country"
                            value={editFormData.address?.country || ""}
                            onChange={(e) =>
                              handleInputChange(
                                "country",
                                e.target.value,
                                "address"
                              )
                            }
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="zipCode">ZIP/Postal Code</Label>
                          <Input
                            id="zipCode"
                            value={editFormData.address?.zipCode || ""}
                            onChange={(e) =>
                              handleInputChange(
                                "zipCode",
                                e.target.value,
                                "address"
                              )
                            }
                          />
                        </div>
                      </div>
                    </TabsContent>

                    <TabsContent value="social" className="space-y-4 mt-4">
                      <div className="grid md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="instagram">Instagram</Label>
                          <Input
                            id="instagram"
                            value={editFormData.socialMedia?.instagram || ""}
                            onChange={(e) =>
                              handleInputChange(
                                "instagram",
                                e.target.value,
                                "socialMedia"
                              )
                            }
                            placeholder="@username"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="twitter">Twitter</Label>
                          <Input
                            id="twitter"
                            value={editFormData.socialMedia?.twitter || ""}
                            onChange={(e) =>
                              handleInputChange(
                                "twitter",
                                e.target.value,
                                "socialMedia"
                              )
                            }
                            placeholder="@username"
                          />
                        </div>
                      </div>
                      <div className="grid md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="linkedin">LinkedIn</Label>
                          <Input
                            id="linkedin"
                            value={editFormData.socialMedia?.linkedin || ""}
                            onChange={(e) =>
                              handleInputChange(
                                "linkedin",
                                e.target.value,
                                "socialMedia"
                              )
                            }
                            placeholder="company/username"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="facebook">Facebook</Label>
                          <Input
                            id="facebook"
                            value={editFormData.socialMedia?.facebook || ""}
                            onChange={(e) =>
                              handleInputChange(
                                "facebook",
                                e.target.value,
                                "socialMedia"
                              )
                            }
                            placeholder="username"
                          />
                        </div>
                      </div>
                    </TabsContent>
                  </Tabs>
                ) : (
                  <div className="space-y-4">
                    {/* Brand Info Display */}
                    <div className="grid md:grid-cols-2 gap-6">
                      <div className="space-y-3">
                        <div>
                          <h4 className="font-medium text-gray-900">
                            Basic Information
                          </h4>
                          <div className="mt-2 space-y-1">
                            <p className="text-sm text-gray-600">
                              Industry: {brand.industry || "Not specified"}
                            </p>
                            {brand.description && (
                              <p className="text-sm text-gray-600">
                                {brand.description}
                              </p>
                            )}
                            {brand.website && (
                              <div className="flex items-center text-sm text-blue-600">
                                <Globe className="h-4 w-4 mr-1" />
                                <a
                                  href={brand.website}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="hover:underline"
                                >
                                  {brand.website}
                                </a>
                              </div>
                            )}
                          </div>
                        </div>

                        {brand.contactInfo && (
                          <div>
                            <h4 className="font-medium text-gray-900">
                              Contact Information
                            </h4>
                            <div className="mt-2 space-y-1">
                              {brand.contactInfo.phone && (
                                <div className="flex items-center text-sm text-gray-600">
                                  <Phone className="h-4 w-4 mr-1" />
                                  {brand.contactInfo.phone}
                                </div>
                              )}
                              {brand.contactInfo.email && (
                                <div className="flex items-center text-sm text-gray-600">
                                  <Mail className="h-4 w-4 mr-1" />
                                  {brand.contactInfo.email}
                                </div>
                              )}
                            </div>
                          </div>
                        )}
                      </div>

                      <div className="space-y-3">
                        {brand.address && (
                          <div>
                            <h4 className="font-medium text-gray-900">
                              Address
                            </h4>
                            <div className="mt-2">
                              <div className="flex items-start text-sm text-gray-600">
                                <MapPin className="h-4 w-4 mr-1 mt-0.5" />
                                <div>
                                  {brand.address.street && (
                                    <div>{brand.address.street}</div>
                                  )}
                                  <div>
                                    {[brand.address.city, brand.address.state]
                                      .filter(Boolean)
                                      .join(", ")}
                                    {brand.address.zipCode &&
                                      ` ${brand.address.zipCode}`}
                                  </div>
                                  {brand.address.country && (
                                    <div>{brand.address.country}</div>
                                  )}
                                </div>
                              </div>
                            </div>
                          </div>
                        )}

                        {brand.socialMedia &&
                          Object.values(brand.socialMedia).some(Boolean) && (
                            <div>
                              <h4 className="font-medium text-gray-900">
                                Social Media
                              </h4>
                              <div className="mt-2 flex flex-wrap gap-2">
                                {brand.socialMedia.instagram && (
                                  <div className="flex items-center text-sm text-gray-600">
                                    <Instagram className="h-4 w-4 mr-1" />
                                    {brand.socialMedia.instagram}
                                  </div>
                                )}
                                {brand.socialMedia.twitter && (
                                  <div className="flex items-center text-sm text-gray-600">
                                    <Twitter className="h-4 w-4 mr-1" />
                                    {brand.socialMedia.twitter}
                                  </div>
                                )}
                                {brand.socialMedia.linkedin && (
                                  <div className="flex items-center text-sm text-gray-600">
                                    <Linkedin className="h-4 w-4 mr-1" />
                                    {brand.socialMedia.linkedin}
                                  </div>
                                )}
                              </div>
                            </div>
                          )}
                      </div>
                    </div>

                    {/* Metrics */}
                    {brand.metrics && (
                      <div className="border-t pt-4">
                        <h4 className="font-medium text-gray-900 mb-2">
                          Brand Metrics
                        </h4>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                          <div className="text-center">
                            <div className="text-2xl font-bold text-blue-600">
                              {brand.metrics.totalCampaigns || 0}
                            </div>
                            <div className="text-sm text-gray-600">
                              Total Campaigns
                            </div>
                          </div>
                          <div className="text-center">
                            <div className="text-2xl font-bold text-green-600">
                              {brand.metrics.activeCampaigns || 0}
                            </div>
                            <div className="text-sm text-gray-600">
                              Active Campaigns
                            </div>
                          </div>
                          <div className="text-center">
                            <div className="text-2xl font-bold text-purple-600">
                              $
                              {(brand.metrics.totalSpent || 0).toLocaleString()}
                            </div>
                            <div className="text-sm text-gray-600">
                              Total Spent
                            </div>
                          </div>
                          <div className="text-center">
                            <div className="text-2xl font-bold text-orange-600">
                              $
                              {(
                                brand.metrics.avgCampaignBudget || 0
                              ).toLocaleString()}
                            </div>
                            <div className="text-sm text-gray-600">
                              Avg Budget
                            </div>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
};

export default React.memo(AdminBrandManagement);
