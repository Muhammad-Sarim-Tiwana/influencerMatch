import { useState, useEffect } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "@/components/ui/carousel";
import { Skeleton } from "@/components/ui/skeleton";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { campaignService } from "@/services/campaignService";
import userService from "@/services/userService";
import { toast } from "@/hooks/use-toast";
import {
  Users,
  TrendingUp,
  Star,
  Sparkles,
  MessageCircle,
  Shield,
  Target,
  DollarSign,
  AlertTriangle,
  CheckCircle,
  Clock,
  BarChart3,
  Eye,
  Heart,
  Share2,
  Brain,
  Award,
  PieChart,
} from "lucide-react";
import { useNavigate } from "react-router-dom";

interface EnhancedRecommendationsProps {
  campaignId: string;
}

interface EnhancedRecommendation {
  id: string;
  name?: string;
  score: number;
  matchLevel?: "excellent" | "good" | "fair" | "poor";
  reasons: string[];
  strengths?: string[];
  concerns?: string[];
  recommendations?: string[];
  estimatedROI?: number;
  budgetFit?: "above" | "within" | "below";
  deliverableMatch?: {
    [key: string]: boolean;
  };
  audienceInsights?: {
    primaryDemographic: string;
    locationMatch: string;
    languageMatch: string;
    interestOverlap?: string;
    engagementQuality?: string;
  };
  performanceMetrics?: {
    avgEngagementRate: number;
    avgViewsPerPost: number;
    avgLikesPerPost: number;
    avgCommentsPerPost: number;
    bestContentType?: string;
  };
  brandCompatibility?: {
    pastBrandCategories: string[];
    brandAffinityScore: number;
    competitorConflicts: boolean;
  };
  personalityMatch?: {
    authenticity: number;
    creativity: number;
    professionalism: number;
    reliability: number;
    overallFit: string;
  };
  contentStyleMatch?: {
    aestheticAlignment: string;
    toneOfVoiceMatch: string;
    frequencyCompatibility: string;
  };
  riskLevel?: "low" | "medium" | "high";
  timelineCompatibility?: "excellent" | "good" | "concerning";
  uniqueSellingPoints?: string[];
  campaignSpecificInsights?: string;
  influencer?: any;
}

interface RecommendationAnalytics {
  averageScore: number;
  topScoreRange: number[];
  matchLevelDistribution: {
    excellent: number;
    good: number;
    fair: number;
    poor: number;
  };
  averageEstimatedROI: number;
}

const EnhancedRecommendations = ({
  campaignId,
}: EnhancedRecommendationsProps) => {
  const [recommendations, setRecommendations] = useState<
    EnhancedRecommendation[]
  >([]);
  const [analytics, setAnalytics] = useState<RecommendationAnalytics | null>(
    null
  );
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedTab, setSelectedTab] = useState("recommendations");
  const navigate = useNavigate();

  useEffect(() => {
    loadRecommendations();
  }, [campaignId]);

  const loadRecommendations = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const response = await campaignService.getEnhancedRecommendations(
        campaignId
      );
      console.log("Enhanced Recommendations Response:", response);

      const responseData = response as any;
      const recommendationData = responseData.recommendations || {};
      const rawRecommendations = recommendationData.allMatches || [];
      const analyticsData = responseData.analytics;

      // Fetch full influencer profiles for each recommendation
      const enhancedRecommendations = await Promise.all(
        rawRecommendations.map(async (rec: any) => {
          try {
            // Ensure the recommendation has a valid ID
            if (!rec.id) {
              console.error("Recommendation missing ID:", rec);
              return null;
            }

            const influencerData = await userService.getInfluencerById(rec.id);
            return {
              ...rec,
              influencer: influencerData,
            };
          } catch (error) {
            console.error(`Failed to load influencer ${rec.id}:`, error);
            return {
              ...rec,
              influencer: null,
            };
          }
        })
      );

      // Filter out null recommendations and those where we couldn't load the influencer
      const validRecommendations = enhancedRecommendations.filter(
        (rec) => rec && rec.influencer
      );

      setRecommendations(validRecommendations);
      setAnalytics(analyticsData);
    } catch (error: any) {
      console.error("Failed to load recommendations:", error);
      setError("Failed to load recommendations");
      toast({
        title: "Error",
        description: "Failed to load enhanced influencer recommendations.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const formatFollowers = (count: number) => {
    if (count >= 1000000) {
      return `${(count / 1000000).toFixed(1)}M`;
    } else if (count >= 1000) {
      return `${(count / 1000).toFixed(1)}K`;
    }
    return count.toString();
  };

  const getMatchLevelColor = (level?: string) => {
    switch (level) {
      case "excellent":
        return "bg-green-100 text-green-800 border-green-200";
      case "good":
        return "bg-blue-100 text-blue-800 border-blue-200";
      case "fair":
        return "bg-yellow-100 text-yellow-800 border-yellow-200";
      case "poor":
        return "bg-red-100 text-red-800 border-red-200";
      default:
        return "bg-gray-100 text-gray-800 border-gray-200";
    }
  };

  const getRiskLevelColor = (level?: string) => {
    switch (level) {
      case "low":
        return "bg-green-100 text-green-800";
      case "medium":
        return "bg-yellow-100 text-yellow-800";
      case "high":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getBudgetFitColor = (fit?: string) => {
    switch (fit) {
      case "within":
        return "bg-green-100 text-green-800";
      case "above":
        return "bg-orange-100 text-orange-800";
      case "below":
        return "bg-blue-100 text-blue-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {[...Array(6)].map((_, index) => (
            <Card key={index} className="p-6">
              <Skeleton className="h-4 w-2/3 mb-2" />
              <Skeleton className="h-4 w-1/2 mb-4" />
              <Skeleton className="h-32 w-full" />
            </Card>
          ))}
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <Card className="p-6">
        <div className="text-center text-red-600">
          <AlertTriangle className="h-12 w-12 mx-auto mb-4" />
          <p>{error}</p>
          <Button onClick={loadRecommendations} className="mt-4">
            Try Again
          </Button>
        </div>
      </Card>
    );
  }

  if (recommendations.length === 0) {
    return (
      <Card className="p-6">
        <div className="text-center text-gray-500">
          <Users className="h-12 w-12 mx-auto mb-4" />
          <p>No matching influencers found for this campaign.</p>
          <p className="text-sm mt-2">
            Try adjusting your campaign requirements to find more potential
            matches.
          </p>
        </div>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold flex items-center gap-2">
          <Brain className="h-6 w-6 text-purple-600" />
          AI-Enhanced Recommendations
        </h2>
        <Badge variant="secondary" className="flex items-center gap-1">
          <Sparkles className="h-4 w-4" />
          {recommendations.length} Recommendations
        </Badge>
      </div>

      <Tabs
        value={selectedTab}
        onValueChange={setSelectedTab}
        className="w-full"
      >
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="recommendations">Recommendations</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
        </TabsList>

        <TabsContent value="recommendations" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
            {recommendations.map((recommendation, index) => (
              <Card
                key={recommendation.id}
                className={`relative transition-all duration-200 hover:shadow-lg border-2 ${
                  index < 3 ? "ring-2 ring-purple-200 bg-purple-50/30" : ""
                }`}
              >
                {index < 3 && (
                  <div className="absolute -top-2 -right-2 bg-purple-600 text-white rounded-full w-8 h-8 flex items-center justify-center text-sm font-bold">
                    {index + 1}
                  </div>
                )}

                <CardHeader className="pb-4">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <Avatar className="h-12 w-12">
                        <AvatarImage
                          src={recommendation.influencer?.profileImage}
                          alt={recommendation.influencer?.name}
                        />
                        <AvatarFallback>
                          {recommendation.influencer?.name?.charAt(0) || "?"}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <CardTitle className="text-lg">
                          {recommendation.influencer?.name ||
                            "Unknown Influencer"}
                        </CardTitle>
                        <CardDescription className="flex items-center gap-2">
                          <Users className="h-4 w-4" />
                          {formatFollowers(
                            recommendation.influencer?.metrics
                              ?.totalFollowers || 0
                          )}{" "}
                          followers
                        </CardDescription>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-2xl font-bold text-purple-600">
                        {recommendation.score}
                      </div>
                      <Badge
                        className={getMatchLevelColor(
                          recommendation.matchLevel
                        )}
                      >
                        {recommendation.matchLevel}
                      </Badge>
                    </div>
                  </div>
                </CardHeader>

                <CardContent className="space-y-4">
                  {/* Performance Metrics */}
                  {recommendation.performanceMetrics && (
                    <div className="bg-gray-50 rounded-lg p-3">
                      <h4 className="font-semibold text-sm mb-2 flex items-center gap-1">
                        <BarChart3 className="h-4 w-4" />
                        Performance Metrics
                      </h4>
                      <div className="grid grid-cols-2 gap-2 text-xs">
                        <div className="flex items-center gap-1">
                          <Heart className="h-3 w-3 text-red-500" />
                          {recommendation.performanceMetrics.avgEngagementRate.toFixed(
                            1
                          )}
                          % engagement
                        </div>
                        <div className="flex items-center gap-1">
                          <Eye className="h-3 w-3 text-blue-500" />
                          {formatFollowers(
                            recommendation.performanceMetrics.avgViewsPerPost
                          )}{" "}
                          avg views
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Audience Insights */}
                  {recommendation.audienceInsights && (
                    <div className="bg-blue-50 rounded-lg p-3">
                      <h4 className="font-semibold text-sm mb-2 flex items-center gap-1">
                        <Target className="h-4 w-4" />
                        Audience Match
                      </h4>
                      <div className="space-y-1 text-xs">
                        <div>
                          {recommendation.audienceInsights.primaryDemographic}
                        </div>
                        <div className="flex justify-between">
                          <span>Location Match:</span>
                          <span className="font-medium">
                            {recommendation.audienceInsights.locationMatch}
                          </span>
                        </div>
                        {recommendation.audienceInsights.interestOverlap && (
                          <div className="flex justify-between">
                            <span>Interest Overlap:</span>
                            <span className="font-medium">
                              {recommendation.audienceInsights.interestOverlap}
                            </span>
                          </div>
                        )}
                      </div>
                    </div>
                  )}

                  {/* Personality & Brand Fit */}
                  {recommendation.personalityMatch && (
                    <div className="bg-green-50 rounded-lg p-3">
                      <h4 className="font-semibold text-sm mb-2 flex items-center gap-1">
                        <Award className="h-4 w-4" />
                        Personality Fit
                      </h4>
                      <div className="grid grid-cols-2 gap-2 text-xs">
                        <div>
                          <span>Authenticity:</span>
                          <div className="w-full bg-gray-200 rounded-full h-1.5 mt-1">
                            <div
                              className="bg-green-600 h-1.5 rounded-full"
                              style={{
                                width: `${
                                  recommendation.personalityMatch.authenticity *
                                  10
                                }%`,
                              }}
                            ></div>
                          </div>
                        </div>
                        <div>
                          <span>Creativity:</span>
                          <div className="w-full bg-gray-200 rounded-full h-1.5 mt-1">
                            <div
                              className="bg-purple-600 h-1.5 rounded-full"
                              style={{
                                width: `${
                                  recommendation.personalityMatch.creativity *
                                  10
                                }%`,
                              }}
                            ></div>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Key Insights */}
                  <div className="space-y-2">
                    <h4 className="font-semibold text-sm flex items-center gap-1">
                      <Sparkles className="h-4 w-4" />
                      Key Strengths
                    </h4>
                    <div className="space-y-1">
                      {recommendation.strengths
                        ?.slice(0, 2)
                        .map((strength, idx) => (
                          <div
                            key={idx}
                            className="flex items-center gap-2 text-sm text-green-700"
                          >
                            <CheckCircle className="h-3 w-3" />
                            {strength}
                          </div>
                        ))}
                    </div>
                  </div>

                  {/* Concerns & Risk */}
                  {recommendation.concerns &&
                    recommendation.concerns.length > 0 && (
                      <div className="space-y-2">
                        <h4 className="font-semibold text-sm flex items-center gap-1">
                          <AlertTriangle className="h-4 w-4" />
                          Considerations
                        </h4>
                        <div className="space-y-1">
                          {recommendation.concerns
                            .slice(0, 1)
                            .map((concern, idx) => (
                              <div
                                key={idx}
                                className="flex items-center gap-2 text-sm text-orange-600"
                              >
                                <AlertTriangle className="h-3 w-3" />
                                {concern}
                              </div>
                            ))}
                        </div>
                      </div>
                    )}

                  {/* ROI & Budget */}
                  <div className="flex justify-between items-center pt-2 border-t">
                    <div className="flex items-center gap-2">
                      <DollarSign className="h-4 w-4 text-green-600" />
                      <span className="text-sm font-medium">
                        {recommendation.estimatedROI}% ROI
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge
                        className={getRiskLevelColor(recommendation.riskLevel)}
                        variant="outline"
                      >
                        {recommendation.riskLevel} risk
                      </Badge>
                      <Badge
                        className={getBudgetFitColor(recommendation.budgetFit)}
                        variant="outline"
                      >
                        {recommendation.budgetFit} budget
                      </Badge>
                    </div>
                  </div>

                  {/* Action Buttons */}
                  <div className="flex gap-2 pt-2">
                    <Button
                      variant="default"
                      size="sm"
                      className="flex-1"
                      onClick={() => {
                        if (recommendation.id) {
                          navigate(`/influencer-profile/${recommendation.id}`);
                        } else {
                          console.error(
                            "Cannot navigate: recommendation.id is undefined"
                          );
                          toast({
                            title: "Error",
                            description:
                              "Unable to view profile - invalid influencer ID",
                            variant: "destructive",
                          });
                        }
                      }}
                    >
                      View Profile
                    </Button>
                    <Button variant="outline" size="sm">
                      Contact
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="analytics" className="space-y-6">
          {analytics && (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card className="p-6">
                <div className="flex items-center gap-2 mb-2">
                  <Star className="h-5 w-5 text-yellow-500" />
                  <h3 className="font-semibold">Average Score</h3>
                </div>
                <div className="text-3xl font-bold text-purple-600">
                  {analytics.averageScore.toFixed(1)}
                </div>
                <p className="text-sm text-gray-600 mt-1">Out of 100 points</p>
              </Card>

              <Card className="p-6">
                <div className="flex items-center gap-2 mb-2">
                  <TrendingUp className="h-5 w-5 text-green-500" />
                  <h3 className="font-semibold">Expected ROI</h3>
                </div>
                <div className="text-3xl font-bold text-green-600">
                  {analytics.averageEstimatedROI.toFixed(0)}%
                </div>
                <p className="text-sm text-gray-600 mt-1">
                  Average across all recommendations
                </p>
              </Card>

              <Card className="p-6">
                <div className="flex items-center gap-2 mb-2">
                  <Award className="h-5 w-5 text-blue-500" />
                  <h3 className="font-semibold">Top Performers</h3>
                </div>
                <div className="text-3xl font-bold text-blue-600">
                  {analytics.topScoreRange[0] || 0}
                </div>
                <p className="text-sm text-gray-600 mt-1">
                  Highest match score
                </p>
              </Card>

              <Card className="p-6">
                <div className="flex items-center gap-2 mb-2">
                  <PieChart className="h-5 w-5 text-purple-500" />
                  <h3 className="font-semibold">Excellent Matches</h3>
                </div>
                <div className="text-3xl font-bold text-purple-600">
                  {analytics.matchLevelDistribution.excellent}
                </div>
                <p className="text-sm text-gray-600 mt-1">
                  Top-tier recommendations
                </p>
              </Card>
            </div>
          )}

          {/* Match Level Distribution */}
          {analytics && (
            <Card className="p-6">
              <h3 className="font-semibold mb-4 flex items-center gap-2">
                <BarChart3 className="h-5 w-5" />
                Match Level Distribution
              </h3>
              <div className="space-y-3">
                {Object.entries(analytics.matchLevelDistribution).map(
                  ([level, count]) => (
                    <div key={level} className="flex items-center gap-3">
                      <div className="w-20 text-sm font-medium capitalize">
                        {level}
                      </div>
                      <div className="flex-1">
                        <Progress
                          value={(count / recommendations.length) * 100}
                          className="h-2"
                        />
                      </div>
                      <div className="w-12 text-sm text-gray-600">{count}</div>
                    </div>
                  )
                )}
              </div>
            </Card>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default EnhancedRecommendations;
