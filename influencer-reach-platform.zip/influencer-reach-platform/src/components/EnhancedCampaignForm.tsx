import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Slider } from "@/components/ui/slider";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { X, Plus } from "lucide-react";

// Enhanced schema with new fields
const enhancedCampaignSchema = z.object({
  title: z.string().min(1, "Title is required").max(200, "Title too long"),
  description: z.string().min(1, "Description is required").max(3000, "Description too long"),
  category: z.string().min(1, "Category is required"),
  objectives: z.array(z.string()).min(1, "At least one objective is required"),
  
  // Product Information
  productInfo: z.object({
    name: z.string().optional(),
    description: z.string().optional(),
    price: z.number().optional(),
    urls: z.array(z.string()).optional(),
  }).optional(),

  // Enhanced Requirements
  requirements: z.object({
    // Basic requirements
    influencerTypes: z.array(z.string()).optional(),
    followerRange: z.object({
      min: z.number().optional(),
      max: z.number().optional(),
    }).optional(),
    
    // Enhanced demographics
    demographics: z.object({
      ageGroups: z.array(z.string()).optional(),
      genders: z.array(z.string()).optional(),
      locations: z.array(z.string()).optional(),
      interests: z.array(z.string()).optional(),
      languages: z.array(z.string()).optional(),
    }).optional(),
    
    platforms: z.array(z.string()).optional(),
    engagementRate: z.object({
      min: z.number().optional(),
      max: z.number().optional(),
    }).optional(),
    
    // Content style preferences
    contentStyle: z.object({
      preferredAesthetic: z.array(z.string()).optional(),
      toneOfVoice: z.array(z.string()).optional(),
    }).optional(),
    
    // Personality traits
    personalityTraits: z.object({
      authenticity: z.object({
        min: z.number().min(1).max(10).optional(),
        max: z.number().min(1).max(10).optional(),
      }).optional(),
      creativity: z.object({
        min: z.number().min(1).max(10).optional(),
        max: z.number().min(1).max(10).optional(),
      }).optional(),
      professionalism: z.object({
        min: z.number().min(1).max(10).optional(),
        max: z.number().min(1).max(10).optional(),
      }).optional(),
      reliability: z.object({
        min: z.number().min(1).max(10).optional(),
        max: z.number().min(1).max(10).optional(),
      }).optional(),
    }).optional(),
    
    // Brand collaboration requirements
    mustHaveCollaboratedWith: z.array(z.string()).optional(),
    mustNotHaveCollaboratedWith: z.array(z.string()).optional(),
    minimumRating: z.number().min(0).max(5).optional(),
    verificationRequired: z.boolean().optional(),
    excludeCompetitors: z.boolean().optional(),
  }).optional(),
    
    // Enhanced demographics
    demographics: z.object({
      ageGroups: z.array(z.string()).optional(),
      genders: z.array(z.string()).optional(),
      locations: z.array(z.string()).optional(),
      interests: z.array(z.string()).optional(), // New field
      languages: z.array(z.string()).optional(),
    }).optional(),
    
    platforms: z.array(z.string()).optional(),
    engagementRate: z.object({
      min: z.number().optional(),
      max: z.number().optional(),
    }).optional(),
    
    // Content style preferences
    contentStyle: z.object({
      preferredAesthetic: z.array(z.string()).optional(),
      toneOfVoice: z.array(z.string()).optional(),
    }).optional(),
    
    // Personality requirements
    personalityTraits: z.object({
      authenticity: z.object({
        min: z.number().optional(),
        max: z.number().optional(),
      }).optional(),
      creativity: z.object({
        min: z.number().optional(),
        max: z.number().optional(),
      }).optional(),
      professionalism: z.object({
        min: z.number().optional(),
        max: z.number().optional(),
      }).optional(),
      reliability: z.object({
        min: z.number().optional(),
        max: z.number().optional(),
      }).optional(),
    }).optional(),
    
    // Brand collaboration requirements
    mustHaveCollaboratedWith: z.array(z.string()).optional(),
    mustNotHaveCollaboratedWith: z.array(z.string()).optional(),
    minimumRating: z.number().optional(),
    verificationRequired: z.boolean().optional(),
    excludeCompetitors: z.boolean().optional(),
  }),
  
  // Budget
  budget: z.object({
    type: z.enum(["fixed", "negotiable", "performance"]),
    amount: z.object({
      min: z.number().optional(),
      max: z.number().optional(),
    }).optional(),
    currency: z.string().default("USD"),
    paymentTerms: z.string().optional(),
  }),
  
  // Timeline
  timeline: z.object({
    applicationDeadline: z.string(),
    campaignStart: z.string(),
    campaignEnd: z.string(),
    contentDeadline: z.string().optional(),
  }),
  
  // Deliverables
  deliverables: z.array(z.object({
    type: z.string(),
    platform: z.string(),
    quantity: z.number().min(1),
    specifications: z.object({
      duration: z.number().optional(),
      dimensions: z.string().optional(),
      hashtags: z.array(z.string()).optional(),
      mentions: z.array(z.string()).optional(),
      guidelines: z.string().optional(),
    }).optional(),
  })).min(1, "At least one deliverable is required"),

  visibility: z.enum(["public", "private", "invited-only"]).default("public"),
  tags: z.array(z.string()).optional(),
});

type EnhancedCampaignFormData = z.infer<typeof enhancedCampaignSchema>;

interface EnhancedCampaignFormProps {
  onSubmit: (data: EnhancedCampaignFormData) => void;
  initialData?: Partial<EnhancedCampaignFormData>;
  isLoading?: boolean;
}

const categories = [
  "fashion", "beauty", "fitness", "food", "travel", "lifestyle",
  "technology", "gaming", "music", "art", "education", "brand",
  "health", "parenting", "pets", "sports", "entertainment", "comedy",
  "diy", "automotive", "home", "finance", "books", "photography", "other"
];

const objectives = [
  "brand-awareness", "lead-generation", "sales-conversion", "engagement",
  "content-creation", "event-promotion", "product-launch", "app-downloads",
  "website-traffic", "social-media-growth"
];

const platforms = [
  "instagram", "tiktok", "youtube", "twitter", "facebook",
  "linkedin", "twitch", "snapchat"
];

const deliverableTypes = [
  "post", "story", "reel", "video", "article", "review",
  "unboxing", "tutorial", "other"
];

const influencerTypes = ["nano", "micro", "macro", "mega"];
const ageGroups = ["13-17", "18-24", "25-34", "35-44", "45-54", "55-64", "65+"];
const genders = ["male", "female", "mixed", "other"];

const aestheticStyles = [
  "minimalist", "colorful", "dark", "bright", "vintage",
  "modern", "artistic", "lifestyle"
];

const toneOfVoiceOptions = [
  "professional", "casual", "humorous", "inspirational",
  "educational", "friendly", "authoritative"
];

const EnhancedCampaignForm = ({ onSubmit, initialData, isLoading }: EnhancedCampaignFormProps) => {
  const [activeTab, setActiveTab] = useState("basic");
  const [interests, setInterests] = useState<string[]>(initialData?.requirements?.demographics?.interests || []);
  const [newInterest, setNewInterest] = useState("");
  const [mustHaveBrands, setMustHaveBrands] = useState<string[]>(initialData?.requirements?.mustHaveCollaboratedWith || []);
  const [newMustHaveBrand, setNewMustHaveBrand] = useState("");
  const [excludeBrands, setExcludeBrands] = useState<string[]>(initialData?.requirements?.mustNotHaveCollaboratedWith || []);
  const [newExcludeBrand, setNewExcludeBrand] = useState("");

  const form = useForm<EnhancedCampaignFormData>({
    resolver: zodResolver(enhancedCampaignSchema),
    defaultValues: {
      title: "",
      description: "",
      category: "",
      objectives: [],
      requirements: {
        demographics: {
          interests: interests,
        },
        contentStyle: {
          preferredAesthetic: [],
          toneOfVoice: [],
        },
        personalityTraits: {},
        mustHaveCollaboratedWith: mustHaveBrands,
        mustNotHaveCollaboratedWith: excludeBrands,
        verificationRequired: true,
      },
      budget: {
        type: "negotiable",
        currency: "USD",
      },
      deliverables: [],
      visibility: "public",
      tags: [],
      ...initialData,
    },
  });

  const addInterest = () => {
    if (newInterest.trim() && !interests.includes(newInterest.trim())) {
      const updated = [...interests, newInterest.trim()];
      setInterests(updated);
      form.setValue("requirements.demographics.interests", updated);
      setNewInterest("");
    }
  };

  const removeInterest = (interest: string) => {
    const updated = interests.filter(i => i !== interest);
    setInterests(updated);
    form.setValue("requirements.demographics.interests", updated);
  };

  const addMustHaveBrand = () => {
    if (newMustHaveBrand.trim() && !mustHaveBrands.includes(newMustHaveBrand.trim())) {
      const updated = [...mustHaveBrands, newMustHaveBrand.trim()];
      setMustHaveBrands(updated);
      form.setValue("requirements.mustHaveCollaboratedWith", updated);
      setNewMustHaveBrand("");
    }
  };

  const removeMustHaveBrand = (brand: string) => {
    const updated = mustHaveBrands.filter(b => b !== brand);
    setMustHaveBrands(updated);
    form.setValue("requirements.mustHaveCollaboratedWith", updated);
  };

  const addExcludeBrand = () => {
    if (newExcludeBrand.trim() && !excludeBrands.includes(newExcludeBrand.trim())) {
      const updated = [...excludeBrands, newExcludeBrand.trim()];
      setExcludeBrands(updated);
      form.setValue("requirements.mustNotHaveCollaboratedWith", updated);
      setNewExcludeBrand("");
    }
  };

  const removeExcludeBrand = (brand: string) => {
    const updated = excludeBrands.filter(b => b !== brand);
    setExcludeBrands(updated);
    form.setValue("requirements.mustNotHaveCollaboratedWith", updated);
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="basic">Basic Info</TabsTrigger>
            <TabsTrigger value="targeting">Targeting</TabsTrigger>
            <TabsTrigger value="preferences">Preferences</TabsTrigger>
            <TabsTrigger value="budget">Budget & Timeline</TabsTrigger>
            <TabsTrigger value="deliverables">Deliverables</TabsTrigger>
          </TabsList>

          <TabsContent value="basic" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Campaign Basics</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <FormField
                  control={form.control}
                  name="title"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Campaign Title</FormLabel>
                      <FormControl>
                        <Input placeholder="Enter campaign title" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Campaign Description</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="Describe your campaign goals, brand, and what you're looking for..."
                          className="min-h-[120px]"
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="category"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Category</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select campaign category" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {categories.map((category) => (
                            <SelectItem key={category} value={category}>
                              {category.charAt(0).toUpperCase() + category.slice(1)}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="objectives"
                  render={() => (
                    <FormItem>
                      <FormLabel>Campaign Objectives</FormLabel>
                      <FormDescription>
                        Select all that apply to your campaign goals
                      </FormDescription>
                      <div className="grid grid-cols-2 gap-2">
                        {objectives.map((objective) => (
                          <FormField
                            key={objective}
                            control={form.control}
                            name="objectives"
                            render={({ field }) => (
                              <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                                <FormControl>
                                  <Checkbox
                                    checked={field.value?.includes(objective)}
                                    onCheckedChange={(checked) => {
                                      const current = field.value || [];
                                      if (checked) {
                                        field.onChange([...current, objective]);
                                      } else {
                                        field.onChange(current.filter((value) => value !== objective));
                                      }
                                    }}
                                  />
                                </FormControl>
                                <FormLabel className="text-sm font-normal">
                                  {objective.replace('-', ' ').replace(/\b\w/g, l => l.toUpperCase())}
                                </FormLabel>
                              </FormItem>
                            )}
                          />
                        ))}
                      </div>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="targeting" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Audience & Influencer Targeting</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Influencer Types */}
                <FormField
                  control={form.control}
                  name="requirements.influencerTypes"
                  render={() => (
                    <FormItem>
                      <FormLabel>Influencer Types</FormLabel>
                      <FormDescription>
                        Select the types of influencers you want to work with
                      </FormDescription>
                      <div className="flex gap-2">
                        {influencerTypes.map((type) => (
                          <FormField
                            key={type}
                            control={form.control}
                            name="requirements.influencerTypes"
                            render={({ field }) => (
                              <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                                <FormControl>
                                  <Checkbox
                                    checked={field.value?.includes(type)}
                                    onCheckedChange={(checked) => {
                                      const current = field.value || [];
                                      if (checked) {
                                        field.onChange([...current, type]);
                                      } else {
                                        field.onChange(current.filter((value) => value !== type));
                                      }
                                    }}
                                  />
                                </FormControl>
                                <FormLabel className="text-sm font-normal capitalize">
                                  {type}
                                </FormLabel>
                              </FormItem>
                            )}
                          />
                        ))}
                      </div>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {/* Follower Range */}
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="requirements.followerRange.min"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Minimum Followers</FormLabel>
                        <FormControl>
                          <Input 
                            type="number" 
                            placeholder="e.g., 1000"
                            {...field}
                            onChange={(e) => field.onChange(parseInt(e.target.value) || undefined)}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="requirements.followerRange.max"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Maximum Followers</FormLabel>
                        <FormControl>
                          <Input 
                            type="number" 
                            placeholder="e.g., 100000"
                            {...field}
                            onChange={(e) => field.onChange(parseInt(e.target.value) || undefined)}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                {/* Demographics */}
                <div className="space-y-4">
                  <Label className="text-base font-medium">Target Demographics</Label>
                  
                  {/* Age Groups */}
                  <FormField
                    control={form.control}
                    name="requirements.demographics.ageGroups"
                    render={() => (
                      <FormItem>
                        <FormLabel>Age Groups</FormLabel>
                        <div className="flex flex-wrap gap-2">
                          {ageGroups.map((age) => (
                            <FormField
                              key={age}
                              control={form.control}
                              name="requirements.demographics.ageGroups"
                              render={({ field }) => (
                                <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                                  <FormControl>
                                    <Checkbox
                                      checked={field.value?.includes(age)}
                                      onCheckedChange={(checked) => {
                                        const current = field.value || [];
                                        if (checked) {
                                          field.onChange([...current, age]);
                                        } else {
                                          field.onChange(current.filter((value) => value !== age));
                                        }
                                      }}
                                    />
                                  </FormControl>
                                  <FormLabel className="text-sm font-normal">
                                    {age}
                                  </FormLabel>
                                </FormItem>
                              )}
                            />
                          ))}
                        </div>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  {/* Audience Interests */}
                  <div>
                    <Label>Audience Interests</Label>
                    <div className="flex gap-2 mt-2">
                      <Input
                        placeholder="Add audience interest..."
                        value={newInterest}
                        onChange={(e) => setNewInterest(e.target.value)}
                        onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addInterest())}
                      />
                      <Button type="button" onClick={addInterest} size="sm">
                        <Plus className="h-4 w-4" />
                      </Button>
                    </div>
                    <div className="flex flex-wrap gap-2 mt-2">
                      {interests.map((interest) => (
                        <Badge key={interest} variant="secondary" className="flex items-center gap-1">
                          {interest}
                          <button type="button" onClick={() => removeInterest(interest)}>
                            <X className="h-3 w-3" />
                          </button>
                        </Badge>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Platforms */}
                <FormField
                  control={form.control}
                  name="requirements.platforms"
                  render={() => (
                    <FormItem>
                      <FormLabel>Required Platforms</FormLabel>
                      <div className="grid grid-cols-3 gap-2">
                        {platforms.map((platform) => (
                          <FormField
                            key={platform}
                            control={form.control}
                            name="requirements.platforms"
                            render={({ field }) => (
                              <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                                <FormControl>
                                  <Checkbox
                                    checked={field.value?.includes(platform)}
                                    onCheckedChange={(checked) => {
                                      const current = field.value || [];
                                      if (checked) {
                                        field.onChange([...current, platform]);
                                      } else {
                                        field.onChange(current.filter((value) => value !== platform));
                                      }
                                    }}
                                  />
                                </FormControl>
                                <FormLabel className="text-sm font-normal capitalize">
                                  {platform}
                                </FormLabel>
                              </FormItem>
                            )}
                          />
                        ))}
                      </div>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="preferences" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Content & Personality Preferences</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Content Style */}
                <div className="space-y-4">
                  <Label className="text-base font-medium">Content Style Preferences</Label>
                  
                  <FormField
                    control={form.control}
                    name="requirements.contentStyle.preferredAesthetic"
                    render={() => (
                      <FormItem>
                        <FormLabel>Preferred Aesthetic</FormLabel>
                        <div className="grid grid-cols-3 gap-2">
                          {aestheticStyles.map((style) => (
                            <FormField
                              key={style}
                              control={form.control}
                              name="requirements.contentStyle.preferredAesthetic"
                              render={({ field }) => (
                                <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                                  <FormControl>
                                    <Checkbox
                                      checked={field.value?.includes(style)}
                                      onCheckedChange={(checked) => {
                                        const current = field.value || [];
                                        if (checked) {
                                          field.onChange([...current, style]);
                                        } else {
                                          field.onChange(current.filter((value) => value !== style));
                                        }
                                      }}
                                    />
                                  </FormControl>
                                  <FormLabel className="text-sm font-normal capitalize">
                                    {style}
                                  </FormLabel>
                                </FormItem>
                              )}
                            />
                          ))}
                        </div>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="requirements.contentStyle.toneOfVoice"
                    render={() => (
                      <FormItem>
                        <FormLabel>Tone of Voice</FormLabel>
                        <div className="grid grid-cols-3 gap-2">
                          {toneOfVoiceOptions.map((tone) => (
                            <FormField
                              key={tone}
                              control={form.control}
                              name="requirements.contentStyle.toneOfVoice"
                              render={({ field }) => (
                                <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                                  <FormControl>
                                    <Checkbox
                                      checked={field.value?.includes(tone)}
                                      onCheckedChange={(checked) => {
                                        const current = field.value || [];
                                        if (checked) {
                                          field.onChange([...current, tone]);
                                        } else {
                                          field.onChange(current.filter((value) => value !== tone));
                                        }
                                      }}
                                    />
                                  </FormControl>
                                  <FormLabel className="text-sm font-normal capitalize">
                                    {tone}
                                  </FormLabel>
                                </FormItem>
                              )}
                            />
                          ))}
                        </div>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <Separator />

                {/* Personality Traits */}
                <div className="space-y-4">
                  <Label className="text-base font-medium">Personality Requirements</Label>
                  <FormDescription>
                    Set minimum requirements for personality traits (1-10 scale)
                  </FormDescription>
                  
                  {['authenticity', 'creativity', 'professionalism', 'reliability'].map((trait) => (
                    <FormField
                      key={trait}
                      control={form.control}
                      name={`requirements.personalityTraits.${trait}.min` as any}
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="capitalize">{trait}</FormLabel>
                          <FormControl>
                            <div className="space-y-2">
                              <Slider
                                value={[field.value || 1]}
                                onValueChange={(value) => field.onChange(value[0])}
                                max={10}
                                min={1}
                                step={1}
                                className="w-full"
                              />
                              <div className="text-sm text-gray-600">
                                Minimum: {field.value || 1}/10
                              </div>
                            </div>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  ))}
                </div>

                <Separator />

                {/* Brand Collaboration Requirements */}
                <div className="space-y-4">
                  <Label className="text-base font-medium">Brand Collaboration History</Label>
                  
                  <div>
                    <Label>Must Have Collaborated With</Label>
                    <FormDescription>Brands that influencers must have worked with previously</FormDescription>
                    <div className="flex gap-2 mt-2">
                      <Input
                        placeholder="Add required brand..."
                        value={newMustHaveBrand}
                        onChange={(e) => setNewMustHaveBrand(e.target.value)}
                        onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addMustHaveBrand())}
                      />
                      <Button type="button" onClick={addMustHaveBrand} size="sm">
                        <Plus className="h-4 w-4" />
                      </Button>
                    </div>
                    <div className="flex flex-wrap gap-2 mt-2">
                      {mustHaveBrands.map((brand) => (
                        <Badge key={brand} variant="secondary" className="flex items-center gap-1">
                          {brand}
                          <button type="button" onClick={() => removeMustHaveBrand(brand)}>
                            <X className="h-3 w-3" />
                          </button>
                        </Badge>
                      ))}
                    </div>
                  </div>

                  <div>
                    <Label>Must NOT Have Collaborated With</Label>
                    <FormDescription>Competitor brands to exclude</FormDescription>
                    <div className="flex gap-2 mt-2">
                      <Input
                        placeholder="Add competitor brand..."
                        value={newExcludeBrand}
                        onChange={(e) => setNewExcludeBrand(e.target.value)}
                        onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addExcludeBrand())}
                      />
                      <Button type="button" onClick={addExcludeBrand} size="sm">
                        <Plus className="h-4 w-4" />
                      </Button>
                    </div>
                    <div className="flex flex-wrap gap-2 mt-2">
                      {excludeBrands.map((brand) => (
                        <Badge key={brand} variant="destructive" className="flex items-center gap-1">
                          {brand}
                          <button type="button" onClick={() => removeExcludeBrand(brand)}>
                            <X className="h-3 w-3" />
                          </button>
                        </Badge>
                      ))}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="budget" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Budget & Timeline</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Budget Information */}
                <FormField
                  control={form.control}
                  name="budget.type"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Budget Type</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select budget type" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="fixed">Fixed Budget</SelectItem>
                          <SelectItem value="negotiable">Negotiable</SelectItem>
                          <SelectItem value="performance">Performance-based</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="budget.amount.min"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Minimum Budget</FormLabel>
                        <FormControl>
                          <Input 
                            type="number" 
                            placeholder="e.g., 500"
                            {...field}
                            onChange={(e) => field.onChange(parseInt(e.target.value) || undefined)}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="budget.amount.max"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Maximum Budget</FormLabel>
                        <FormControl>
                          <Input 
                            type="number" 
                            placeholder="e.g., 2000"
                            {...field}
                            onChange={(e) => field.onChange(parseInt(e.target.value) || undefined)}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                {/* Timeline */}
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="timeline.applicationDeadline"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Application Deadline</FormLabel>
                        <FormControl>
                          <Input type="datetime-local" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="timeline.campaignStart"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Campaign Start</FormLabel>
                        <FormControl>
                          <Input type="datetime-local" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="timeline.campaignEnd"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Campaign End</FormLabel>
                        <FormControl>
                          <Input type="datetime-local" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="timeline.contentDeadline"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Content Deadline (Optional)</FormLabel>
                        <FormControl>
                          <Input type="datetime-local" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="deliverables" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Campaign Deliverables</CardTitle>
              </CardHeader>
              <CardContent>
                <FormDescription className="mb-4">
                  Define what content you want influencers to create
                </FormDescription>
                {/* Deliverables section - simplified for now */}
                <div className="text-sm text-gray-600">
                  Deliverables configuration will be implemented here...
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        <div className="flex justify-between pt-6">
          <Button
            type="button"
            variant="outline"
            onClick={() => {
              const tabs = ["basic", "targeting", "preferences", "budget", "deliverables"];
              const currentIndex = tabs.indexOf(activeTab);
              if (currentIndex > 0) {
                setActiveTab(tabs[currentIndex - 1]);
              }
            }}
            disabled={activeTab === "basic"}
          >
            Previous
          </Button>
          
          {activeTab !== "deliverables" ? (
            <Button
              type="button"
              onClick={() => {
                const tabs = ["basic", "targeting", "preferences", "budget", "deliverables"];
                const currentIndex = tabs.indexOf(activeTab);
                if (currentIndex < tabs.length - 1) {
                  setActiveTab(tabs[currentIndex + 1]);
                }
              }}
            >
              Next
            </Button>
          ) : (
            <Button type="submit" disabled={isLoading}>
              {isLoading ? "Creating Campaign..." : "Create Campaign"}
            </Button>
          )}
        </div>
      </form>
    </Form>
  );
};

export default EnhancedCampaignForm;
