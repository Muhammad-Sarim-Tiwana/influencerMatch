import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Clock, Mail, Phone, RefreshCw } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useState } from "react";
import { useAuthStore } from "@/store/authStore";
import { toast } from "@/hooks/use-toast";

interface BrandProfileStatusProps {
  status: "pending";
  onRetry?: () => void;
}

const BrandProfileStatus = ({ onRetry }: BrandProfileStatusProps) => {
  const navigate = useNavigate();
  const { checkAuth } = useAuthStore();
  const [isRefreshing, setIsRefreshing] = useState(false);

  const handleRefreshStatus = async () => {
    setIsRefreshing(true);
    try {
      await checkAuth();
      toast({
        title: "Status Updated",
        description: "Your account status has been refreshed.",
      });
      // If account is now active, the parent component will re-render
      // and redirect away from this waiting page
    } catch (error) {
      toast({
        title: "Refresh Failed",
        description: "Unable to refresh status. Please try again later.",
        variant: "destructive",
      });
    } finally {
      setIsRefreshing(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center py-12 px-4">
      <div className="max-w-2xl mx-auto text-center">
        <Card className="border-0 shadow-lg">
          <CardHeader className="pb-4">
            <div className="flex justify-center mb-6">
              <Clock className="h-16 w-16 text-yellow-500" />
            </div>
            <CardTitle className="text-2xl font-bold text-yellow-600">
              Account Pending Approval
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <p className="text-gray-600 text-lg leading-relaxed">
              Thank you for submitting your brand profile! Your account is
              currently under review by our team. Please be patient while we
              complete the verification process.
            </p>

            <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-6">
              <h3 className="font-semibold text-yellow-900 mb-2">
                🔄 Account Status: Under Review
              </h3>
              <p className="text-yellow-800 text-sm mb-3">
                Your account is temporarily inactive until the review is
                complete. You'll receive full access to all features once
                approved.
              </p>
            </div>

            <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
              <h3 className="font-semibold text-blue-900 mb-2">
                What happens next?
              </h3>
              <ul className="text-blue-800 text-sm space-y-1 list-disc list-inside">
                <li>Our team will review your company information</li>
                <li>
                  We'll verify your business details and social media profiles
                </li>
                <li>You'll receive an email notification with the decision</li>
                <li>Review typically takes 1-3 business days</li>
              </ul>
            </div>

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                onClick={handleRefreshStatus}
                disabled={isRefreshing}
                className="flex-1 sm:flex-none"
              >
                {isRefreshing ? (
                  <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                ) : (
                  <RefreshCw className="mr-2 h-4 w-4" />
                )}
                {isRefreshing ? "Checking..." : "Check Status"}
              </Button>
              <Button
                variant="outline"
                onClick={() => navigate("/contact")}
                className="flex-1 sm:flex-none"
              >
                Contact Support
              </Button>
            </div>

            <div className="pt-6 border-t border-gray-200">
              <div className="mb-4 p-3 bg-gray-50 rounded-lg">
                <p className="text-sm text-gray-700 text-center">
                  💡 <strong>Tip:</strong> Use the "Check Status" button above
                  to refresh your account status if you've received an approval
                  email.
                </p>
              </div>
              <p className="text-sm text-gray-500 mb-4">
                Need to contact us about your review?
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center text-sm">
                <div className="flex items-center justify-center gap-2 text-gray-600">
                  <Mail className="h-4 w-4" />
                  <span>support@influencermatch.com</span>
                </div>
                <div className="flex items-center justify-center gap-2 text-gray-600">
                  <Phone className="h-4 w-4" />
                  <span>+1 (555) 123-4567</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default BrandProfileStatus;
