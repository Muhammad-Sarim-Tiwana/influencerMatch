import React, { useState, useEffect, useRef } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Send, ArrowLeft, Clock, CheckCircle } from "lucide-react";
import {
  firebaseChatService,
  ChatMessage,
  ChatConversation,
} from "@/services/firebaseChatService";
import { useAuthStore } from "@/store/authStore";
import { useToast } from "@/hooks/use-toast";
import { useNavigate } from "react-router-dom";

interface ChatProps {
  conversationId?: string;
  campaignId?: string;
  campaignTitle?: string;
  brandId?: string;
  brandName?: string;
  influencerId?: string;
  influencerName?: string;
  onBack?: () => void;
}

const Chat: React.FC<ChatProps> = ({
  conversationId: initialConversationId,
  campaignId,
  campaignTitle,
  brandId,
  brandName,
  influencerId,
  influencerName,
  onBack,
}) => {
  const { user } = useAuthStore();
  const { toast } = useToast();
  const navigate = useNavigate();
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [newMessage, setNewMessage] = useState("");
  const [conversationId, setConversationId] = useState<string | null>(
    initialConversationId || null
  );
  const [isLoading, setIsLoading] = useState(false);
  const [isSending, setIsSending] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (initialConversationId) {
      setConversationId(initialConversationId);
    } else if (
      campaignId &&
      brandId &&
      influencerId &&
      brandName &&
      influencerName &&
      campaignTitle
    ) {
      initializeConversation();
    }
  }, [
    initialConversationId,
    campaignId,
    brandId,
    influencerId,
    brandName,
    influencerName,
    campaignTitle,
  ]);

  useEffect(() => {
    if (conversationId) {
      console.log(
        "Setting up message listener for conversation:",
        conversationId
      );

      // Debug conversation access and user conversations
      if (user?.id) {
        firebaseChatService.debugConversationAccess(conversationId, user.id);
        firebaseChatService.debugUserConversations(user.id);
      }

      const unsubscribe = firebaseChatService.listenToMessagesWithNotifications(
        conversationId,
        user?.id || "",
        (newMessages, newMessage) => {
          console.log("🔄 Received messages update:", {
            messageCount: newMessages.length,
            newMessage: newMessage
              ? `${newMessage.senderName}: ${newMessage.text}`
              : null,
            currentUserId: user?.id,
            currentUserRole: user?.role,
          });

          setMessages(newMessages);
          scrollToBottom();

          // Show toast notification for new messages from other users
          if (newMessage && newMessage.senderId !== user?.id) {
            toast({
              title: `New message from ${newMessage.senderName}`,
              description:
                newMessage.text.length > 50
                  ? `${newMessage.text.substring(0, 50)}...`
                  : newMessage.text,
              duration: 4000,
            });
          }

          // Mark messages as read
          if (user?.id) {
            firebaseChatService.markMessagesAsRead(conversationId, user.id);
          }
        }
      );

      return unsubscribe;
    }
  }, [conversationId, user?.id, toast]);

  const initializeConversation = async () => {
    if (
      !user ||
      !campaignId ||
      !brandId ||
      !influencerId ||
      !brandName ||
      !influencerName ||
      !campaignTitle
    ) {
      console.error(
        "❌ Missing required data for conversation initialization:",
        {
          user: !!user,
          campaignId: !!campaignId,
          brandId: !!brandId,
          influencerId: !!influencerId,
          brandName: !!brandName,
          influencerName: !!influencerName,
          campaignTitle: !!campaignTitle,
        }
      );
      return;
    }

    console.log("🚀 Initializing conversation with:", {
      currentUser: { id: user.id, name: user.name, role: user.role },
      campaignId,
      campaignTitle,
      brandId,
      brandName,
      influencerId,
      influencerName,
    });

    // Verify that the current user is either the brand or influencer
    const isCurrentUserBrand = user.id === brandId;
    const isCurrentUserInfluencer = user.id === influencerId;

    console.log("👤 User role verification:", {
      currentUserId: user.id,
      isCurrentUserBrand,
      isCurrentUserInfluencer,
      expectedRole: isCurrentUserBrand ? "brand" : "influencer",
      actualRole: user.role,
    });

    setIsLoading(true);
    try {
      const newConversationId =
        await firebaseChatService.createOrGetConversation(
          campaignId,
          campaignTitle,
          brandId,
          brandName,
          influencerId,
          influencerName,
          user.id
        );

      console.log("✅ Conversation initialized:", newConversationId);
      setConversationId(newConversationId);
    } catch (error) {
      console.error("❌ Failed to initialize conversation:", error);
      toast({
        title: "Error",
        description: "Failed to start conversation. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  const handleSendMessage = async () => {
    if (!newMessage.trim() || !conversationId || !user || isSending) {
      return;
    }

    console.log("Sending message:", {
      conversationId,
      userId: user.id,
      userName: user.name,
      message: newMessage.trim(),
    });

    setIsSending(true);
    try {
      // Validate user role
      const userRole = user.role as "influencer" | "brand";
      if (!userRole || (userRole !== "influencer" && userRole !== "brand")) {
        throw new Error("Invalid user role");
      }

      await firebaseChatService.sendMessage(
        conversationId,
        user.id,
        user.name || "Unknown User",
        userRole,
        newMessage.trim(),
        campaignId
      );
      setNewMessage("");
      console.log("Message sent successfully");
    } catch (error) {
      console.error("Failed to send message:", error);
      toast({
        title: "Error",
        description:
          error instanceof Error
            ? error.message
            : "Failed to send message. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSending(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const formatMessageTime = (timestamp: number) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffInHours = (now.getTime() - date.getTime()) / (1000 * 60 * 60);

    if (diffInHours < 24) {
      return date.toLocaleTimeString([], {
        hour: "2-digit",
        minute: "2-digit",
      });
    } else {
      return date.toLocaleDateString([], { month: "short", day: "numeric" });
    }
  };

  const getOtherParticipant = () => {
    if (!user) return null;

    if (user.role === "brand") {
      return {
        name: influencerName || "Influencer",
        role: "influencer" as const,
      };
    } else {
      return {
        name: brandName || "Brand",
        role: "brand" as const,
      };
    }
  };

  const otherParticipant = getOtherParticipant();

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-[500px]">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600"></div>
      </div>
    );
  }

  return (
    <Card className="h-[600px] flex flex-col">
      <CardHeader className="flex-shrink-0 border-b">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            {onBack && (
              <Button variant="ghost" size="sm" onClick={onBack}>
                <ArrowLeft className="h-4 w-4" />
              </Button>
            )}
            <Avatar className="h-10 w-10">
              <AvatarFallback>
                {otherParticipant?.name?.charAt(0).toUpperCase() || "U"}
              </AvatarFallback>
            </Avatar>
            <div>
              <CardTitle className="text-lg">
                {otherParticipant?.name}
              </CardTitle>
              <div className="flex items-center space-x-2">
                <Badge variant="secondary" className="text-xs">
                  {otherParticipant?.role}
                </Badge>
                {campaignTitle && (
                  <span className="text-sm text-gray-500">
                    • {campaignTitle}
                  </span>
                )}
                {/* Debug buttons - remove in production */}
                <div className="flex gap-2">
                  <button
                    onClick={async () => {
                      if (conversationId && user?.id) {
                        console.log("🔄 Manual refresh triggered");
                        await firebaseChatService.debugConversationAccess(
                          conversationId,
                          user.id
                        );
                        const fetchedMessages =
                          await firebaseChatService.fetchMessages(
                            conversationId
                          );
                        setMessages(fetchedMessages);
                      }
                    }}
                    className="text-xs bg-blue-500 text-white px-2 py-1 rounded"
                  >
                    Debug Refresh
                  </button>
                  <button
                    onClick={() => {
                      if (user?.id) {
                        firebaseChatService.debugUserConversations(user.id);
                      }
                    }}
                    className="text-xs bg-green-500 text-white px-2 py-1 rounded"
                  >
                    List Conversations
                  </button>
                  <button
                    onClick={async () => {
                      const connected =
                        await firebaseChatService.testConnection();
                      console.log("🔗 Firebase connection:", connected);
                    }}
                    className="text-xs bg-purple-500 text-white px-2 py-1 rounded"
                  >
                    Test Connection
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </CardHeader>

      <CardContent className="flex-1 flex flex-col p-0">
        <ScrollArea className="flex-1 p-4">
          <div className="space-y-4">
            {messages.map((message) => {
              const isOwnMessage = message.senderId === user?.id;
              return (
                <div
                  key={message.id}
                  className={`flex ${
                    isOwnMessage ? "justify-end" : "justify-start"
                  }`}
                >
                  <div
                    className={`max-w-[70%] rounded-lg px-4 py-2 ${
                      isOwnMessage
                        ? "bg-indigo-600 text-white"
                        : "bg-gray-100 text-gray-900"
                    }`}
                  >
                    <div className="text-sm">{message.text}</div>
                    <div
                      className={`flex items-center justify-between mt-1 text-xs ${
                        isOwnMessage ? "text-indigo-200" : "text-gray-500"
                      }`}
                    >
                      <span>{formatMessageTime(message.timestamp)}</span>
                      {isOwnMessage && <CheckCircle className="h-3 w-3 ml-2" />}
                    </div>
                  </div>
                </div>
              );
            })}
            {messages.length === 0 && (
              <div className="text-center text-gray-500 py-8">
                <div className="mb-2">Start your conversation</div>
                <div className="text-sm">
                  This is the beginning of your chat about {campaignTitle}
                </div>
              </div>
            )}
          </div>
          <div ref={messagesEndRef} />
        </ScrollArea>

        <div className="flex-shrink-0 border-t p-4">
          <div className="flex space-x-2">
            <Input
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Type your message..."
              className="flex-1"
              disabled={isSending}
            />
            <Button
              onClick={handleSendMessage}
              disabled={!newMessage.trim() || isSending}
              size="sm"
            >
              <Send className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default Chat;
