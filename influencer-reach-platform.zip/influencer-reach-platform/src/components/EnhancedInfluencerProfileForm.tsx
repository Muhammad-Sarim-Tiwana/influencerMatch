import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { Slider } from "@/components/ui/slider";
import { PlusCircle, X, Star } from "lucide-react";

interface EnhancedInfluencerProfileFormProps {
  onSubmit: (data: any) => void;
  initialData?: any;
  isLoading?: boolean;
}

const categories = [
  "fashion",
  "beauty",
  "fitness",
  "food",
  "travel",
  "lifestyle",
  "technology",
  "gaming",
  "music",
  "art",
  "education",
  "brand",
  "health",
  "parenting",
  "pets",
  "sports",
  "entertainment",
  "comedy",
  "diy",
  "automotive",
  "home",
  "finance",
  "books",
  "photography",
  "other",
];

const platforms = [
  "instagram",
  "tiktok",
  "youtube",
  "twitter",
  "facebook",
  "linkedin",
  "twitch",
  "snapchat",
];

const contentTypes = [
  "post",
  "story",
  "reel",
  "video",
  "article",
  "review",
  "unboxing",
  "tutorial",
  "other",
];

const collaborationTypes = [
  "sponsored-post",
  "product-review",
  "brand-ambassador",
  "event-coverage",
  "giveaway",
  "takeover",
  "affiliate",
  "other",
];

const aesthetics = [
  "minimalist",
  "colorful",
  "dark",
  "bright",
  "vintage",
  "modern",
  "artistic",
  "lifestyle",
];

const toneOfVoice = [
  "professional",
  "casual",
  "humorous",
  "inspirational",
  "educational",
  "friendly",
  "authoritative",
];

const contentFrequency = [
  "daily",
  "multiple-daily",
  "weekly",
  "bi-weekly",
  "irregular",
];

const EnhancedInfluencerProfileForm: React.FC<
  EnhancedInfluencerProfileFormProps
> = ({ onSubmit, initialData = {}, isLoading = false }) => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    bio: "",
    profileImage: "",
    location: {
      country: "",
      city: "",
    },
    socialPlatforms: [],
    categories: [],
    demographics: {
      ageGroup: "",
      gender: "",
      primaryAudience: {
        ageGroup: "",
        gender: "",
        locations: [],
        interests: [],
        languages: [],
      },
    },
    languages: [],
    contentTypes: [],
    collaborationTypes: [],
    pastBrands: [],
    excludedBrands: [],
    brandAffinities: [],
    personalityTraits: {
      authenticity: 5,
      creativity: 5,
      professionalism: 5,
      reliability: 5,
    },
    contentStyle: {
      visualAesthetic: "",
      toneOfVoice: "",
      contentFrequency: "",
    },
    performanceMetrics: {
      averageViewsPerPost: 0,
      averageLikesPerPost: 0,
      averageCommentsPerPost: 0,
      averageSharesPerPost: 0,
      bestPerformingContentType: "",
      peakEngagementHours: [],
    },
    pricing: {
      postPrice: 0,
      storyPrice: 0,
      videoPrice: 0,
      reelPrice: 0,
      packageDeals: [],
      currency: "USD",
      negotiable: true,
    },
    portfolio: [],
    availability: {
      status: "available",
      nextAvailable: "",
    },
    tags: [],
    ...initialData,
  });

  const updateFormData = (path: string, value: any) => {
    setFormData((prev) => {
      const keys = path.split(".");
      const newData = { ...prev };
      let current = newData;

      for (let i = 0; i < keys.length - 1; i++) {
        if (!current[keys[i]]) current[keys[i]] = {};
        current = current[keys[i]];
      }

      current[keys[keys.length - 1]] = value;
      return newData;
    });
  };

  const addToArray = (path: string, value: any) => {
    const keys = path.split(".");
    let current = formData;
    for (const key of keys.slice(0, -1)) {
      current = current[key];
    }
    const arrayKey = keys[keys.length - 1];
    const currentArray = current[arrayKey] || [];

    updateFormData(path, [...currentArray, value]);
  };

  const removeFromArray = (path: string, index: number) => {
    const keys = path.split(".");
    let current = formData;
    for (const key of keys.slice(0, -1)) {
      current = current[key];
    }
    const arrayKey = keys[keys.length - 1];
    const currentArray = current[arrayKey] || [];

    updateFormData(
      path,
      currentArray.filter((_, i) => i !== index)
    );
  };

  const addSocialPlatform = () => {
    const newPlatform = {
      platform: "",
      username: "",
      followerCount: 0,
      engagementRate: 0,
      profileUrl: "",
    };
    addToArray("socialPlatforms", newPlatform);
  };

  const addPastBrand = () => {
    const newBrand = {
      name: "",
      category: "",
      collaborationType: "",
      year: new Date().getFullYear(),
    };
    addToArray("pastBrands", newBrand);
  };

  const addPortfolioItem = () => {
    const newItem = {
      title: "",
      description: "",
      imageUrl: "",
      videoUrl: "",
      platform: "",
      metrics: {
        views: 0,
        likes: 0,
        comments: 0,
        shares: 0,
      },
      brandName: "",
      campaignType: "",
      date: new Date().toISOString().split("T")[0],
    };
    addToArray("portfolio", newItem);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formData);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <Tabs defaultValue="basic" className="w-full">
        <TabsList className="grid w-full grid-cols-6">
          <TabsTrigger value="basic">Basic Info</TabsTrigger>
          <TabsTrigger value="social">Social Media</TabsTrigger>
          <TabsTrigger value="content">Content Style</TabsTrigger>
          <TabsTrigger value="personality">Personality</TabsTrigger>
          <TabsTrigger value="portfolio">Portfolio</TabsTrigger>
          <TabsTrigger value="pricing">Pricing</TabsTrigger>
        </TabsList>

        <TabsContent value="basic" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Basic Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="name">Full Name *</Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => updateFormData("name", e.target.value)}
                    placeholder="Enter your full name"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="email">Email *</Label>
                  <Input
                    id="email"
                    type="email"
                    value={formData.email}
                    onChange={(e) => updateFormData("email", e.target.value)}
                    placeholder="your@email.com"
                    required
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="bio">Bio</Label>
                <Textarea
                  id="bio"
                  value={formData.bio}
                  onChange={(e) => updateFormData("bio", e.target.value)}
                  placeholder="Tell us about yourself and your content..."
                  rows={4}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="country">Country</Label>
                  <Input
                    id="country"
                    value={formData.location.country}
                    onChange={(e) =>
                      updateFormData("location.country", e.target.value)
                    }
                    placeholder="Your country"
                  />
                </div>
                <div>
                  <Label htmlFor="city">City</Label>
                  <Input
                    id="city"
                    value={formData.location.city}
                    onChange={(e) =>
                      updateFormData("location.city", e.target.value)
                    }
                    placeholder="Your city"
                  />
                </div>
              </div>

              <div>
                <Label>Content Categories</Label>
                <div className="grid grid-cols-4 gap-2 mt-2">
                  {categories.map((category) => (
                    <div key={category} className="flex items-center space-x-2">
                      <Checkbox
                        id={category}
                        checked={formData.categories.includes(category)}
                        onCheckedChange={(checked) => {
                          if (checked) {
                            updateFormData("categories", [
                              ...formData.categories,
                              category,
                            ]);
                          } else {
                            updateFormData(
                              "categories",
                              formData.categories.filter((c) => c !== category)
                            );
                          }
                        }}
                      />
                      <Label htmlFor={category} className="text-sm">
                        {category.charAt(0).toUpperCase() + category.slice(1)}
                      </Label>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Demographics & Audience</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="ageGroup">Your Age Group</Label>
                  <Select
                    value={formData.demographics.ageGroup}
                    onValueChange={(value) =>
                      updateFormData("demographics.ageGroup", value)
                    }
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select age group" />
                    </SelectTrigger>
                    <SelectContent>
                      {[
                        "13-17",
                        "18-24",
                        "25-34",
                        "35-44",
                        "45-54",
                        "55-64",
                        "65+",
                      ].map((age) => (
                        <SelectItem key={age} value={age}>
                          {age}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="gender">Gender</Label>
                  <Select
                    value={formData.demographics.gender}
                    onValueChange={(value) =>
                      updateFormData("demographics.gender", value)
                    }
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select gender" />
                    </SelectTrigger>
                    <SelectContent>
                      {[
                        "male",
                        "female",
                        "non-binary",
                        "prefer-not-to-say",
                      ].map((gender) => (
                        <SelectItem key={gender} value={gender}>
                          {gender.charAt(0).toUpperCase() +
                            gender.slice(1).replace("-", " ")}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <Label>Primary Audience Demographics</Label>
                <div className="grid grid-cols-2 gap-4 mt-2">
                  <div>
                    <Label className="text-sm">Audience Age Group</Label>
                    <Select
                      value={formData.demographics.primaryAudience.ageGroup}
                      onValueChange={(value) =>
                        updateFormData(
                          "demographics.primaryAudience.ageGroup",
                          value
                        )
                      }
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select audience age" />
                      </SelectTrigger>
                      <SelectContent>
                        {[
                          "13-17",
                          "18-24",
                          "25-34",
                          "35-44",
                          "45-54",
                          "55-64",
                          "65+",
                        ].map((age) => (
                          <SelectItem key={age} value={age}>
                            {age}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label className="text-sm">Audience Gender</Label>
                    <Select
                      value={formData.demographics.primaryAudience.gender}
                      onValueChange={(value) =>
                        updateFormData(
                          "demographics.primaryAudience.gender",
                          value
                        )
                      }
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select audience gender" />
                      </SelectTrigger>
                      <SelectContent>
                        {["male", "female", "mixed", "other"].map((gender) => (
                          <SelectItem key={gender} value={gender}>
                            {gender.charAt(0).toUpperCase() + gender.slice(1)}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="social" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                Social Media Platforms
                <Button type="button" onClick={addSocialPlatform} size="sm">
                  <PlusCircle className="w-4 h-4 mr-2" />
                  Add Platform
                </Button>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {formData.socialPlatforms.map((platform, index) => (
                <div key={index} className="border p-4 rounded-lg space-y-3">
                  <div className="flex justify-between items-center">
                    <h4 className="font-medium">Platform {index + 1}</h4>
                    <Button
                      type="button"
                      onClick={() => removeFromArray("socialPlatforms", index)}
                      size="sm"
                      variant="outline"
                    >
                      <X className="w-4 h-4" />
                    </Button>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <Label>Platform</Label>
                      <Select
                        value={platform.platform}
                        onValueChange={(value) =>
                          updateFormData(
                            `socialPlatforms.${index}.platform`,
                            value
                          )
                        }
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select platform" />
                        </SelectTrigger>
                        <SelectContent>
                          {platforms.map((p) => (
                            <SelectItem key={p} value={p}>
                              {p.charAt(0).toUpperCase() + p.slice(1)}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label>Username</Label>
                      <Input
                        value={platform.username}
                        onChange={(e) =>
                          updateFormData(
                            `socialPlatforms.${index}.username`,
                            e.target.value
                          )
                        }
                        placeholder="@username"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <Label>Followers</Label>
                      <Input
                        type="number"
                        value={platform.followerCount}
                        onChange={(e) =>
                          updateFormData(
                            `socialPlatforms.${index}.followerCount`,
                            parseInt(e.target.value) || 0
                          )
                        }
                        placeholder="Number of followers"
                      />
                    </div>
                    <div>
                      <Label>Engagement Rate (%)</Label>
                      <Input
                        type="number"
                        step="0.1"
                        value={platform.engagementRate}
                        onChange={(e) =>
                          updateFormData(
                            `socialPlatforms.${index}.engagementRate`,
                            parseFloat(e.target.value) || 0
                          )
                        }
                        placeholder="e.g., 3.5"
                      />
                    </div>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="content" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Content Style & Preferences</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label>Content Types You Create</Label>
                <div className="grid grid-cols-3 gap-2 mt-2">
                  {contentTypes.map((type) => (
                    <div key={type} className="flex items-center space-x-2">
                      <Checkbox
                        id={type}
                        checked={formData.contentTypes.includes(type)}
                        onCheckedChange={(checked) => {
                          if (checked) {
                            updateFormData("contentTypes", [
                              ...formData.contentTypes,
                              type,
                            ]);
                          } else {
                            updateFormData(
                              "contentTypes",
                              formData.contentTypes.filter((t) => t !== type)
                            );
                          }
                        }}
                      />
                      <Label htmlFor={type} className="text-sm">
                        {type.charAt(0).toUpperCase() +
                          type.slice(1).replace("-", " ")}
                      </Label>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <Label>Visual Aesthetic</Label>
                <Select
                  value={formData.contentStyle.visualAesthetic}
                  onValueChange={(value) =>
                    updateFormData("contentStyle.visualAesthetic", value)
                  }
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select your visual style" />
                  </SelectTrigger>
                  <SelectContent>
                    {aesthetics.map((aesthetic) => (
                      <SelectItem key={aesthetic} value={aesthetic}>
                        {aesthetic.charAt(0).toUpperCase() + aesthetic.slice(1)}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label>Tone of Voice</Label>
                <Select
                  value={formData.contentStyle.toneOfVoice}
                  onValueChange={(value) =>
                    updateFormData("contentStyle.toneOfVoice", value)
                  }
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select your tone" />
                  </SelectTrigger>
                  <SelectContent>
                    {toneOfVoice.map((tone) => (
                      <SelectItem key={tone} value={tone}>
                        {tone.charAt(0).toUpperCase() + tone.slice(1)}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label>Content Frequency</Label>
                <Select
                  value={formData.contentStyle.contentFrequency}
                  onValueChange={(value) =>
                    updateFormData("contentStyle.contentFrequency", value)
                  }
                >
                  <SelectTrigger>
                    <SelectValue placeholder="How often do you post?" />
                  </SelectTrigger>
                  <SelectContent>
                    {contentFrequency.map((freq) => (
                      <SelectItem key={freq} value={freq}>
                        {freq.charAt(0).toUpperCase() +
                          freq.slice(1).replace("-", " ")}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="personality" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Personality Traits</CardTitle>
              <p className="text-sm text-muted-foreground">
                Rate yourself on a scale of 1-10
              </p>
            </CardHeader>
            <CardContent className="space-y-6">
              {Object.entries(formData.personalityTraits).map(
                ([trait, value]) => (
                  <div key={trait} className="space-y-2">
                    <div className="flex justify-between">
                      <Label className="capitalize">{trait}</Label>
                      <span className="text-sm font-medium">{value}/10</span>
                    </div>
                    <Slider
                      value={[value]}
                      onValueChange={(values) =>
                        updateFormData(`personalityTraits.${trait}`, values[0])
                      }
                      min={1}
                      max={10}
                      step={1}
                      className="w-full"
                    />
                  </div>
                )
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="pricing" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Pricing Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="postPrice">Post Price (USD)</Label>
                  <Input
                    id="postPrice"
                    type="number"
                    value={formData.pricing.postPrice}
                    onChange={(e) =>
                      updateFormData(
                        "pricing.postPrice",
                        parseInt(e.target.value) || 0
                      )
                    }
                    placeholder="Price per post"
                  />
                </div>
                <div>
                  <Label htmlFor="storyPrice">Story Price (USD)</Label>
                  <Input
                    id="storyPrice"
                    type="number"
                    value={formData.pricing.storyPrice}
                    onChange={(e) =>
                      updateFormData(
                        "pricing.storyPrice",
                        parseInt(e.target.value) || 0
                      )
                    }
                    placeholder="Price per story"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="reelPrice">Reel Price (USD)</Label>
                  <Input
                    id="reelPrice"
                    type="number"
                    value={formData.pricing.reelPrice}
                    onChange={(e) =>
                      updateFormData(
                        "pricing.reelPrice",
                        parseInt(e.target.value) || 0
                      )
                    }
                    placeholder="Price per reel"
                  />
                </div>
                <div>
                  <Label htmlFor="videoPrice">Video Price (USD)</Label>
                  <Input
                    id="videoPrice"
                    type="number"
                    value={formData.pricing.videoPrice}
                    onChange={(e) =>
                      updateFormData(
                        "pricing.videoPrice",
                        parseInt(e.target.value) || 0
                      )
                    }
                    placeholder="Price per video"
                  />
                </div>
              </div>

              <div className="flex items-center space-x-2">
                <Checkbox
                  id="negotiable"
                  checked={formData.pricing.negotiable}
                  onCheckedChange={(checked) =>
                    updateFormData("pricing.negotiable", checked)
                  }
                />
                <Label htmlFor="negotiable">Prices are negotiable</Label>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <div className="flex justify-end space-x-4">
        <Button type="button" variant="outline">
          Save as Draft
        </Button>
        <Button type="submit" disabled={isLoading}>
          {isLoading ? "Saving..." : "Save Profile"}
        </Button>
      </div>
    </form>
  );
};

export default EnhancedInfluencerProfileForm;
