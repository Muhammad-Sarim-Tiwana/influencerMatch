import React, { useState, useEffect, useRef } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Send, ArrowLeft, Clock, CheckCircle } from "lucide-react";
import {
  firebaseChatService,
  ChatMessage,
  ChatConversation,
} from "@/services/firebaseChatService";
import { useAuthStore } from "@/store/authStore";
import { useToast } from "@/hooks/use-toast";
import { useNavigate } from "react-router-dom";

interface ChatProps {
  conversationId?: string;
  recipientId?: string;
  recipientName?: string;
  recipientRole?: "influencer" | "brand" | "superadmin";
  onBack?: () => void;
}

const Chat: React.FC<ChatProps> = ({
  conversationId: initialConversationId,
  recipientId,
  recipientName,
  recipientRole,
  onBack,
}) => {
  const { user } = useAuthStore();
  const { toast } = useToast();
  const navigate = useNavigate();
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [newMessage, setNewMessage] = useState("");
  const [conversationId, setConversationId] = useState<string | null>(
    initialConversationId || null
  );
  const [isLoading, setIsLoading] = useState(false);
  const [isSending, setIsSending] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const [otherParticipant, setOtherParticipant] = useState<{
    name: string;
    role: "influencer" | "brand" | "superadmin";
  } | null>(null);
  const [campaignInfo, setCampaignInfo] = useState<{
    id: string;
    title: string;
  } | null>(null);

  useEffect(() => {
    if (initialConversationId) {
      setConversationId(initialConversationId);
      loadConversationDetails(initialConversationId);
    } else if (recipientId && recipientName && recipientRole && user) {
      initializeConversation();
    }
  }, [initialConversationId, recipientId, recipientName, recipientRole, user]);

  const loadConversationDetails = async (convId: string) => {
    try {
      const conversation = await firebaseChatService.getConversation(convId);
      if (conversation && user?.id) {
        // Find the other participant
        const otherParticipantId = Object.keys(conversation.participants).find(
          (id) => id !== user.id
        );

        if (otherParticipantId) {
          const participant = conversation.participants[otherParticipantId];
          setOtherParticipant({
            name: participant.name,
            role: participant.role,
          });
        }

        // Set campaign info if available
        if (conversation.campaignId && conversation.campaignTitle) {
          setCampaignInfo({
            id: conversation.campaignId,
            title: conversation.campaignTitle,
          });
        }
      }
    } catch (error) {
      console.error("Failed to load conversation details:", error);
    }
  };

  useEffect(() => {
    if (conversationId && user?.id) {
      console.log(
        "Setting up message listener for conversation:",
        conversationId
      );

      const unsubscribe = firebaseChatService.listenToMessagesWithNotifications(
        conversationId,
        user.id,
        (newMessages, newMessage) => {
          console.log("🔄 Received messages update:", {
            messageCount: newMessages.length,
            newMessage: newMessage
              ? `${newMessage.senderName}: ${newMessage.text}`
              : null,
            currentUserId: user.id,
            currentUserRole: user.role,
          });

          setMessages(newMessages);
          scrollToBottom();

          // Show toast notification for new messages from other users
          if (newMessage && newMessage.senderId !== user.id) {
            toast({
              title: `New message from ${newMessage.senderName}`,
              description:
                newMessage.text.length > 50
                  ? `${newMessage.text.substring(0, 50)}...`
                  : newMessage.text,
              duration: 4000,
            });
          }

          // Mark messages as read
          firebaseChatService.markAsRead(conversationId, user.id);
        }
      );

      return unsubscribe;
    }
  }, [conversationId, user?.id, toast]);

  const initializeConversation = async () => {
    if (!user || !recipientId || !recipientName || !recipientRole) {
      console.error(
        "❌ Missing required data for conversation initialization:",
        {
          user: !!user,
          recipientId: !!recipientId,
          recipientName: !!recipientName,
          recipientRole: !!recipientRole,
        }
      );
      return;
    }

    console.log("🚀 Initializing conversation with:", {
      currentUser: { id: user.id, name: user.name, role: user.role },
      recipient: { id: recipientId, name: recipientName, role: recipientRole },
    });

    setIsLoading(true);
    try {
      const newConversationId =
        await firebaseChatService.createOrGetConversation(
          user.id,
          user.name,
          user.role as "influencer" | "brand" | "superadmin",
          recipientId,
          recipientName,
          recipientRole
        );

      console.log("✅ Conversation initialized:", newConversationId);
      setConversationId(newConversationId);
      setOtherParticipant({ name: recipientName, role: recipientRole });
    } catch (error) {
      console.error("❌ Failed to initialize conversation:", error);

      // More detailed error handling
      let errorMessage = "Failed to start conversation. Please try again.";

      if (error instanceof Error) {
        if (error.message.includes("Firebase")) {
          errorMessage =
            "Firebase connection issue. Please check your internet connection.";
        } else if (error.message.includes("permission")) {
          errorMessage = "Permission denied. Please contact support.";
        } else if (error.message.includes("network")) {
          errorMessage =
            "Network error. Please check your connection and try again.";
        } else {
          errorMessage = `Error: ${error.message}`;
        }
      }

      toast({
        title: "Error",
        description: errorMessage,
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = async () => {
    if (!newMessage.trim() || !conversationId || !user || isSending) {
      return;
    }

    setIsSending(true);
    try {
      await firebaseChatService.sendMessage(
        conversationId,
        user.id,
        user.name,
        user.role as "influencer" | "brand" | "superadmin",
        newMessage.trim()
      );

      setNewMessage("");
    } catch (error) {
      console.error("❌ Failed to send message:", error);
      toast({
        title: "Error",
        description: "Failed to send message. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSending(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  if (isLoading) {
    return (
      <Card className="h-[600px] flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Starting conversation...</p>
        </div>
      </Card>
    );
  }

  if (!conversationId) {
    return (
      <Card className="h-[600px] flex items-center justify-center">
        <div className="text-center">
          <p className="text-muted-foreground">
            Unable to load conversation. Please try again.
          </p>
          {onBack && (
            <Button onClick={onBack} variant="outline" className="mt-4">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Go Back
            </Button>
          )}
        </div>
      </Card>
    );
  }

  const getParticipantName = () => {
    if (otherParticipant) {
      return otherParticipant.name;
    }
    if (recipientName) {
      return recipientName;
    }
    return "Unknown User";
  };

  const getRoleBadgeColor = (role: string) => {
    switch (role) {
      case "brand":
        return "bg-blue-100 text-blue-800";
      case "influencer":
        return "bg-green-100 text-green-800";
      case "superadmin":
        return "bg-purple-100 text-purple-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <Card className="h-[600px] flex flex-col">
      <CardHeader className="flex-shrink-0 border-b">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            {onBack && (
              <Button onClick={onBack} variant="ghost" size="sm">
                <ArrowLeft className="w-4 h-4" />
              </Button>
            )}
            <Avatar className="h-8 w-8">
              <AvatarImage src="" />
              <AvatarFallback className="text-sm">
                {getParticipantName()
                  .split(" ")
                  .map((n) => n[0])
                  .join("")
                  .toUpperCase()}
              </AvatarFallback>
            </Avatar>
            <div>
              <CardTitle className="text-lg">{getParticipantName()}</CardTitle>
              <div className="flex items-center space-x-2">
                <Badge
                  variant="secondary"
                  className={getRoleBadgeColor(
                    otherParticipant?.role || recipientRole || "unknown"
                  )}
                >
                  {(otherParticipant?.role || recipientRole || "unknown")
                    .charAt(0)
                    .toUpperCase() +
                    (
                      otherParticipant?.role ||
                      recipientRole ||
                      "unknown"
                    ).slice(1)}
                </Badge>
                {campaignInfo && (
                  <Badge variant="outline" className="text-xs">
                    📋 {campaignInfo.title}
                  </Badge>
                )}
              </div>
            </div>
          </div>
        </div>
      </CardHeader>

      <CardContent className="flex-1 flex flex-col p-0">
        <ScrollArea className="flex-1 p-4">
          {messages.length === 0 ? (
            <div className="flex items-center justify-center h-full text-muted-foreground">
              <div className="text-center">
                <div className="text-4xl mb-2">💬</div>
                <p>Start your conversation!</p>
                <p className="text-sm">Send a message to get started.</p>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              {messages.map((message) => {
                const isCurrentUser = message.senderId === user?.id;
                return (
                  <div
                    key={message.id}
                    className={`flex ${
                      isCurrentUser ? "justify-end" : "justify-start"
                    }`}
                  >
                    <div
                      className={`max-w-[70%] rounded-lg p-3 ${
                        isCurrentUser
                          ? "bg-primary text-primary-foreground"
                          : "bg-muted"
                      }`}
                    >
                      {!isCurrentUser && (
                        <div className="flex items-center space-x-2 mb-1">
                          <span className="text-xs font-medium">
                            {message.senderName}
                          </span>
                          <Badge
                            variant="secondary"
                            className={`text-xs ${getRoleBadgeColor(
                              message.senderRole
                            )}`}
                          >
                            {message.senderRole.charAt(0).toUpperCase() +
                              message.senderRole.slice(1)}
                          </Badge>
                        </div>
                      )}
                      <p className="whitespace-pre-wrap break-words">
                        {message.text}
                      </p>
                      <div
                        className={`flex items-center space-x-1 mt-2 text-xs ${
                          isCurrentUser
                            ? "text-primary-foreground/70"
                            : "text-muted-foreground"
                        }`}
                      >
                        {isCurrentUser ? (
                          <CheckCircle className="w-3 h-3" />
                        ) : (
                          <Clock className="w-3 h-3" />
                        )}
                        <span>
                          {new Date(message.timestamp).toLocaleTimeString([], {
                            hour: "2-digit",
                            minute: "2-digit",
                          })}
                        </span>
                      </div>
                    </div>
                  </div>
                );
              })}
              <div ref={messagesEndRef} />
            </div>
          )}
        </ScrollArea>

        <div className="border-t p-4">
          <div className="flex space-x-2">
            <Input
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Type your message..."
              disabled={isSending}
              className="flex-1"
            />
            <Button
              onClick={handleSendMessage}
              disabled={!newMessage.trim() || isSending}
              size="sm"
            >
              {isSending ? (
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
              ) : (
                <Send className="w-4 h-4" />
              )}
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default Chat;
