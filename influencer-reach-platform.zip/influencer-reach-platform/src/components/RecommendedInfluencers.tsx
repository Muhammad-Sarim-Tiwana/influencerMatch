import { useState, useEffect } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "@/components/ui/carousel";
import { Skeleton } from "@/components/ui/skeleton";
import { campaignService } from "@/services/campaignService";
import { toast } from "@/hooks/use-toast";
import { Users, TrendingUp, Star, Sparkles, MessageCircle } from "lucide-react";
import { useNavigate } from "react-router-dom";

interface RecommendedInfluencersProps {
  campaignId: string;
}

interface InfluencerRecommendation {
  id: string;
  name?: string;
  score: number;
  matchLevel: "excellent" | "good" | "fair" | "poor";
  reasons: string[];
  strengths: string[];
  concerns: string[];
  recommendations: string[];
  estimatedROI: number;
  budgetFit: "above" | "within" | "below";
  deliverableMatch: {
    [key: string]: boolean;
  };
  audienceInsights: {
    primaryDemographic: string;
    locationMatch: string;
    languageMatch: string;
  };
  riskLevel: "low" | "medium" | "high";
  timelineCompatibility: "excellent" | "good" | "concerning";
  influencer?: {
    _id: string;
    name: string;
    username?: string;
    profilePicture?: string;
    categories: string[];
    platforms: string[];
    totalFollowers: number;
    averageEngagementRate: number;
    rating: number;
    verificationStatus: string;
    bio?: string;
  };
  aiInsights: string;
}

const RecommendedInfluencers = ({
  campaignId,
}: RecommendedInfluencersProps) => {
  const [recommendations, setRecommendations] = useState<
    InfluencerRecommendation[]
  >([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const navigate = useNavigate();

  useEffect(() => {
    loadRecommendations();
  }, [campaignId]);

  const loadRecommendations = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const response = await campaignService.getPublicRecommendations(
        campaignId
      );
      console.log("API Response:", response);

      // Handle different response structures - the API client might return data directly or wrapped
      const responseData = response as any;
      const recommendations =
        responseData.recommendations ||
        responseData.data?.recommendations ||
        [];
      console.log("Extracted recommendations:", recommendations);
      console.log("Number of recommendations:", recommendations.length);
      setRecommendations(recommendations);
    } catch (error: any) {
      console.error("Failed to load recommendations:", error);
      setError("Failed to load recommendations");
      toast({
        title: "Error",
        description: "Failed to load influencer recommendations.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const formatFollowers = (count: number) => {
    if (count >= 1000000) {
      return `${(count / 1000000).toFixed(1)}M`;
    } else if (count >= 1000) {
      return `${(count / 1000).toFixed(1)}K`;
    }
    return count.toString();
  };

  const handleInfluencerClick = (influencerId: string) => {
    navigate(`/influencer-profile/${influencerId}?campaignId=${campaignId}`);
  };

  if (error && !isLoading) {
    return null; // Don't show anything if there's an error
  }

  console.log("Current recommendations state:", recommendations);
  console.log("Is loading:", isLoading);
  console.log("Error:", error);

  return (
    <Card className="mt-8">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Sparkles className="h-5 w-5 text-purple-600" />
          AI-Recommended Influencers
        </CardTitle>
        <CardDescription>
          Discover the most suitable influencers for this campaign, powered by
          AI analysis
        </CardDescription>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="flex space-x-4 overflow-hidden">
            {[...Array(4)].map((_, index) => (
              <div key={index} className="flex-shrink-0 w-80">
                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center space-x-3 mb-3">
                      <Skeleton className="h-12 w-12 rounded-full" />
                      <div>
                        <Skeleton className="h-4 w-24 mb-2" />
                        <Skeleton className="h-3 w-16" />
                      </div>
                    </div>
                    <Skeleton className="h-3 w-full mb-2" />
                    <Skeleton className="h-3 w-3/4 mb-3" />
                    <div className="flex gap-2">
                      <Skeleton className="h-6 w-16" />
                      <Skeleton className="h-6 w-20" />
                    </div>
                  </CardContent>
                </Card>
              </div>
            ))}
          </div>
        ) : recommendations.length === 0 ? (
          <div className="text-center py-8 text-gray-500">
            <Users className="h-12 w-12 mx-auto mb-4 opacity-50" />
            <p>No recommended influencers available for this campaign.</p>
          </div>
        ) : (
          <Carousel
            opts={{
              align: "start",
            }}
            className="w-full"
          >
            <CarouselContent>
              {recommendations
                .filter((recommendation) => recommendation?.influencer?._id) // Filter out invalid recommendations
                .map((recommendation, index) => (
                  <CarouselItem
                    key={`${recommendation.influencer._id}-${index}`}
                    className="md:basis-1/2 lg:basis-1/3 xl:basis-1/4"
                  >
                    <Card
                      className="h-full cursor-pointer hover:shadow-lg transition-shadow duration-200 border-2 hover:border-purple-200"
                      onClick={() =>
                        handleInfluencerClick(recommendation.influencer._id)
                      }
                    >
                      <CardContent className="p-4">
                        {/* Header with Avatar and Basic Info */}
                        <div className="flex items-center space-x-3 mb-3">
                          <Avatar className="h-12 w-12">
                            <AvatarImage
                              src={recommendation.influencer.profilePicture}
                              alt={recommendation.influencer.name}
                            />
                            <AvatarFallback>
                              {recommendation.influencer.name
                                .split(" ")
                                .map((n) => n[0])
                                .join("")}
                            </AvatarFallback>
                          </Avatar>
                          <div className="flex-1 min-w-0">
                            <h4 className="font-semibold text-sm truncate">
                              {recommendation.influencer.name}
                            </h4>
                            {recommendation.influencer.username && (
                              <p className="text-xs text-gray-500 truncate">
                                @{recommendation.influencer.username}
                              </p>
                            )}
                          </div>
                          <Badge
                            variant="secondary"
                            className="bg-purple-100 text-purple-800 text-xs px-2 py-1"
                          >
                            {recommendation.score}%
                          </Badge>
                        </div>

                        {/* Bio */}
                        {recommendation.influencer.bio && (
                          <p className="text-xs text-gray-600 mb-3 overflow-hidden">
                            <span className="block max-h-8 overflow-hidden">
                              {recommendation.influencer.bio.length > 80
                                ? `${recommendation.influencer.bio.substring(
                                    0,
                                    80
                                  )}...`
                                : recommendation.influencer.bio}
                            </span>
                          </p>
                        )}

                        {/* Stats */}
                        <div className="grid grid-cols-2 gap-2 mb-3 text-xs">
                          <div className="flex items-center gap-1">
                            <Users className="h-3 w-3 text-blue-500" />
                            <span className="font-medium">
                              {formatFollowers(
                                recommendation.influencer.totalFollowers
                              )}
                            </span>
                          </div>
                          <div className="flex items-center gap-1">
                            <TrendingUp className="h-3 w-3 text-green-500" />
                            <span className="font-medium">
                              {(
                                recommendation.influencer
                                  .averageEngagementRate || 0
                              ).toFixed(1)}
                              %
                            </span>
                          </div>
                          <div className="flex items-center gap-1">
                            <Star className="h-3 w-3 text-yellow-500" />
                            <span className="font-medium">
                              {(recommendation.influencer.rating || 0).toFixed(
                                1
                              )}
                            </span>
                          </div>
                          <div className="flex items-center gap-1">
                            <span
                              className={`h-2 w-2 rounded-full ${
                                recommendation.influencer.verificationStatus ===
                                "verified"
                                  ? "bg-green-500"
                                  : "bg-gray-400"
                              }`}
                            />
                            <span className="text-xs">
                              {recommendation.influencer.verificationStatus ===
                              "verified"
                                ? "Verified"
                                : "Unverified"}
                            </span>
                          </div>
                        </div>

                        {/* Categories */}
                        <div className="flex flex-wrap gap-1 mb-3">
                          {recommendation.influencer.categories
                            .slice(0, 2)
                            .map((category, idx) => (
                              <Badge
                                key={idx}
                                variant="outline"
                                className="text-xs px-2 py-0"
                              >
                                {category}
                              </Badge>
                            ))}
                          {recommendation.influencer.categories.length > 2 && (
                            <Badge
                              variant="outline"
                              className="text-xs px-2 py-0"
                            >
                              +{recommendation.influencer.categories.length - 2}
                            </Badge>
                          )}
                        </div>

                        {/* AI Insights */}
                        <div className="bg-purple-50 rounded-lg p-2 mb-3">
                          <p className="text-xs text-purple-700 font-medium mb-1">
                            AI Insight:
                          </p>
                          <p className="text-xs text-purple-600 overflow-hidden">
                            <span className="block max-h-8 overflow-hidden">
                              {recommendation.aiInsights.length > 100
                                ? `${recommendation.aiInsights.substring(
                                    0,
                                    100
                                  )}...`
                                : recommendation.aiInsights}
                            </span>
                          </p>
                        </div>

                        {/* Action Button */}
                        <Button
                          size="sm"
                          className="w-full bg-purple-600 hover:bg-purple-700 text-white"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleInfluencerClick(
                              recommendation.influencer._id
                            );
                          }}
                        >
                          <MessageCircle className="h-3 w-3 mr-1" />
                          View Profile
                        </Button>
                      </CardContent>
                    </Card>
                  </CarouselItem>
                ))}
            </CarouselContent>
            <CarouselPrevious />
            <CarouselNext />
          </Carousel>
        )}
      </CardContent>
    </Card>
  );
};

export default RecommendedInfluencers;
