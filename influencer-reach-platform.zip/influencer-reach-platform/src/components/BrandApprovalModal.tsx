import React, { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import brandService, { BrandProfile } from "@/services/brandService";
import { toast } from "@/hooks/use-toast";
import {
  Building2,
  MapPin,
  Globe,
  Users,
  DollarSign,
  Calendar,
  CheckCircle,
  XCircle,
  Clock,
  Loader2,
} from "lucide-react";

interface BrandApprovalModalProps {
  brand: BrandProfile | null;
  isOpen: boolean;
  onClose: () => void;
  onApprove: (brandId: string) => void;
  onReject: (brandId: string) => void;
}

const BrandApprovalModal: React.FC<BrandApprovalModalProps> = ({
  brand,
  isOpen,
  onClose,
  onApprove,
  onReject,
}) => {
  const [isApproving, setIsApproving] = useState(false);
  const [isRejecting, setIsRejecting] = useState(false);

  useEffect(() => {
    // Reset state when modal closes
    if (!isOpen) {
      setIsApproving(false);
      setIsRejecting(false);
    }
  }, [isOpen]);

  const handleApprove = async () => {
    if (!brand) return;

    setIsApproving(true);
    try {
      await brandService.approveBrand(brand.id);
      toast({
        title: "Brand Approved",
        description: `${brand.companyName} has been approved and activated.`,
      });
      onApprove(brand.id);
      onClose();
    } catch (error: any) {
      toast({
        title: "Approval Failed",
        description: error.message || "Failed to approve brand",
        variant: "destructive",
      });
    } finally {
      setIsApproving(false);
    }
  };

  const handleReject = async () => {
    if (!brand) return;

    setIsRejecting(true);
    try {
      await brandService.rejectBrand(brand.id);
      toast({
        title: "Brand Rejected",
        description: `${brand.companyName} has been rejected.`,
      });
      onReject(brand.id);
      onClose();
    } catch (error: any) {
      toast({
        title: "Rejection Failed",
        description: error.message || "Failed to reject brand",
        variant: "destructive",
      });
    } finally {
      setIsRejecting(false);
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "pending":
        return (
          <Badge
            variant="outline"
            className="text-yellow-600 border-yellow-300"
          >
            <Clock className="w-3 h-3 mr-1" />
            Pending Review
          </Badge>
        );
      case "verified":
        return (
          <Badge variant="outline" className="text-green-600 border-green-300">
            <CheckCircle className="w-3 h-3 mr-1" />
            Verified
          </Badge>
        );
      case "rejected":
        return (
          <Badge variant="outline" className="text-red-600 border-red-300">
            <XCircle className="w-3 h-3 mr-1" />
            Rejected
          </Badge>
        );
      default:
        return null;
    }
  };

  if (!brand) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-3">
            <Building2 className="h-6 w-6" />
            Brand Profile Review: {brand.companyName}
          </DialogTitle>
          <DialogDescription>
            Review the brand information below and decide whether to approve or
            reject this profile.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* Status and Basic Info */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg">Company Information</CardTitle>
                {getStatusBadge(brand.verificationStatus)}
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-sm font-medium text-gray-500">
                    Company Name
                  </Label>
                  <p className="font-medium">{brand.companyName}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium text-gray-500">
                    Industry
                  </Label>
                  <p className="capitalize">
                    {brand.industry.replace("-", " ")}
                  </p>
                </div>
                <div>
                  <Label className="text-sm font-medium text-gray-500">
                    Company Type
                  </Label>
                  <p className="capitalize">
                    {brand.companyType.replace("-", " ")}
                  </p>
                </div>
                <div>
                  <Label className="text-sm font-medium text-gray-500">
                    Team Size
                  </Label>
                  <p>{brand.teamSize}</p>
                </div>
              </div>

              {brand.description && (
                <div>
                  <Label className="text-sm font-medium text-gray-500">
                    Description
                  </Label>
                  <p className="text-sm text-gray-700 mt-1">
                    {brand.description}
                  </p>
                </div>
              )}

              <div className="flex items-center gap-4 text-sm text-gray-600">
                {brand.website && (
                  <div className="flex items-center gap-1">
                    <Globe className="h-4 w-4" />
                    <a
                      href={brand.website}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-blue-600 hover:underline"
                    >
                      {brand.website}
                    </a>
                  </div>
                )}
                {brand.founded && (
                  <div className="flex items-center gap-1">
                    <Calendar className="h-4 w-4" />
                    <span>Founded {brand.founded}</span>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Contact Information */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Contact Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-sm font-medium text-gray-500">
                    Contact Email
                  </Label>
                  <p>{brand.user.email}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium text-gray-500">
                    Contact Person
                  </Label>
                  <p>{brand.user.name}</p>
                </div>
              </div>

              {brand.contact?.phone && (
                <div>
                  <Label className="text-sm font-medium text-gray-500">
                    Phone
                  </Label>
                  <p>{brand.contact.phone}</p>
                </div>
              )}

              {brand.location?.headquarters && (
                <div>
                  <Label className="text-sm font-medium text-gray-500">
                    Location
                  </Label>
                  <div className="flex items-center gap-1 text-sm">
                    <MapPin className="h-4 w-4" />
                    <span>
                      {[
                        brand.location.headquarters.city,
                        brand.location.headquarters.country,
                      ]
                        .filter(Boolean)
                        .join(", ")}
                    </span>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Budget Information */}
          {brand.budget && (
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Budget & Preferences</CardTitle>
              </CardHeader>
              <CardContent>
                {brand.budget.monthlyInfluencerBudget && (
                  <div>
                    <Label className="text-sm font-medium text-gray-500">
                      Monthly Influencer Budget
                    </Label>
                    <div className="flex items-center gap-1 mt-1">
                      <DollarSign className="h-4 w-4" />
                      <span className="capitalize">
                        {brand.budget.monthlyInfluencerBudget.replace(
                          "-",
                          " - $"
                        )}
                      </span>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          {/* Registration Date */}
          <Card>
            <CardContent className="pt-6">
              <div className="text-sm text-gray-500">
                <strong>Registered:</strong>{" "}
                {new Date(brand.createdAt).toLocaleDateString()}
              </div>
              {brand.updatedAt !== brand.createdAt && (
                <div className="text-sm text-gray-500">
                  <strong>Last Updated:</strong>{" "}
                  {new Date(brand.updatedAt).toLocaleDateString()}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Action Buttons */}
          {brand.verificationStatus === "pending" && (
            <div className="border-t pt-6">
              <div className="flex gap-3 justify-end">
                <Button
                  variant="outline"
                  onClick={handleReject}
                  disabled={isApproving || isRejecting}
                >
                  {isRejecting ? (
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  ) : (
                    <XCircle className="h-4 w-4 mr-2" />
                  )}
                  Reject
                </Button>
                <Button
                  onClick={handleApprove}
                  disabled={isApproving || isRejecting}
                  className="bg-green-600 hover:bg-green-700"
                >
                  {isApproving ? (
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  ) : (
                    <CheckCircle className="h-4 w-4 mr-2" />
                  )}
                  Approve & Activate
                </Button>
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default BrandApprovalModal;
