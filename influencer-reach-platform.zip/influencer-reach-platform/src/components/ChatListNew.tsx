import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Search, MessageCircle, Clock } from "lucide-react";
import {
  firebaseChatService,
  ChatConversation,
} from "@/services/firebaseChatService";
import { useAuthStore } from "@/store/authStore";
import { useToast } from "@/hooks/use-toast";

interface ChatListProps {
  onConversationSelect: (
    conversationId: string,
    otherParticipant: {
      id: string;
      name: string;
      role: "influencer" | "brand" | "superadmin";
    }
  ) => void;
  onStartNewConversation?: () => void;
}

const ChatList: React.FC<ChatListProps> = ({
  onConversationSelect,
  onStartNewConversation,
}) => {
  const { user } = useAuthStore();
  const { toast } = useToast();
  const [conversations, setConversations] = useState<ChatConversation[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (!user?.id) return;

    console.log("Setting up conversation listener for user:", user.id);

    const unsubscribe = firebaseChatService.listenToUserConversations(
      user.id,
      (updatedConversations) => {
        console.log("🔄 Received conversations update:", {
          count: updatedConversations.length,
          conversations: updatedConversations.map((c) => ({
            id: c.id,
            participants: Object.keys(c.participants),
            lastMessage: c.lastMessage?.text?.substring(0, 50) + "...",
          })),
        });
        setConversations(updatedConversations);
        setIsLoading(false);
      }
    );

    return unsubscribe;
  }, [user?.id]);

  const filteredConversations = conversations.filter((conv) => {
    if (!searchQuery.trim()) return true;

    // Get the other participant (not the current user)
    const otherParticipantId = Object.keys(conv.participants).find(
      (id) => id !== user?.id
    );

    if (!otherParticipantId) return false;

    const otherParticipant = conv.participants[otherParticipantId];
    return otherParticipant.name
      .toLowerCase()
      .includes(searchQuery.toLowerCase());
  });

  const getOtherParticipant = (conversation: ChatConversation) => {
    const otherParticipantId = Object.keys(conversation.participants).find(
      (id) => id !== user?.id
    );

    if (!otherParticipantId) {
      return null;
    }

    return {
      id: otherParticipantId,
      ...conversation.participants[otherParticipantId],
    };
  };

  const getRoleBadgeColor = (role: string) => {
    switch (role) {
      case "brand":
        return "bg-blue-100 text-blue-800";
      case "influencer":
        return "bg-green-100 text-green-800";
      case "superadmin":
        return "bg-purple-100 text-purple-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const formatTime = (timestamp: number) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffInMs = now.getTime() - date.getTime();
    const diffInHours = diffInMs / (1000 * 60 * 60);

    if (diffInHours < 24) {
      return date.toLocaleTimeString([], {
        hour: "2-digit",
        minute: "2-digit",
      });
    } else if (diffInHours < 48) {
      return "Yesterday";
    } else {
      return date.toLocaleDateString();
    }
  };

  if (isLoading) {
    return (
      <Card className="h-[600px]">
        <CardHeader>
          <CardTitle>Messages</CardTitle>
        </CardHeader>
        <CardContent className="flex items-center justify-center h-[500px]">
          <div className="text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
            <p className="text-muted-foreground">Loading conversations...</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="h-[600px] flex flex-col">
      <CardHeader className="flex-shrink-0">
        <div className="flex items-center justify-between">
          <CardTitle>Messages</CardTitle>
          {onStartNewConversation && (
            <Button onClick={onStartNewConversation} size="sm">
              <MessageCircle className="w-4 h-4 mr-2" />
              New Chat
            </Button>
          )}
        </div>
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search conversations..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-9"
          />
        </div>
      </CardHeader>

      <CardContent className="flex-1 p-0">
        <ScrollArea className="h-full">
          {filteredConversations.length === 0 ? (
            <div className="flex items-center justify-center h-full text-muted-foreground p-8">
              <div className="text-center">
                <MessageCircle className="w-12 h-12 mx-auto mb-4 opacity-50" />
                <p className="text-lg font-medium mb-2">No conversations yet</p>
                <p className="text-sm">
                  {searchQuery.trim()
                    ? "No conversations match your search."
                    : "Start a conversation to see it here."}
                </p>
                {onStartNewConversation && !searchQuery.trim() && (
                  <Button
                    onClick={onStartNewConversation}
                    variant="outline"
                    size="sm"
                    className="mt-4"
                  >
                    Start New Chat
                  </Button>
                )}
              </div>
            </div>
          ) : (
            <div className="divide-y">
              {filteredConversations.map((conversation) => {
                const otherParticipant = getOtherParticipant(conversation);
                if (!otherParticipant) return null;

                const unreadCount =
                  conversation.unreadCount[user?.id || ""] || 0;
                const lastMessageTime =
                  conversation.lastMessageTime || conversation.createdAt;

                return (
                  <div
                    key={conversation.id}
                    className="p-4 hover:bg-muted/50 cursor-pointer transition-colors"
                    onClick={() =>
                      onConversationSelect(conversation.id, otherParticipant)
                    }
                  >
                    <div className="flex items-start space-x-3">
                      <Avatar className="h-10 w-10 flex-shrink-0">
                        <AvatarImage src="" />
                        <AvatarFallback>
                          {otherParticipant.name
                            .split(" ")
                            .map((n) => n[0])
                            .join("")
                            .toUpperCase()}
                        </AvatarFallback>
                      </Avatar>

                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between mb-1">
                          <div className="flex items-center space-x-2">
                            <h3 className="font-medium text-sm truncate">
                              {otherParticipant.name}
                            </h3>
                            <Badge
                              variant="secondary"
                              className={`text-xs ${getRoleBadgeColor(
                                otherParticipant.role
                              )}`}
                            >
                              {otherParticipant.role.charAt(0).toUpperCase() +
                                otherParticipant.role.slice(1)}
                            </Badge>
                          </div>
                          <div className="flex items-center space-x-2 flex-shrink-0">
                            <div className="flex items-center text-xs text-muted-foreground">
                              <Clock className="w-3 h-3 mr-1" />
                              {formatTime(lastMessageTime)}
                            </div>
                            {unreadCount > 0 && (
                              <Badge variant="destructive" className="text-xs">
                                {unreadCount}
                              </Badge>
                            )}
                          </div>
                        </div>

                        {/* Campaign context if available */}
                        {conversation.campaignTitle && (
                          <div className="mb-1">
                            <Badge variant="outline" className="text-xs">
                              📋 {conversation.campaignTitle}
                            </Badge>
                          </div>
                        )}

                        {conversation.lastMessage && (
                          <p className="text-sm text-muted-foreground truncate">
                            {conversation.lastMessage.senderId === user?.id
                              ? "You: "
                              : `${conversation.lastMessage.senderName}: `}
                            {conversation.lastMessage.text}
                          </p>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </ScrollArea>
      </CardContent>
    </Card>
  );
};

export default ChatList;
