import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Slider } from "@/components/ui/slider";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { X, Plus } from "lucide-react";

// Enhanced influencer profile schema
const enhancedInfluencerSchema = z.object({
  name: z.string().min(1, "Name is required"),
  bio: z.string().max(1000, "Bio too long").optional(),
  location: z
    .object({
      country: z.string().optional(),
      city: z.string().optional(),
    })
    .optional(),

  // Social platforms
  socialPlatforms: z
    .array(
      z.object({
        platform: z.string(),
        username: z.string(),
        followerCount: z.number().min(0).optional(),
        engagementRate: z.number().min(0).max(100),
        profileUrl: z.string().optional(),
      })
    )
    .min(1, "At least one social platform is required"),

  // Categories and content
  categories: z.array(z.string()).min(1, "At least one category is required"),
  tags: z.array(z.string()).optional(),
  languages: z.array(z.string()).optional(),
  contentTypes: z.array(z.string()).optional(),
  collaborationTypes: z.array(z.string()).optional(),

  // Enhanced demographics
  demographics: z
    .object({
      ageGroup: z.string().optional(),
      gender: z.string().optional(),
      primaryAudience: z
        .object({
          ageGroup: z.string().optional(),
          gender: z.string().optional(),
          locations: z.array(z.string()).optional(),
          interests: z.array(z.string()).optional(), // New field
          languages: z.array(z.string()).optional(), // New field
        })
        .optional(),
    })
    .optional(),

  // New enhanced fields
  brandAffinities: z
    .array(
      z.object({
        brand: z.string(),
        category: z.string(),
        collaborationType: z.string(),
        score: z.number().min(1).max(10),
        date: z.string().optional(),
      })
    )
    .optional(),

  personalityTraits: z
    .object({
      authenticity: z.number().min(1).max(10).default(5),
      creativity: z.number().min(1).max(10).default(5),
      professionalism: z.number().min(1).max(10).default(5),
      reliability: z.number().min(1).max(10).default(5),
    })
    .optional(),

  contentStyle: z
    .object({
      visualAesthetic: z.string().optional(),
      toneOfVoice: z.string().optional(),
      contentFrequency: z.string().optional(),
    })
    .optional(),

  performanceMetrics: z
    .object({
      averageViewsPerPost: z.number().optional(),
      averageLikesPerPost: z.number().optional(),
      averageCommentsPerPost: z.number().optional(),
      averageSharesPerPost: z.number().optional(),
      bestPerformingContentType: z.string().optional(),
      peakEngagementHours: z.array(z.string()).optional(),
    })
    .optional(),

  // Pricing
  pricing: z
    .object({
      postPrice: z.number().min(0).optional(),
      storyPrice: z.number().min(0).optional(),
      videoPrice: z.number().min(0).optional(),
      reelPrice: z.number().min(0).optional(),
      currency: z.string().default("USD"),
      negotiable: z.boolean().default(true),
    })
    .optional(),

  // Availability
  availability: z
    .object({
      status: z.enum(["available", "busy", "unavailable"]).default("available"),
      nextAvailable: z.string().optional(),
    })
    .optional(),
});

type EnhancedInfluencerFormData = z.infer<typeof enhancedInfluencerSchema>;

interface EnhancedInfluencerFormProps {
  onSubmit: (data: EnhancedInfluencerFormData) => void;
  initialData?: Partial<EnhancedInfluencerFormData>;
  isLoading?: boolean;
}

const categories = [
  "fashion",
  "beauty",
  "fitness",
  "food",
  "travel",
  "lifestyle",
  "technology",
  "gaming",
  "music",
  "art",
  "education",
  "brand",
  "health",
  "parenting",
  "pets",
  "sports",
  "entertainment",
  "comedy",
  "diy",
  "automotive",
  "home",
  "finance",
  "books",
  "photography",
  "other",
];

const platforms = [
  "instagram",
  "tiktok",
  "youtube",
  "twitter",
  "facebook",
  "linkedin",
  "twitch",
  "snapchat",
];

const contentTypes = [
  "post",
  "story",
  "reel",
  "video",
  "article",
  "review",
  "unboxing",
  "tutorial",
  "other",
];

const collaborationTypes = [
  "sponsored-post",
  "product-review",
  "brand-ambassador",
  "event-coverage",
  "giveaway",
  "takeover",
  "affiliate",
  "other",
];

const ageGroups = ["13-17", "18-24", "25-34", "35-44", "45-54", "55-64", "65+"];
const genders = ["male", "female", "non-binary", "prefer-not-to-say"];

const aestheticStyles = [
  "minimalist",
  "colorful",
  "dark",
  "bright",
  "vintage",
  "modern",
  "artistic",
  "lifestyle",
];

const toneOptions = [
  "professional",
  "casual",
  "humorous",
  "inspirational",
  "educational",
  "friendly",
  "authoritative",
];

const contentFrequencies = [
  "daily",
  "multiple-daily",
  "weekly",
  "bi-weekly",
  "irregular",
];

const EnhancedInfluencerForm = ({
  onSubmit,
  initialData,
  isLoading,
}: EnhancedInfluencerFormProps) => {
  const [activeTab, setActiveTab] = useState("basic");
  const [audienceInterests, setAudienceInterests] = useState<string[]>(
    initialData?.demographics?.primaryAudience?.interests || []
  );
  const [newAudienceInterest, setNewAudienceInterest] = useState("");
  const [tags, setTags] = useState<string[]>(initialData?.tags || []);
  const [newTag, setNewTag] = useState("");
  const [languages, setLanguages] = useState<string[]>(
    initialData?.languages || []
  );
  const [newLanguage, setNewLanguage] = useState("");

  const form = useForm<EnhancedInfluencerFormData>({
    resolver: zodResolver(enhancedInfluencerSchema),
    defaultValues: {
      name: "",
      bio: "",
      location: {
        country: "",
        city: "",
      },
      socialPlatforms: [],
      categories: [],
      tags: tags,
      languages: languages,
      contentTypes: [],
      collaborationTypes: [],
      demographics: {
        primaryAudience: {
          interests: audienceInterests,
        },
      },
      personalityTraits: {
        authenticity: 5,
        creativity: 5,
        professionalism: 5,
        reliability: 5,
      },
      contentStyle: {
        contentFrequency: "weekly",
      },
      pricing: {
        currency: "USD",
        negotiable: true,
      },
      availability: {
        status: "available",
      },
      ...initialData,
    },
  });

  const addAudienceInterest = () => {
    if (
      newAudienceInterest.trim() &&
      !audienceInterests.includes(newAudienceInterest.trim())
    ) {
      const updated = [...audienceInterests, newAudienceInterest.trim()];
      setAudienceInterests(updated);
      form.setValue("demographics.primaryAudience.interests", updated);
      setNewAudienceInterest("");
    }
  };

  const removeAudienceInterest = (interest: string) => {
    const updated = audienceInterests.filter((i) => i !== interest);
    setAudienceInterests(updated);
    form.setValue("demographics.primaryAudience.interests", updated);
  };

  const addTag = () => {
    if (newTag.trim() && !tags.includes(newTag.trim())) {
      const updated = [...tags, newTag.trim()];
      setTags(updated);
      form.setValue("tags", updated);
      setNewTag("");
    }
  };

  const removeTag = (tag: string) => {
    const updated = tags.filter((t) => t !== tag);
    setTags(updated);
    form.setValue("tags", updated);
  };

  const addLanguage = () => {
    if (newLanguage.trim() && !languages.includes(newLanguage.trim())) {
      const updated = [...languages, newLanguage.trim()];
      setLanguages(updated);
      form.setValue("languages", updated);
      setNewLanguage("");
    }
  };

  const removeLanguage = (language: string) => {
    const updated = languages.filter((l) => l !== language);
    setLanguages(updated);
    form.setValue("languages", updated);
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="basic">Basic Info</TabsTrigger>
            <TabsTrigger value="social">Social Media</TabsTrigger>
            <TabsTrigger value="content">Content & Style</TabsTrigger>
            <TabsTrigger value="personality">Personality</TabsTrigger>
            <TabsTrigger value="brand">Brand</TabsTrigger>
          </TabsList>

          <TabsContent value="basic" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Basic Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Full Name</FormLabel>
                      <FormControl>
                        <Input placeholder="Enter your full name" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="bio"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Bio</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="Tell us about yourself, your content, and what makes you unique..."
                          className="min-h-[120px]"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {/* Location */}
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="location.country"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Country</FormLabel>
                        <FormControl>
                          <Input placeholder="e.g., United States" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="location.city"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>City</FormLabel>
                        <FormControl>
                          <Input placeholder="e.g., New York" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                {/* Categories */}
                <FormField
                  control={form.control}
                  name="categories"
                  render={() => (
                    <FormItem>
                      <FormLabel>Content Categories</FormLabel>
                      <FormDescription>
                        Select all categories that describe your content
                      </FormDescription>
                      <div className="grid grid-cols-3 gap-2">
                        {categories.map((category) => (
                          <FormField
                            key={category}
                            control={form.control}
                            name="categories"
                            render={({ field }) => (
                              <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                                <FormControl>
                                  <Checkbox
                                    checked={field.value?.includes(category)}
                                    onCheckedChange={(checked) => {
                                      const current = field.value || [];
                                      if (checked) {
                                        field.onChange([...current, category]);
                                      } else {
                                        field.onChange(
                                          current.filter(
                                            (value) => value !== category
                                          )
                                        );
                                      }
                                    }}
                                  />
                                </FormControl>
                                <FormLabel className="text-sm font-normal capitalize">
                                  {category}
                                </FormLabel>
                              </FormItem>
                            )}
                          />
                        ))}
                      </div>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {/* Tags */}
                <div>
                  <Label>Tags</Label>
                  <FormDescription>
                    Add tags that describe your content and niche
                  </FormDescription>
                  <div className="flex gap-2 mt-2">
                    <Input
                      placeholder="Add tag..."
                      value={newTag}
                      onChange={(e) => setNewTag(e.target.value)}
                      onKeyPress={(e) =>
                        e.key === "Enter" && (e.preventDefault(), addTag())
                      }
                    />
                    <Button type="button" onClick={addTag} size="sm">
                      <Plus className="h-4 w-4" />
                    </Button>
                  </div>
                  <div className="flex flex-wrap gap-2 mt-2">
                    {tags.map((tag) => (
                      <Badge
                        key={tag}
                        variant="secondary"
                        className="flex items-center gap-1"
                      >
                        {tag}
                        <button type="button" onClick={() => removeTag(tag)}>
                          <X className="h-3 w-3" />
                        </button>
                      </Badge>
                    ))}
                  </div>
                </div>

                {/* Languages */}
                <div>
                  <Label>Languages</Label>
                  <FormDescription>
                    Languages you create content in
                  </FormDescription>
                  <div className="flex gap-2 mt-2">
                    <Input
                      placeholder="Add language..."
                      value={newLanguage}
                      onChange={(e) => setNewLanguage(e.target.value)}
                      onKeyPress={(e) =>
                        e.key === "Enter" && (e.preventDefault(), addLanguage())
                      }
                    />
                    <Button type="button" onClick={addLanguage} size="sm">
                      <Plus className="h-4 w-4" />
                    </Button>
                  </div>
                  <div className="flex flex-wrap gap-2 mt-2">
                    {languages.map((language) => (
                      <Badge
                        key={language}
                        variant="secondary"
                        className="flex items-center gap-1"
                      >
                        {language}
                        <button
                          type="button"
                          onClick={() => removeLanguage(language)}
                        >
                          <X className="h-3 w-3" />
                        </button>
                      </Badge>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="social" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Social Media Platforms</CardTitle>
              </CardHeader>
              <CardContent>
                <FormDescription className="mb-4">
                  Add your social media accounts and their metrics
                </FormDescription>
                {/* Social platforms section - simplified for now */}
                <div className="text-sm text-gray-600">
                  Social platforms configuration will be implemented here...
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="content" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Content Style & Preferences</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Content Types */}
                <FormField
                  control={form.control}
                  name="contentTypes"
                  render={() => (
                    <FormItem>
                      <FormLabel>Content Types</FormLabel>
                      <FormDescription>
                        Types of content you create
                      </FormDescription>
                      <div className="grid grid-cols-3 gap-2">
                        {contentTypes.map((type) => (
                          <FormField
                            key={type}
                            control={form.control}
                            name="contentTypes"
                            render={({ field }) => (
                              <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                                <FormControl>
                                  <Checkbox
                                    checked={field.value?.includes(type)}
                                    onCheckedChange={(checked) => {
                                      const current = field.value || [];
                                      if (checked) {
                                        field.onChange([...current, type]);
                                      } else {
                                        field.onChange(
                                          current.filter(
                                            (value) => value !== type
                                          )
                                        );
                                      }
                                    }}
                                  />
                                </FormControl>
                                <FormLabel className="text-sm font-normal capitalize">
                                  {type.replace("-", " ")}
                                </FormLabel>
                              </FormItem>
                            )}
                          />
                        ))}
                      </div>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {/* Content Style */}
                <div className="space-y-4">
                  <Label className="text-base font-medium">Content Style</Label>

                  <FormField
                    control={form.control}
                    name="contentStyle.visualAesthetic"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Visual Aesthetic</FormLabel>
                        <Select
                          onValueChange={field.onChange}
                          defaultValue={field.value}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select your visual style" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {aestheticStyles.map((style) => (
                              <SelectItem key={style} value={style}>
                                {style.charAt(0).toUpperCase() + style.slice(1)}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="contentStyle.toneOfVoice"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Tone of Voice</FormLabel>
                        <Select
                          onValueChange={field.onChange}
                          defaultValue={field.value}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select your tone of voice" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {toneOptions.map((tone) => (
                              <SelectItem key={tone} value={tone}>
                                {tone.charAt(0).toUpperCase() + tone.slice(1)}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="contentStyle.contentFrequency"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Content Frequency</FormLabel>
                        <Select
                          onValueChange={field.onChange}
                          defaultValue={field.value}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="How often do you post?" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {contentFrequencies.map((frequency) => (
                              <SelectItem key={frequency} value={frequency}>
                                {frequency
                                  .replace("-", " ")
                                  .charAt(0)
                                  .toUpperCase() +
                                  frequency.replace("-", " ").slice(1)}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                {/* Audience Demographics */}
                <div className="space-y-4">
                  <Label className="text-base font-medium">Your Audience</Label>

                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="demographics.primaryAudience.ageGroup"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Primary Audience Age</FormLabel>
                          <Select
                            onValueChange={field.onChange}
                            defaultValue={field.value}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select age group" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {ageGroups.map((age) => (
                                <SelectItem key={age} value={age}>
                                  {age}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="demographics.primaryAudience.gender"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Primary Audience Gender</FormLabel>
                          <Select
                            onValueChange={field.onChange}
                            defaultValue={field.value}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select gender" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {genders.map((gender) => (
                                <SelectItem key={gender} value={gender}>
                                  {gender.charAt(0).toUpperCase() +
                                    gender.slice(1).replace("-", " ")}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  {/* Audience Interests */}
                  <div>
                    <Label>Audience Interests</Label>
                    <FormDescription>
                      What are your audience most interested in?
                    </FormDescription>
                    <div className="flex gap-2 mt-2">
                      <Input
                        placeholder="Add audience interest..."
                        value={newAudienceInterest}
                        onChange={(e) => setNewAudienceInterest(e.target.value)}
                        onKeyPress={(e) =>
                          e.key === "Enter" &&
                          (e.preventDefault(), addAudienceInterest())
                        }
                      />
                      <Button
                        type="button"
                        onClick={addAudienceInterest}
                        size="sm"
                      >
                        <Plus className="h-4 w-4" />
                      </Button>
                    </div>
                    <div className="flex flex-wrap gap-2 mt-2">
                      {audienceInterests.map((interest) => (
                        <Badge
                          key={interest}
                          variant="secondary"
                          className="flex items-center gap-1"
                        >
                          {interest}
                          <button
                            type="button"
                            onClick={() => removeAudienceInterest(interest)}
                          >
                            <X className="h-3 w-3" />
                          </button>
                        </Badge>
                      ))}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="personality" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Personality Traits</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <FormDescription>
                  Rate yourself on these personality traits (1-10 scale)
                </FormDescription>

                {[
                  "authenticity",
                  "creativity",
                  "professionalism",
                  "reliability",
                ].map((trait) => (
                  <FormField
                    key={trait}
                    control={form.control}
                    name={`personalityTraits.${trait}` as any}
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="capitalize">{trait}</FormLabel>
                        <FormControl>
                          <div className="space-y-2">
                            <Slider
                              value={[field.value || 5]}
                              onValueChange={(value) =>
                                field.onChange(value[0])
                              }
                              max={10}
                              min={1}
                              step={1}
                              className="w-full"
                            />
                            <div className="text-sm text-gray-600">
                              {field.value || 5}/10
                            </div>
                          </div>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                ))}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="brand" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Brand Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Collaboration Types */}
                <FormField
                  control={form.control}
                  name="collaborationTypes"
                  render={() => (
                    <FormItem>
                      <FormLabel>Collaboration Types</FormLabel>
                      <FormDescription>
                        Types of collaborations you're open to
                      </FormDescription>
                      <div className="grid grid-cols-2 gap-2">
                        {collaborationTypes.map((type) => (
                          <FormField
                            key={type}
                            control={form.control}
                            name="collaborationTypes"
                            render={({ field }) => (
                              <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                                <FormControl>
                                  <Checkbox
                                    checked={field.value?.includes(type)}
                                    onCheckedChange={(checked) => {
                                      const current = field.value || [];
                                      if (checked) {
                                        field.onChange([...current, type]);
                                      } else {
                                        field.onChange(
                                          current.filter(
                                            (value) => value !== type
                                          )
                                        );
                                      }
                                    }}
                                  />
                                </FormControl>
                                <FormLabel className="text-sm font-normal">
                                  {type
                                    .replace("-", " ")
                                    .replace(/\b\w/g, (l) => l.toUpperCase())}
                                </FormLabel>
                              </FormItem>
                            )}
                          />
                        ))}
                      </div>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {/* Pricing */}
                <div className="space-y-4">
                  <Label className="text-base font-medium">Pricing</Label>

                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="pricing.postPrice"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Post Price</FormLabel>
                          <FormControl>
                            <Input
                              type="number"
                              placeholder="e.g., 500"
                              {...field}
                              onChange={(e) =>
                                field.onChange(
                                  parseInt(e.target.value) || undefined
                                )
                              }
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="pricing.storyPrice"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Story Price</FormLabel>
                          <FormControl>
                            <Input
                              type="number"
                              placeholder="e.g., 200"
                              {...field}
                              onChange={(e) =>
                                field.onChange(
                                  parseInt(e.target.value) || undefined
                                )
                              }
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="pricing.reelPrice"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Reel Price</FormLabel>
                          <FormControl>
                            <Input
                              type="number"
                              placeholder="e.g., 800"
                              {...field}
                              onChange={(e) =>
                                field.onChange(
                                  parseInt(e.target.value) || undefined
                                )
                              }
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="pricing.videoPrice"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Video Price</FormLabel>
                          <FormControl>
                            <Input
                              type="number"
                              placeholder="e.g., 1500"
                              {...field}
                              onChange={(e) =>
                                field.onChange(
                                  parseInt(e.target.value) || undefined
                                )
                              }
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <FormField
                    control={form.control}
                    name="pricing.negotiable"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                        <FormControl>
                          <Checkbox
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                        <div className="space-y-1 leading-none">
                          <FormLabel>Prices are negotiable</FormLabel>
                          <FormDescription>
                            Check this if you're open to negotiating prices
                          </FormDescription>
                        </div>
                      </FormItem>
                    )}
                  />
                </div>

                {/* Availability */}
                <FormField
                  control={form.control}
                  name="availability.status"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Availability Status</FormLabel>
                      <Select
                        onValueChange={field.onChange}
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select availability" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="available">Available</SelectItem>
                          <SelectItem value="busy">Busy</SelectItem>
                          <SelectItem value="unavailable">
                            Unavailable
                          </SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        <div className="flex justify-between pt-6">
          <Button
            type="button"
            variant="outline"
            onClick={() => {
              const tabs = [
                "basic",
                "social",
                "content",
                "personality",
                "brand",
              ];
              const currentIndex = tabs.indexOf(activeTab);
              if (currentIndex > 0) {
                setActiveTab(tabs[currentIndex - 1]);
              }
            }}
            disabled={activeTab === "basic"}
          >
            Previous
          </Button>

          {activeTab !== "brand" ? (
            <Button
              type="button"
              onClick={() => {
                const tabs = [
                  "basic",
                  "social",
                  "content",
                  "personality",
                  "brand",
                ];
                const currentIndex = tabs.indexOf(activeTab);
                if (currentIndex < tabs.length - 1) {
                  setActiveTab(tabs[currentIndex + 1]);
                }
              }}
            >
              Next
            </Button>
          ) : (
            <Button type="submit" disabled={isLoading}>
              {isLoading ? "Saving Profile..." : "Save Profile"}
            </Button>
          )}
        </div>
      </form>
    </Form>
  );
};

export default EnhancedInfluencerForm;
