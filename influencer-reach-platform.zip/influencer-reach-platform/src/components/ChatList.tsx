import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { MessageCircle, Search, Clock, RefreshCw } from "lucide-react";
import {
  firebaseChatService,
  ChatConversation,
} from "@/services/firebaseChatService";
import {
  messageApi,
  Conversation,
  apiClient,
  handleTokenRefresh,
} from "@/lib/api";
import { useAuthStore } from "@/store/authStore";
import Chat from "./Chat";
import { useToast } from "@/hooks/use-toast";

const ChatList: React.FC = () => {
  const { user } = useAuthStore();
  const { toast } = useToast();
  const [conversations, setConversations] = useState<ChatConversation[]>([]);
  const [backendConversations, setBackendConversations] = useState<
    Conversation[]
  >([]);
  const [selectedConversation, setSelectedConversation] =
    useState<ChatConversation | null>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [isLoading, setIsLoading] = useState(true);

  // Fetch conversations from backend database
  const fetchBackendConversations = async () => {
    if (!user?.id) {
      console.log("❌ No user found, skipping backend fetch");
      return;
    }

    const accessToken = localStorage.getItem("accessToken");
    if (!accessToken) {
      console.log("❌ No access token found, user not authenticated");
      toast({
        title: "Authentication Required",
        description: "Please log in to view your conversations.",
        variant: "destructive",
      });
      return;
    }

    try {
      console.log("📡 Fetching conversations from backend database...");
      console.log("🔑 Current user:", user);

      // Ensure apiClient has the latest token
      apiClient.refreshToken();

      console.log("🔑 Access token exists:", !!accessToken);
      console.log("🔑 ApiClient token exists:", !!apiClient.getAccessToken());

      const response = await messageApi.getConversations({ limit: 50 });
      console.log("✅ Backend conversations fetched:", response);
      setBackendConversations(response.data || []);
    } catch (error) {
      console.error("❌ Failed to fetch backend conversations:", error);

      // If it's an auth error, try to refresh the token
      if (error.code === 401) {
        console.log("🔄 Attempting to refresh token...");
        try {
          const refreshSuccess = await handleTokenRefresh();
          if (refreshSuccess) {
            console.log("✅ Token refreshed, retrying...");
            // Retry the request
            const response = await messageApi.getConversations({ limit: 50 });
            console.log(
              "✅ Backend conversations fetched after refresh:",
              response
            );
            setBackendConversations(response.data || []);
            return;
          }
        } catch (refreshError) {
          console.error("❌ Token refresh failed:", refreshError);
        }

        toast({
          title: "Authentication Error",
          description: "Your session has expired. Please log in again.",
          variant: "destructive",
        });
      } else {
        toast({
          title: "Error",
          description: "Failed to load conversations from server",
          variant: "destructive",
        });
      }
    }
  };

  useEffect(() => {
    if (!user?.id) return;

    // Fetch backend conversations
    fetchBackendConversations();

    // Listen to Firebase conversations
    const unsubscribe = firebaseChatService.listenToUserConversations(
      user.id,
      (firebaseConversations) => {
        console.log(
          "🔥 Firebase conversations updated:",
          firebaseConversations
        );
        setConversations(firebaseConversations);
        setIsLoading(false);
      }
    );

    // Set loading to false after initial fetch attempts
    setTimeout(() => setIsLoading(false), 3000);

    return unsubscribe;
  }, [user?.id]);

  // Convert backend conversation to ChatConversation format for display
  const convertBackendConversation = (
    backendConv: Conversation
  ): ChatConversation => {
    const otherParticipant = backendConv.participants.find(
      (p) => p.user.id !== user?.id
    );
    const currentParticipant = backendConv.participants.find(
      (p) => p.user.id === user?.id
    );

    // Determine brand and influencer based on roles
    const brandParticipant = backendConv.participants.find(
      (p) => p.user.role === "brand"
    );
    const influencerParticipant = backendConv.participants.find(
      (p) => p.user.role === "influencer"
    );

    return {
      id: backendConv.id,
      campaignId: backendConv.relatedCampaign || "general",
      campaignTitle: backendConv.subject || "Direct Conversation",
      brandId: brandParticipant?.user.id || "",
      brandName: brandParticipant?.user.name || "",
      influencerId: influencerParticipant?.user.id || "",
      influencerName: influencerParticipant?.user.name || "",
      lastMessage: undefined, // We'll handle this separately since the structure is different
      lastMessageTime: new Date(backendConv.lastMessageAt).getTime(),
      unreadCount: {
        [user?.id || ""]: 0, // We'll implement proper unread count later
      },
      createdAt: new Date(backendConv.createdAt).getTime(),
      isActive: true,
    };
  };

  // Combine Firebase and backend conversations, avoiding duplicates
  const getAllConversations = (): ChatConversation[] => {
    const firebaseConvIds = new Set(conversations.map((c) => c.id));
    const backendConverted = backendConversations
      .filter((bc) => !firebaseConvIds.has(bc.id))
      .map(convertBackendConversation);

    return [...conversations, ...backendConverted];
  };

  const allConversations = getAllConversations();

  const filteredConversations = allConversations.filter((conversation) => {
    if (!searchTerm) return true;

    const searchLower = searchTerm.toLowerCase();
    const otherParticipantName =
      user?.role === "brand"
        ? conversation.influencerName
        : conversation.brandName;

    return (
      otherParticipantName.toLowerCase().includes(searchLower) ||
      conversation.campaignTitle.toLowerCase().includes(searchLower) ||
      conversation.lastMessage?.text.toLowerCase().includes(searchLower)
    );
  });

  const formatLastMessageTime = (timestamp?: number) => {
    if (!timestamp) return "";

    const date = new Date(timestamp);
    const now = new Date();
    const diffInDays = Math.floor(
      (now.getTime() - date.getTime()) / (1000 * 60 * 60 * 24)
    );

    if (diffInDays === 0) {
      return date.toLocaleTimeString([], {
        hour: "2-digit",
        minute: "2-digit",
      });
    } else if (diffInDays === 1) {
      return "Yesterday";
    } else if (diffInDays < 7) {
      return date.toLocaleDateString([], { weekday: "short" });
    } else {
      return date.toLocaleDateString([], { month: "short", day: "numeric" });
    }
  };

  const getUnreadCount = (conversation: ChatConversation) => {
    return user?.id ? conversation.unreadCount[user.id] || 0 : 0;
  };

  const getOtherParticipantName = (conversation: ChatConversation) => {
    return user?.role === "brand"
      ? conversation.influencerName
      : conversation.brandName;
  };

  const getOtherParticipantRole = (conversation: ChatConversation) => {
    return user?.role === "brand" ? "influencer" : "brand";
  };

  if (selectedConversation) {
    return (
      <Chat
        conversationId={selectedConversation.id}
        campaignId={selectedConversation.campaignId}
        campaignTitle={selectedConversation.campaignTitle}
        brandId={selectedConversation.brandId}
        brandName={selectedConversation.brandName}
        influencerId={selectedConversation.influencerId}
        influencerName={selectedConversation.influencerName}
        onBack={() => setSelectedConversation(null)}
      />
    );
  }

  return (
    <Card className="h-[600px] flex flex-col">
      <CardHeader className="flex-shrink-0">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center">
            <MessageCircle className="h-5 w-5 mr-2" />
            Messages
          </CardTitle>
          <button
            onClick={() => {
              setIsLoading(true);
              fetchBackendConversations();
            }}
            className="p-2 hover:bg-gray-100 rounded-full transition-colors"
            title="Refresh conversations"
          >
            <RefreshCw className="h-4 w-4" />
          </button>
        </div>
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
          <Input
            placeholder="Search conversations..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
      </CardHeader>

      <CardContent className="flex-1 p-0">
        <ScrollArea className="h-full">
          {isLoading ? (
            <div className="flex items-center justify-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600"></div>
            </div>
          ) : filteredConversations.length === 0 ? (
            <div className="text-center py-8 px-4">
              <MessageCircle className="h-12 w-12 text-gray-400 mx-auto mb-3" />
              <div className="text-gray-500 mb-2">
                {searchTerm ? "No conversations found" : "No messages yet"}
              </div>
              <div className="text-sm text-gray-400">
                {searchTerm
                  ? "Try adjusting your search terms"
                  : "Start collaborating with campaigns to begin conversations"}
              </div>
            </div>
          ) : (
            <div className="divide-y">
              {filteredConversations.map((conversation) => {
                const unreadCount = getUnreadCount(conversation);
                const otherParticipantName =
                  getOtherParticipantName(conversation);
                const otherParticipantRole =
                  getOtherParticipantRole(conversation);

                return (
                  <div
                    key={conversation.id}
                    className="p-4 hover:bg-gray-50 cursor-pointer transition-colors"
                    onClick={() => setSelectedConversation(conversation)}
                  >
                    <div className="flex items-start space-x-3">
                      <Avatar className="h-12 w-12 flex-shrink-0">
                        <AvatarFallback>
                          {otherParticipantName.charAt(0).toUpperCase()}
                        </AvatarFallback>
                      </Avatar>

                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between mb-1">
                          <div className="flex items-center space-x-2">
                            <h3 className="font-semibold text-sm truncate">
                              {otherParticipantName}
                            </h3>
                            <Badge variant="secondary" className="text-xs">
                              {otherParticipantRole}
                            </Badge>
                          </div>
                          <div className="flex items-center space-x-2 flex-shrink-0">
                            {conversation.lastMessageTime && (
                              <span className="text-xs text-gray-500">
                                {formatLastMessageTime(
                                  conversation.lastMessageTime
                                )}
                              </span>
                            )}
                            {unreadCount > 0 && (
                              <div className="bg-indigo-600 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                                {unreadCount > 99 ? "99+" : unreadCount}
                              </div>
                            )}
                          </div>
                        </div>

                        <div className="text-sm text-gray-600 mb-1 truncate">
                          {conversation.campaignTitle}
                        </div>

                        {conversation.lastMessage && (
                          <div className="text-sm text-gray-500 truncate">
                            {conversation.lastMessage.senderId === user?.id
                              ? "You: "
                              : ""}
                            {conversation.lastMessage.text}
                          </div>
                        )}

                        {!conversation.lastMessage && (
                          <div className="text-sm text-gray-400 italic">
                            Conversation started
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </ScrollArea>
      </CardContent>
    </Card>
  );
};

export default ChatList;
