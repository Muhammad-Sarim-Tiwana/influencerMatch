import { Navigate } from "react-router-dom";
import { useAuthStore, UserRole } from "@/store/authStore";

interface AuthRedirectProps {
  children: React.ReactNode;
}

/**
 * Component that redirects authenticated users away from auth pages
 * and to their appropriate dashboard
 */
const AuthRedirect = ({ children }: AuthRedirectProps) => {
  const { isAuthenticated, user, isLoading } = useAuthStore();

  // Show loading while checking authentication
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-indigo-600"></div>
      </div>
    );
  }

  // If user is authenticated, redirect to their dashboard
  if (isAuthenticated && user) {
    const getDashboardPath = (role: UserRole): string => {
      switch (role) {
        case "superadmin":
          return "/admin";
        case "brand":
          return "/brand";
        case "influencer":
          return "/influencer";
        default:
          return "/";
      }
    };

    return <Navigate to={getDashboardPath(user.role)} replace />;
  }

  // If not authenticated, show the auth page
  return <>{children}</>;
};

export default AuthRedirect;
