import { useState, useEffect } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "@/components/ui/carousel";
import { Skeleton } from "@/components/ui/skeleton";
import { campaignService } from "@/services/campaignService";
import userService from "@/services/userService";
import { toast } from "@/hooks/use-toast";
import {
  Users,
  TrendingUp,
  Star,
  Sparkles,
  MessageCircle,
  Shield,
  Target,
  DollarSign,
  AlertTriangle,
  CheckCircle,
  Clock,
} from "lucide-react";
import { useNavigate } from "react-router-dom";

interface RecommendedInfluencersProps {
  campaignId: string;
}

interface EnhancedRecommendation {
  id: string;
  name?: string;
  score: number;
  matchLevel?: "excellent" | "good" | "fair" | "poor";
  reasons: string[];
  strengths?: string[];
  concerns?: string[];
  recommendations?: string[];
  estimatedROI?: number;
  budgetFit?: "above" | "within" | "below";
  deliverableMatch?: {
    [key: string]: boolean;
  };
  audienceInsights?: {
    primaryDemographic: string;
    locationMatch: string;
    languageMatch: string;
  };
  riskLevel?: "low" | "medium" | "high";
  timelineCompatibility?: "excellent" | "good" | "concerning";
  influencer?: any; // Will be populated by fetching user data
}

const RecommendedInfluencersV2 = ({
  campaignId,
}: RecommendedInfluencersProps) => {
  const [recommendations, setRecommendations] = useState<
    EnhancedRecommendation[]
  >([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const navigate = useNavigate();

  useEffect(() => {
    loadRecommendations();
  }, [campaignId]);

  const loadRecommendations = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const response = await campaignService.getAIRecommendations(campaignId);
      console.log("AI Recommendations Response:", response);

      const responseData = response as any;
      const recommendationData =
        responseData.recommendations ||
        responseData.data?.recommendations ||
        {};
      const rawRecommendations =
        recommendationData.allMatches || recommendationData || [];

      // Fetch full influencer profiles for each recommendation
      const enhancedRecommendations = await Promise.all(
        Array.isArray(rawRecommendations)
          ? rawRecommendations.map(async (rec: any) => {
              try {
                // Ensure the recommendation has a valid ID
                if (!rec.id) {
                  console.error("Recommendation missing ID:", rec);
                  return null;
                }

                const influencerData = await userService.getInfluencerById(
                  rec.id
                );
                return {
                  ...rec,
                  influencer: influencerData,
                };
              } catch (error) {
                console.error(`Failed to load influencer ${rec.id}:`, error);
                return {
                  ...rec,
                  influencer: null,
                };
              }
            })
          : // turn single recommendation into an array
          rawRecommendations.id
          ? [
              {
                ...rawRecommendations,
                influencer: await userService.getInfluencerById(
                  rawRecommendations.id
                ),
              },
            ]
          : []
      );

      // Filter out null recommendations and those where we couldn't load the influencer
      const validRecommendations = enhancedRecommendations.filter(
        (rec) => rec && rec.influencer
      );

      setRecommendations(validRecommendations);
    } catch (error: any) {
      console.error("Failed to load recommendations:", error);
      setError("Failed to load recommendations");
      toast({
        title: "Error",
        description: "Failed to load influencer recommendations.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const formatFollowers = (count: number) => {
    if (count >= 1000000) {
      return `${(count / 1000000).toFixed(1)}M`;
    } else if (count >= 1000) {
      return `${(count / 1000).toFixed(1)}K`;
    }
    return count.toString();
  };

  const getMatchLevelColor = (level?: string) => {
    switch (level) {
      case "excellent":
        return "bg-green-100 text-green-800";
      case "good":
        return "bg-blue-100 text-blue-800";
      case "fair":
        return "bg-yellow-100 text-yellow-800";
      case "poor":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getRiskLevelColor = (level?: string) => {
    switch (level) {
      case "low":
        return "bg-green-100 text-green-800";
      case "medium":
        return "bg-yellow-100 text-yellow-800";
      case "high":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getBudgetFitColor = (fit?: string) => {
    switch (fit) {
      case "within":
        return "bg-green-100 text-green-800";
      case "below":
        return "bg-blue-100 text-blue-800";
      case "above":
        return "bg-orange-100 text-orange-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const handleInfluencerClick = (influencerId: string) => {
    navigate(`/influencer-profile/${influencerId}?campaignId=${campaignId}`);
  };

  if (error && !isLoading) {
    return null;
  }

  return (
    <Card className="mt-8">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Sparkles className="h-5 w-5 text-purple-600" />
          AI-Powered Influencer Recommendations
        </CardTitle>
        <CardDescription>
          Discover perfectly matched influencers using advanced AI analysis of
          campaign requirements and influencer profiles
        </CardDescription>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="flex space-x-4 overflow-hidden">
            {[...Array(4)].map((_, index) => (
              <div key={index} className="flex-shrink-0 w-80">
                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center space-x-3 mb-3">
                      <Skeleton className="h-12 w-12 rounded-full" />
                      <div>
                        <Skeleton className="h-4 w-24 mb-2" />
                        <Skeleton className="h-3 w-16" />
                      </div>
                    </div>
                    <Skeleton className="h-3 w-full mb-2" />
                    <Skeleton className="h-3 w-3/4 mb-3" />
                    <div className="flex gap-2">
                      <Skeleton className="h-6 w-16" />
                      <Skeleton className="h-6 w-20" />
                    </div>
                  </CardContent>
                </Card>
              </div>
            ))}
          </div>
        ) : recommendations.length === 0 ? (
          <div className="text-center py-8 text-gray-500">
            <Users className="h-12 w-12 mx-auto mb-4 opacity-50" />
            <p>No AI recommendations available for this campaign yet.</p>
            <p className="text-sm mt-2">
              Our AI is analyzing potential matches...
            </p>
          </div>
        ) : (
          <Carousel
            opts={{
              align: "start",
            }}
            className="w-full"
          >
            <CarouselContent>
              {recommendations.map((recommendation, index) => (
                <CarouselItem
                  key={`${recommendation.id}-${index}`}
                  className="md:basis-1/2 lg:basis-1/3 xl:basis-1/4"
                >
                  <Card
                    className="h-full cursor-pointer hover:shadow-lg transition-all duration-200 border-2 hover:border-purple-200 hover:scale-[1.02]"
                    onClick={() => handleInfluencerClick(recommendation.id)}
                  >
                    <CardContent className="p-4">
                      {/* Header with Avatar and Score */}
                      <div className="flex items-center space-x-3 mb-4">
                        <Avatar className="h-12 w-12">
                          <AvatarImage
                            src={recommendation.influencer?.profileImage}
                            alt={
                              recommendation.name ||
                              recommendation.influencer?.name
                            }
                          />
                          <AvatarFallback>
                            {(
                              recommendation.name ||
                              recommendation.influencer?.name ||
                              "?"
                            )
                              .split(" ")
                              .map((n) => n[0])
                              .join("")}
                          </AvatarFallback>
                        </Avatar>
                        <div className="flex-1 min-w-0">
                          <h4 className="font-semibold text-sm truncate">
                            {recommendation.name ||
                              recommendation.influencer?.name}
                          </h4>
                          <div className="flex items-center gap-2 mt-1">
                            <div className="flex items-center space-x-1">
                              <Star className="h-3 w-3 text-yellow-500 fill-current" />
                              <span className="font-bold text-lg text-purple-600">
                                {recommendation.score}
                              </span>
                            </div>
                            {recommendation.influencer?.verificationStatus ===
                              "verified" && (
                              <CheckCircle className="h-4 w-4 text-green-500" />
                            )}
                          </div>
                        </div>
                      </div>

                      {/* Match Level and Risk Assessment */}
                      <div className="flex gap-2 mb-3">
                        {recommendation.matchLevel && (
                          <Badge
                            className={`text-xs ${getMatchLevelColor(
                              recommendation.matchLevel
                            )}`}
                          >
                            {recommendation.matchLevel} match
                          </Badge>
                        )}
                        {recommendation.riskLevel && (
                          <Badge
                            className={`text-xs ${getRiskLevelColor(
                              recommendation.riskLevel
                            )}`}
                          >
                            {recommendation.riskLevel} risk
                          </Badge>
                        )}
                      </div>

                      {/* Key Metrics */}
                      <div className="grid grid-cols-2 gap-2 mb-3 text-xs">
                        <div className="flex items-center gap-1">
                          <Users className="h-3 w-3 text-blue-500" />
                          <span className="font-medium">
                            {formatFollowers(
                              recommendation.influencer?.metrics
                                ?.totalFollowers || 0
                            )}
                          </span>
                        </div>
                        <div className="flex items-center gap-1">
                          <TrendingUp className="h-3 w-3 text-green-500" />
                          <span className="font-medium">
                            {(
                              recommendation.influencer?.metrics
                                ?.averageEngagement || 0
                            ).toFixed(1)}
                            %
                          </span>
                        </div>
                        {recommendation.estimatedROI && (
                          <div className="flex items-center gap-1">
                            <Target className="h-3 w-3 text-purple-500" />
                            <span className="font-medium text-purple-600">
                              {recommendation.estimatedROI}% ROI
                            </span>
                          </div>
                        )}
                        {recommendation.budgetFit && (
                          <div className="flex items-center gap-1">
                            <DollarSign className="h-3 w-3 text-green-500" />
                            <Badge
                              className={`text-xs ${getBudgetFitColor(
                                recommendation.budgetFit
                              )}`}
                            >
                              {recommendation.budgetFit}
                            </Badge>
                          </div>
                        )}
                      </div>

                      {/* Categories */}
                      <div className="flex flex-wrap gap-1 mb-3">
                        {(recommendation.influencer?.categories || [])
                          .slice(0, 2)
                          .map((category: string, idx: number) => (
                            <Badge
                              key={idx}
                              variant="outline"
                              className="text-xs"
                            >
                              {category}
                            </Badge>
                          ))}
                      </div>

                      {/* Audience Insights */}
                      {recommendation.audienceInsights && (
                        <div className="bg-blue-50 rounded-lg p-2 mb-3">
                          <p className="text-xs font-medium text-blue-700 mb-1">
                            Audience Match:
                          </p>
                          <p className="text-xs text-blue-600">
                            {recommendation.audienceInsights.primaryDemographic}
                          </p>
                          <div className="flex gap-2 mt-1">
                            <span className="text-xs text-blue-600">
                              📍 {recommendation.audienceInsights.locationMatch}
                            </span>
                            <span className="text-xs text-blue-600">
                              🗣️ {recommendation.audienceInsights.languageMatch}
                            </span>
                          </div>
                        </div>
                      )}

                      {/* Top Strengths */}
                      <div className="bg-green-50 rounded-lg p-2 mb-3">
                        <p className="text-xs font-medium text-green-700 mb-1">
                          Key Strengths:
                        </p>
                        <ul className="text-xs text-green-600 space-y-1">
                          {(recommendation.strengths || recommendation.reasons)
                            .slice(0, 2)
                            .map((strength: string, idx: number) => (
                              <li key={idx} className="truncate">
                                • {strength}
                              </li>
                            ))}
                        </ul>
                      </div>

                      {/* Concerns */}
                      {recommendation.concerns &&
                        recommendation.concerns.length > 0 && (
                          <div className="bg-yellow-50 rounded-lg p-2 mb-3">
                            <p className="text-xs font-medium text-yellow-700 mb-1">
                              Considerations:
                            </p>
                            <ul className="text-xs text-yellow-600 space-y-1">
                              {recommendation.concerns
                                .slice(0, 1)
                                .map((concern: string, idx: number) => (
                                  <li key={idx} className="truncate">
                                    • {concern}
                                  </li>
                                ))}
                            </ul>
                          </div>
                        )}

                      {/* Deliverable Match */}
                      {recommendation.deliverableMatch && (
                        <div className="mb-3">
                          <p className="text-xs font-medium text-gray-700 mb-1">
                            Can Deliver:
                          </p>
                          <div className="flex flex-wrap gap-1">
                            {Object.entries(recommendation.deliverableMatch)
                              .filter(([_, matches]) => matches)
                              .slice(0, 3)
                              .map(([deliverable, _]) => (
                                <Badge
                                  key={deliverable}
                                  variant="outline"
                                  className="text-xs"
                                >
                                  ✓ {deliverable.replace("_", " ")}
                                </Badge>
                              ))}
                          </div>
                        </div>
                      )}

                      {/* Timeline Compatibility */}
                      {recommendation.timelineCompatibility && (
                        <div className="flex items-center gap-1 mb-3">
                          <Clock className="h-3 w-3 text-gray-500" />
                          <span className="text-xs text-gray-600">
                            Timeline: {recommendation.timelineCompatibility}
                          </span>
                        </div>
                      )}

                      {/* Action Button */}
                      <Button
                        size="sm"
                        className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleInfluencerClick(recommendation.id);
                        }}
                      >
                        <MessageCircle className="h-4 w-4 mr-2" />
                        View Profile & Connect
                      </Button>
                    </CardContent>
                  </Card>
                </CarouselItem>
              ))}
            </CarouselContent>
            <CarouselPrevious />
            <CarouselNext />
          </Carousel>
        )}
      </CardContent>
    </Card>
  );
};

export default RecommendedInfluencersV2;
