import { useState, useEffect } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "@/components/ui/carousel";
import { Skeleton } from "@/components/ui/skeleton";
import { campaignService } from "@/services/campaignService";
import userService from "@/services/userService";
import { toast } from "@/hooks/use-toast";
import {
  Users,
  TrendingUp,
  Star,
  Sparkles,
  MessageCircle,
  Shield,
  Target,
  DollarSign,
  AlertTriangle,
  CheckCircle,
  Clock,
} from "lucide-react";
import { useNavigate } from "react-router-dom";

interface AllInfluencersProps {
  campaignId?: string; // Made optional since we might want to show all influencers without campaign context
}

interface Influencer {
  id: string;
  name: string;
  profileImage?: string;
  verificationStatus?: string;
  metrics?: {
    totalFollowers: number;
    averageEngagement: number;
  };
  categories?: string[];
}

const AllInfluencers = ({ campaignId }: AllInfluencersProps) => {
  const [influencers, setInfluencers] = useState<Influencer[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const navigate = useNavigate();

  useEffect(() => {
    loadInfluencers();
  }, []);

  const loadInfluencers = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const response = await userService.getAllInfluencers();
      console.log("response.data", response);
      setInfluencers(response.results || []);
    } catch (error: any) {
      console.error("Failed to load influencers:", error);
      setError("Failed to load influencers");
      toast({
        title: "Error",
        description: "Failed to load influencers.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const formatFollowers = (count: number) => {
    if (count >= 1000000) {
      return `${(count / 1000000).toFixed(1)}M`;
    } else if (count >= 1000) {
      return `${(count / 1000).toFixed(1)}K`;
    }
    return count.toString();
  };

  const getMatchLevelColor = (level?: string) => {
    switch (level) {
      case "excellent":
        return "bg-green-100 text-green-800";
      case "good":
        return "bg-blue-100 text-blue-800";
      case "fair":
        return "bg-yellow-100 text-yellow-800";
      case "poor":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getRiskLevelColor = (level?: string) => {
    switch (level) {
      case "low":
        return "bg-green-100 text-green-800";
      case "medium":
        return "bg-yellow-100 text-yellow-800";
      case "high":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getBudgetFitColor = (fit?: string) => {
    switch (fit) {
      case "within":
        return "bg-green-100 text-green-800";
      case "below":
        return "bg-blue-100 text-blue-800";
      case "above":
        return "bg-orange-100 text-orange-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const handleInfluencerClick = (influencerId: string) => {
    if (campaignId) {
      navigate(`/influencer-profile/${influencerId}?campaignId=${campaignId}`);
    } else {
      navigate(`/influencer-profile/${influencerId}`);
    }
  };

  if (error && !isLoading) {
    return null;
  }

  return (
    <Card className="mt-8">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Users className="h-5 w-5 text-purple-600" />
          All Influencers
        </CardTitle>
        <CardDescription>
          Browse through our network of talented content creators
        </CardDescription>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {[...Array(8)].map((_, index) => (
              <Card key={index}>
                <CardContent className="p-4">
                  <div className="flex items-center space-x-3 mb-3">
                    <Skeleton className="h-12 w-12 rounded-full" />
                    <div>
                      <Skeleton className="h-4 w-24 mb-2" />
                      <Skeleton className="h-3 w-16" />
                    </div>
                  </div>
                  <Skeleton className="h-3 w-full mb-2" />
                  <Skeleton className="h-3 w-3/4 mb-3" />
                </CardContent>
              </Card>
            ))}
          </div>
        ) : influencers.length === 0 ? (
          <div className="text-center py-8 text-gray-500">
            <Users className="h-12 w-12 mx-auto mb-4 opacity-50" />
            <p>No influencers found.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {influencers.map((influencer) => (
              <Card
                key={influencer.id}
                className="cursor-pointer hover:shadow-lg transition-all duration-200 border-2 hover:border-purple-200 hover:scale-[1.02]"
                onClick={() => handleInfluencerClick(influencer.id)}
              >
                <CardContent className="p-4">
                  <div className="flex items-center space-x-3 mb-4">
                    <Avatar className="h-12 w-12">
                      <AvatarImage
                        src={influencer.profileImage}
                        alt={influencer.name}
                      />
                      <AvatarFallback>
                        {influencer.name
                          .split(" ")
                          .map((n) => n[0])
                          .join("")}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <h4 className="font-semibold text-sm truncate">
                        {influencer.name}
                      </h4>
                      {influencer.verificationStatus === "verified" && (
                        <div className="flex items-center gap-1 mt-1">
                          <CheckCircle className="h-3 w-3 text-green-500" />
                          <span className="text-xs text-green-600">
                            Verified
                          </span>
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2 mb-3 text-xs">
                    <div className="flex items-center gap-1">
                      <Users className="h-3 w-3 text-blue-500" />
                      <span className="font-medium">
                        {formatFollowers(
                          influencer.metrics?.totalFollowers || 0
                        )}
                      </span>
                    </div>
                    <div className="flex items-center gap-1">
                      <TrendingUp className="h-3 w-3 text-green-500" />
                      <span className="font-medium">
                        {(influencer.metrics?.averageEngagement || 0).toFixed(
                          1
                        )}
                        %
                      </span>
                    </div>
                  </div>

                  <div className="flex flex-wrap gap-1 mb-3">
                    {(influencer.categories || [])
                      .slice(0, 3)
                      .map((category, idx) => (
                        <Badge key={idx} variant="outline" className="text-xs">
                          {category}
                        </Badge>
                      ))}
                  </div>

                  <Button
                    size="sm"
                    className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleInfluencerClick(influencer.id);
                    }}
                  >
                    <MessageCircle className="h-4 w-4 mr-2" />
                    View Profile
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default AllInfluencers;
