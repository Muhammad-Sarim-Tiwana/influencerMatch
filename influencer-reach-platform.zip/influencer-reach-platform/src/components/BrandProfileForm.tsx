import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuthStore } from "@/store/authStore";
import brandService, { CreateBrandData } from "@/services/brandService";
import { toast } from "@/hooks/use-toast";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Building2, Loader2 } from "lucide-react";

interface BrandProfileFormProps {
  onSuccess?: () => void;
}

const BrandProfileForm = ({ onSuccess }: BrandProfileFormProps) => {
  const { user } = useAuthStore();
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(false);
  const [formData, setFormData] = useState<CreateBrandData>({
    companyName: "",
    industry: "",
    companyType: "startup",
    description: "",
    website: "",
    location: {
      headquarters: {
        country: "",
        city: "",
        address: "",
      },
      targetMarkets: [],
    },
    contact: {
      phone: "",
      email: user?.email || "",
      socialMedia: {
        instagram: "",
        twitter: "",
        linkedin: "",
        facebook: "",
        youtube: "",
      },
    },
    teamSize: "1-10",
    founded: new Date().getFullYear(),
    budget: {
      monthlyInfluencerBudget: "under-1k",
    },
    preferences: {
      preferredInfluencerTypes: [],
      preferredCategories: [],
      targetDemographics: {
        ageGroups: [],
        genders: [],
        locations: [],
      },
    },
  });

  const industries = [
    "fashion",
    "beauty",
    "technology",
    "food-beverage",
    "travel-hospitality",
    "fitness-health",
    "automotive",
    "finance",
    "education",
    "entertainment",
    "gaming",
    "home-garden",
    "pets",
    "sports",
    "nonprofit",
    "b2b-services",
    "ecommerce",
    "media",
    "healthcare",
    "real-estate",
    "other",
  ];

  const companyTypes = [
    { value: "startup", label: "Startup" },
    { value: "small-brand", label: "Small Brand" },
    { value: "medium-brand", label: "Medium Brand" },
    { value: "enterprise", label: "Enterprise" },
    { value: "agency", label: "Agency" },
    { value: "nonprofit", label: "Nonprofit" },
  ];

  const teamSizes = [
    { value: "1-10", label: "1-10 employees" },
    { value: "11-50", label: "11-50 employees" },
    { value: "51-200", label: "51-200 employees" },
    { value: "201-500", label: "201-500 employees" },
    { value: "501-1000", label: "501-1000 employees" },
    { value: "1000+", label: "1000+ employees" },
  ];

  const budgetRanges = [
    { value: "under-1k", label: "Under $1,000" },
    { value: "1k-5k", label: "$1,000 - $5,000" },
    { value: "5k-10k", label: "$5,000 - $10,000" },
    { value: "10k-25k", label: "$10,000 - $25,000" },
    { value: "25k-50k", label: "$25,000 - $50,000" },
    { value: "50k-100k", label: "$50,000 - $100,000" },
    { value: "100k+", label: "$100,000+" },
  ];

  const cleanFormData = (data: CreateBrandData) => {
    const cleaned = { ...data };

    // Clean up social media fields - convert empty strings to undefined
    if (cleaned.contact?.socialMedia) {
      const socialMedia = cleaned.contact.socialMedia;
      Object.keys(socialMedia).forEach((key) => {
        if (socialMedia[key as keyof typeof socialMedia] === "") {
          delete socialMedia[key as keyof typeof socialMedia];
        }
      });
    }

    return cleaned;
  };

  const handleInputChange = (field: string, value: any) => {
    if (field.includes(".")) {
      const keys = field.split(".");
      setFormData((prev) => {
        const newData = { ...prev };
        let current: any = newData;
        for (let i = 0; i < keys.length - 1; i++) {
          if (!current[keys[i]]) current[keys[i]] = {};
          current = current[keys[i]];
        }
        current[keys[keys.length - 1]] = value;
        return newData;
      });
    } else {
      setFormData((prev) => ({
        ...prev,
        [field]: value,
      }));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // Validate required fields
    const errors: string[] = [];

    if (!formData.companyName?.trim()) {
      errors.push("Company name is required");
    }
    if (!formData.industry?.trim()) {
      errors.push("Industry is required");
    }
    if (!formData.description?.trim()) {
      errors.push("Company description is required");
    }

    if (errors.length > 0) {
      toast({
        title: "Missing Information",
        description: errors.join(", "),
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);

    try {
      await brandService.createBrand(cleanFormData(formData));

      toast({
        title: "Profile Submitted!",
        description:
          "Your brand profile has been submitted for review. You'll be notified once it's approved.",
      });

      if (onSuccess) {
        onSuccess();
      } else {
        navigate("/brand/dashboard");
      }
    } catch (error: any) {
      toast({
        title: "Submission Failed",
        description: error.message || "Failed to submit brand profile.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-4xl mx-auto px-4">
        <div className="text-center mb-8">
          <Building2 className="h-12 w-12 text-blue-600 mx-auto mb-4" />
          <h1 className="text-3xl font-bold text-gray-900">
            Create Your Brand Profile
          </h1>
          <p className="text-gray-600 mt-2">
            Tell us about your company to start connecting with influencers
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-8">
          {/* Company Information */}
          <Card>
            <CardHeader>
              <CardTitle>Company Information</CardTitle>
              <CardDescription>
                Basic information about your company
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <Label htmlFor="companyName">
                    Company Name <span className="text-red-500">*</span>
                  </Label>
                  <Input
                    id="companyName"
                    value={formData.companyName}
                    onChange={(e) =>
                      handleInputChange("companyName", e.target.value)
                    }
                    placeholder="Enter your company name"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="industry">
                    Industry <span className="text-red-500">*</span>
                  </Label>
                  <Select
                    value={formData.industry}
                    onValueChange={(value) =>
                      handleInputChange("industry", value)
                    }
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select your industry" />
                    </SelectTrigger>
                    <SelectContent>
                      {industries.map((industry) => (
                        <SelectItem key={industry} value={industry}>
                          {industry.charAt(0).toUpperCase() +
                            industry.slice(1).replace("-", " ")}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <Label htmlFor="companyType">Company Type</Label>
                  <Select
                    value={formData.companyType}
                    onValueChange={(value) =>
                      handleInputChange("companyType", value)
                    }
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {companyTypes.map((type) => (
                        <SelectItem key={type.value} value={type.value}>
                          {type.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="teamSize">Team Size</Label>
                  <Select
                    value={formData.teamSize}
                    onValueChange={(value) =>
                      handleInputChange("teamSize", value)
                    }
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {teamSizes.map((size) => (
                        <SelectItem key={size.value} value={size.value}>
                          {size.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <Label htmlFor="website">Website</Label>
                  <Input
                    id="website"
                    type="url"
                    value={formData.website}
                    onChange={(e) =>
                      handleInputChange("website", e.target.value)
                    }
                    placeholder="https://yourcompany.com"
                  />
                </div>
                <div>
                  <Label htmlFor="founded">Founded Year</Label>
                  <Input
                    id="founded"
                    type="number"
                    value={formData.founded}
                    onChange={(e) =>
                      handleInputChange("founded", parseInt(e.target.value))
                    }
                    min="1800"
                    max={new Date().getFullYear()}
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="description">Company Description</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) =>
                    handleInputChange("description", e.target.value)
                  }
                  placeholder="Tell us about your company, mission, and values..."
                  rows={4}
                />
              </div>
            </CardContent>
          </Card>

          {/* Location Information */}
          <Card>
            <CardHeader>
              <CardTitle>Location & Contact</CardTitle>
              <CardDescription>
                Where is your company based and how can we reach you?
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div>
                  <Label htmlFor="country">Country</Label>
                  <Input
                    id="country"
                    value={formData.location?.headquarters?.country || ""}
                    onChange={(e) =>
                      handleInputChange(
                        "location.headquarters.country",
                        e.target.value
                      )
                    }
                    placeholder="United States"
                  />
                </div>
                <div>
                  <Label htmlFor="city">City</Label>
                  <Input
                    id="city"
                    value={formData.location?.headquarters?.city || ""}
                    onChange={(e) =>
                      handleInputChange(
                        "location.headquarters.city",
                        e.target.value
                      )
                    }
                    placeholder="San Francisco"
                  />
                </div>
                <div>
                  <Label htmlFor="phone">Phone</Label>
                  <Input
                    id="phone"
                    type="tel"
                    value={formData.contact?.phone || ""}
                    onChange={(e) =>
                      handleInputChange("contact.phone", e.target.value)
                    }
                    placeholder="+1 (555) 123-4567"
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="address">Address</Label>
                <Input
                  id="address"
                  value={formData.location?.headquarters?.address || ""}
                  onChange={(e) =>
                    handleInputChange(
                      "location.headquarters.address",
                      e.target.value
                    )
                  }
                  placeholder="123 Business Street, Suite 100"
                />
              </div>
            </CardContent>
          </Card>

          {/* Social Media Information */}
          <Card>
            <CardHeader>
              <CardTitle>Social Media Presence</CardTitle>
              <CardDescription>
                Please provide your brand's social media accounts (optional)
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <Label htmlFor="instagram">Instagram</Label>
                  <Input
                    id="instagram"
                    value={formData.contact?.socialMedia?.instagram || ""}
                    onChange={(e) =>
                      handleInputChange(
                        "contact.socialMedia.instagram",
                        e.target.value
                      )
                    }
                    placeholder="@yourcompany or instagram.com/yourcompany"
                  />
                </div>
                <div>
                  <Label htmlFor="twitter">Twitter/X</Label>
                  <Input
                    id="twitter"
                    value={formData.contact?.socialMedia?.twitter || ""}
                    onChange={(e) =>
                      handleInputChange(
                        "contact.socialMedia.twitter",
                        e.target.value
                      )
                    }
                    placeholder="@yourcompany or x.com/yourcompany"
                  />
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <Label htmlFor="linkedin">LinkedIn</Label>
                  <Input
                    id="linkedin"
                    value={formData.contact?.socialMedia?.linkedin || ""}
                    onChange={(e) =>
                      handleInputChange(
                        "contact.socialMedia.linkedin",
                        e.target.value
                      )
                    }
                    placeholder="linkedin.com/company/yourcompany"
                  />
                </div>
                <div>
                  <Label htmlFor="facebook">Facebook</Label>
                  <Input
                    id="facebook"
                    value={formData.contact?.socialMedia?.facebook || ""}
                    onChange={(e) =>
                      handleInputChange(
                        "contact.socialMedia.facebook",
                        e.target.value
                      )
                    }
                    placeholder="facebook.com/yourcompany"
                  />
                </div>
              </div>
              <div>
                <div>
                  <Label htmlFor="youtube">YouTube</Label>
                  <Input
                    id="youtube"
                    value={formData.contact?.socialMedia?.youtube || ""}
                    onChange={(e) =>
                      handleInputChange(
                        "contact.socialMedia.youtube",
                        e.target.value
                      )
                    }
                    placeholder="youtube.com/@yourcompany or youtube.com/c/yourcompany"
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Budget Information */}
          <Card>
            <CardHeader>
              <CardTitle>Budget & Preferences</CardTitle>
              <CardDescription>
                Help us understand your influencer marketing budget
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <Label htmlFor="monthlyBudget">Monthly Influencer Budget</Label>
                <Select
                  value={formData.budget?.monthlyInfluencerBudget}
                  onValueChange={(value) =>
                    handleInputChange("budget.monthlyInfluencerBudget", value)
                  }
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {budgetRanges.map((range) => (
                      <SelectItem key={range.value} value={range.value}>
                        {range.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          <div className="flex justify-end space-x-4">
            <Button
              type="button"
              variant="outline"
              onClick={() => navigate("/brand/dashboard")}
            >
              Cancel
            </Button>
            <Button type="submit" disabled={isLoading}>
              {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Submit for Review
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default BrandProfileForm;
