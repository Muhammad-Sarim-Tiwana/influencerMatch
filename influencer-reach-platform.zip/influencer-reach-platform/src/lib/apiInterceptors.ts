import { apiClient, handleTokenRefresh } from "@/lib/api";

// Request interceptor to add auth headers
const addAuthHeaders = () => {
  // This is already handled in the apiClient class
  // but this could be extended for additional request modifications
};

// Response interceptor to handle token refresh
const handleAuthErrors = async (error: any) => {
  if (error.code === 401) {
    try {
      // Try to refresh the token
      const refreshSuccess = await handleTokenRefresh();

      if (!refreshSuccess) {
        // Refresh failed, redirect to login
        window.location.href = "/auth";
        return Promise.reject(error);
      }

      // Token refreshed successfully, the user can retry their request
      return Promise.resolve();
    } catch (refreshError) {
      // Refresh failed, redirect to login
      window.location.href = "/auth";
      return Promise.reject(error);
    }
  }

  return Promise.reject(error);
};

// Utility function to setup API interceptors
export const setupApiInterceptors = () => {
  // Add request interceptor
  addAuthHeaders();

  // The response interceptor logic is built into the apiClient
  // This function can be called during app initialization
  console.log("API interceptors configured");
};

// Auto-logout utility
export const autoLogoutOnTokenExpiry = () => {
  // Check token expiry periodically
  setInterval(() => {
    const accessToken = apiClient.getAccessToken();
    const refreshToken = localStorage.getItem("refreshToken");

    if (!accessToken || !refreshToken) {
      // No tokens, already logged out
      return;
    }

    // Check if both tokens are expired
    const accessExpiry = localStorage.getItem("accessTokenExpiry");
    const refreshExpiry = localStorage.getItem("refreshTokenExpiry");

    if (refreshExpiry && new Date() >= new Date(refreshExpiry)) {
      // Refresh token expired, force logout
      window.location.href = "/auth";
    }
  }, 60000); // Check every minute
};

// Export utilities
export { addAuthHeaders, handleAuthErrors };
