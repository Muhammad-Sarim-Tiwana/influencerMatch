import { database } from "@/lib/firebase";
import {
  ref,
  push,
  onValue,
  off,
  query,
  orderByChild,
  set,
  get,
} from "firebase/database";

export interface ChatMessage {
  id: string;
  text: string;
  senderId: string;
  senderName: string;
  senderRole: "influencer" | "brand" | "superadmin";
  timestamp: number;
  attachments?: Array<{
    type: "image" | "document";
    url: string;
    name: string;
  }>;
}

export interface ChatConversation {
  id: string;
  participants: {
    [userId: string]: {
      name: string;
      role: "influencer" | "brand" | "superadmin";
    };
  };
  campaignId?: string;
  campaignTitle?: string;
  lastMessage?: ChatMessage;
  lastMessageTime?: number;
  unreadCount: {
    [userId: string]: number;
  };
  createdAt: number;
  isActive: boolean;
}

class FirebaseChatService {
  private messageListeners: Map<string, Function> = new Map();
  private conversationListeners: Map<string, Function> = new Map();

  // Create or get conversation between two users for a specific campaign
  async createOrGetConversation(
    userId1: string,
    userName1: string,
    userRole1: "influencer" | "brand" | "superadmin",
    userId2: string,
    userName2: string,
    userRole2: "influencer" | "brand" | "superadmin",
    campaignId?: string,
    campaignTitle?: string
  ): Promise<string> {
    try {
      // Validate inputs
      if (!userId1 || !userId2 || !userName1 || !userName2) {
        throw new Error("Missing required user information");
      }

      // Check if Firebase database is available
      if (!database) {
        throw new Error("Firebase database not initialized");
      }

      // Create a deterministic conversation ID based on sorted user IDs and campaign
      const sortedUserIds = [userId1, userId2].sort();
      const conversationId = campaignId
        ? `${sortedUserIds[0]}_${sortedUserIds[1]}_${campaignId}`
        : `${sortedUserIds[0]}_${sortedUserIds[1]}`;

      console.log("🏗️ Creating/getting conversation:", {
        conversationId,
        campaignId,
        campaignTitle,
        participants: [
          { id: userId1, name: userName1, role: userRole1 },
          { id: userId2, name: userName2, role: userRole2 },
        ],
        databaseURL: import.meta.env.VITE_FIREBASE_DATABASE_URL,
      });

      // Check if conversation already exists
      const conversationRef = ref(database, `conversations/${conversationId}`);
      console.log("🔍 Checking if conversation exists...");

      const snapshot = await get(conversationRef);

      if (snapshot.exists()) {
        console.log("✅ Conversation already exists:", snapshot.val());
        return conversationId;
      }

      console.log("📝 Conversation doesn't exist, creating new one...");

      // Create new conversation
      const newConversation: Omit<ChatConversation, "id"> = {
        participants: {
          [userId1]: {
            name: userName1,
            role: userRole1,
          },
          [userId2]: {
            name: userName2,
            role: userRole2,
          },
        },
        ...(campaignId && { campaignId }),
        ...(campaignTitle && { campaignTitle }),
        unreadCount: {
          [userId1]: 0,
          [userId2]: 0,
        },
        createdAt: Date.now(),
        isActive: true,
      };

      console.log("🆕 Creating new conversation:", newConversation);
      await set(conversationRef, newConversation);
      console.log("✅ Conversation created successfully in Firebase");

      return conversationId;
    } catch (error) {
      console.error("❌ Error creating/getting conversation:", error);
      throw error;
    }
  }

  // Send a message in a conversation
  async sendMessage(
    conversationId: string,
    senderId: string,
    senderName: string,
    senderRole: "influencer" | "brand" | "superadmin",
    text: string,
    attachments?: ChatMessage["attachments"]
  ): Promise<void> {
    try {
      // Validate required fields
      if (!conversationId || !senderId || !senderName || !text.trim()) {
        throw new Error("Missing required message fields");
      }

      const message: Omit<ChatMessage, "id"> = {
        text: text.trim(),
        senderId,
        senderName,
        senderRole,
        timestamp: Date.now(),
        ...(attachments && { attachments }),
      };

      const messagesRef = ref(database, `messages/${conversationId}`);
      await push(messagesRef, message);

      // Update conversation's last message and unread counts
      const conversationRef = ref(database, `conversations/${conversationId}`);
      const conversationSnapshot = await get(conversationRef);

      if (conversationSnapshot.exists()) {
        const conversation = conversationSnapshot.val() as ChatConversation;
        const participantIds = Object.keys(conversation.participants);

        // Validate conversation data
        if (participantIds.length !== 2) {
          throw new Error(
            "Invalid conversation data: must have exactly 2 participants"
          );
        }

        const updatedUnreadCount = { ...conversation.unreadCount };

        // Update unread counts for each participant
        participantIds.forEach((participantId) => {
          updatedUnreadCount[participantId] =
            senderId === participantId
              ? 0
              : (conversation.unreadCount[participantId] || 0) + 1;
        });

        const updates = {
          lastMessage: message,
          lastMessageTime: message.timestamp,
          unreadCount: updatedUnreadCount,
        };

        await set(conversationRef, { ...conversation, ...updates });
      }
    } catch (error) {
      console.error("Error sending message:", error);
      throw error;
    }
  }

  // Listen to messages in a conversation
  listenToMessages(
    conversationId: string,
    callback: (messages: ChatMessage[]) => void
  ): () => void {
    const messagesRef = ref(database, `messages/${conversationId}`);
    const messagesQuery = query(messagesRef, orderByChild("timestamp"));

    const unsubscribe = onValue(messagesQuery, (snapshot) => {
      const messages: ChatMessage[] = [];
      if (snapshot.exists()) {
        snapshot.forEach((childSnapshot) => {
          const messageData = childSnapshot.val();
          if (messageData) {
            messages.push({
              id: childSnapshot.key!,
              ...messageData,
            });
          }
        });
      }

      // Sort messages by timestamp to ensure proper order
      messages.sort((a, b) => a.timestamp - b.timestamp);

      callback(messages);
    });

    // Store listener for cleanup
    this.messageListeners.set(conversationId, unsubscribe);

    // Return cleanup function
    return () => {
      off(messagesRef);
      this.messageListeners.delete(conversationId);
    };
  }

  // Listen to messages with notification support
  listenToMessagesWithNotifications(
    conversationId: string,
    currentUserId: string,
    callback: (messages: ChatMessage[], newMessage?: ChatMessage) => void
  ): () => void {
    console.log(
      "Setting up message listener for conversation:",
      conversationId
    );
    console.log("Current user ID:", currentUserId);

    const messagesRef = ref(database, `messages/${conversationId}`);
    const messagesQuery = query(messagesRef, orderByChild("timestamp"));

    let isFirstLoad = true;
    let previousMessages: ChatMessage[] = [];

    const unsubscribe = onValue(
      messagesQuery,
      (snapshot) => {
        console.log("📨 Messages snapshot received:", {
          exists: snapshot.exists(),
          size: snapshot.size,
        });

        const messages: ChatMessage[] = [];
        if (snapshot.exists()) {
          snapshot.forEach((childSnapshot) => {
            const messageData = childSnapshot.val();
            if (messageData) {
              messages.push({
                id: childSnapshot.key!,
                ...messageData,
              });
            }
          });
        }

        // Sort messages by timestamp
        messages.sort((a, b) => a.timestamp - b.timestamp);

        let newMessage: ChatMessage | undefined;

        // Detect new messages for notifications
        if (!isFirstLoad && messages.length > previousMessages.length) {
          const lastMessage = messages[messages.length - 1];

          // Only notify if the new message is from someone else
          if (lastMessage && lastMessage.senderId !== currentUserId) {
            newMessage = lastMessage;
            console.log("🔔 New message detected:", newMessage);
          }
        }

        previousMessages = messages;
        isFirstLoad = false;

        callback(messages, newMessage);
      },
      (error) => {
        console.error("❌ Error listening to messages:", error);
      }
    );

    // Store listener for cleanup
    this.messageListeners.set(conversationId, unsubscribe);

    return () => {
      off(messagesRef);
      this.messageListeners.delete(conversationId);
    };
  }

  // Get user's conversations
  async getUserConversations(userId: string): Promise<ChatConversation[]> {
    try {
      const conversationsRef = ref(database, "conversations");
      const snapshot = await get(conversationsRef);

      const conversations: ChatConversation[] = [];

      if (snapshot.exists()) {
        snapshot.forEach((childSnapshot) => {
          const conv = childSnapshot.val() as ChatConversation;
          // Check if user is a participant in this conversation
          if (conv.participants && conv.participants[userId]) {
            conversations.push({
              id: childSnapshot.key!,
              ...conv,
            });
          }
        });
      }

      // Sort by last message time (most recent first)
      conversations.sort((a, b) => {
        const timeA = a.lastMessageTime || a.createdAt;
        const timeB = b.lastMessageTime || b.createdAt;
        return timeB - timeA;
      });

      return conversations;
    } catch (error) {
      console.error("Error getting user conversations:", error);
      throw error;
    }
  }

  // Listen to user's conversations
  listenToUserConversations(
    userId: string,
    callback: (conversations: ChatConversation[]) => void
  ): () => void {
    const conversationsRef = ref(database, "conversations");

    const unsubscribe = onValue(conversationsRef, (snapshot) => {
      const conversations: ChatConversation[] = [];

      if (snapshot.exists()) {
        snapshot.forEach((childSnapshot) => {
          const conv = childSnapshot.val() as ChatConversation;
          // Check if user is a participant
          if (conv.participants && conv.participants[userId]) {
            conversations.push({
              id: childSnapshot.key!,
              ...conv,
            });
          }
        });
      }

      // Sort by last message time (most recent first)
      conversations.sort((a, b) => {
        const timeA = a.lastMessageTime || a.createdAt;
        const timeB = b.lastMessageTime || b.createdAt;
        return timeB - timeA;
      });

      callback(conversations);
    });

    this.conversationListeners.set(userId, unsubscribe);

    return () => {
      off(conversationsRef);
      this.conversationListeners.delete(userId);
    };
  }

  // Mark messages as read in a conversation
  async markAsRead(conversationId: string, userId: string): Promise<void> {
    try {
      const conversationRef = ref(database, `conversations/${conversationId}`);
      const snapshot = await get(conversationRef);

      if (snapshot.exists()) {
        const conversation = snapshot.val() as ChatConversation;
        const updatedUnreadCount = { ...conversation.unreadCount };
        updatedUnreadCount[userId] = 0;

        await set(conversationRef, {
          ...conversation,
          unreadCount: updatedUnreadCount,
        });
      }
    } catch (error) {
      console.error("Error marking messages as read:", error);
      throw error;
    }
  }

  // Get total unread count for a user
  async getUnreadCount(userId: string): Promise<number> {
    try {
      const conversations = await this.getUserConversations(userId);
      return conversations.reduce((total, conv) => {
        return total + (conv.unreadCount[userId] || 0);
      }, 0);
    } catch (error) {
      console.error("Error getting unread count:", error);
      return 0;
    }
  }

  // Get a specific conversation by ID
  async getConversation(
    conversationId: string
  ): Promise<ChatConversation | null> {
    try {
      if (!database) {
        throw new Error("Firebase database not initialized");
      }

      const conversationRef = ref(database, `conversations/${conversationId}`);
      const snapshot = await get(conversationRef);

      if (snapshot.exists()) {
        const data = snapshot.val();
        return {
          id: conversationId,
          ...data,
        };
      }

      return null;
    } catch (error) {
      console.error("❌ Error getting conversation:", error);
      throw error;
    }
  }

  // Clean up all listeners
  cleanup(): void {
    this.messageListeners.forEach((unsubscribe) => {
      if (typeof unsubscribe === "function") {
        unsubscribe();
      }
    });
    this.messageListeners.clear();

    this.conversationListeners.forEach((unsubscribe) => {
      if (typeof unsubscribe === "function") {
        unsubscribe();
      }
    });
    this.conversationListeners.clear();
  }
}

export const firebaseChatService = new FirebaseChatService();
