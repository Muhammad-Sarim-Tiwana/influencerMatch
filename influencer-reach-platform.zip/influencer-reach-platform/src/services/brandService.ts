import api from "@/lib/api";

export interface BrandProfile {
  id: string;
  user: {
    id: string;
    name: string;
    email: string;
    role: string;
    isEmailVerified: boolean;
  };
  companyName: string;
  industry: string;
  companyType:
    | "startup"
    | "small-brand"
    | "medium-brand"
    | "enterprise"
    | "agency"
    | "nonprofit";
  description?: string;
  website?: string;
  logo?: string;
  location?: {
    headquarters?: {
      country?: string;
      city?: string;
      address?: string;
    };
    targetMarkets?: string[];
  };
  contact?: {
    phone?: string;
    email?: string;
    socialMedia?: {
      instagram?: string;
      twitter?: string;
      linkedin?: string;
      facebook?: string;
      youtube?: string;
    };
  };
  teamSize?: "1-10" | "11-50" | "51-200" | "201-500" | "501-1000" | "1000+";
  founded?: number;
  budget?: {
    monthlyInfluencerBudget?:
      | "under-1k"
      | "1k-5k"
      | "5k-10k"
      | "10k-25k"
      | "25k-50k"
      | "50k-100k"
      | "100k+";
    campaignBudgetRange?: {
      min?: number;
      max?: number;
    };
  };
  preferences?: {
    preferredInfluencerTypes?: ("nano" | "micro" | "macro" | "mega")[];
    preferredCategories?: string[];
    targetDemographics?: {
      ageGroups?: string[];
      genders?: string[];
      locations?: string[];
    };
  };
  metrics?: {
    totalCampaigns: number;
    activeCampaigns: number;
    completedCampaigns: number;
    totalInfluencersWorkedWith: number;
    averageCampaignRating: number;
  };
  verificationStatus: "pending" | "verified" | "rejected";
  subscription?: {
    plan: "basic" | "premium" | "enterprise";
    startDate?: string;
    endDate?: string;
    features?: string[];
  };
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface CreateBrandData {
  companyName: string;
  industry: string;
  companyType:
    | "startup"
    | "small-brand"
    | "medium-brand"
    | "enterprise"
    | "agency"
    | "nonprofit";
  description?: string;
  website?: string;
  logo?: string;
  location?: {
    headquarters?: {
      country?: string;
      city?: string;
      address?: string;
    };
    targetMarkets?: string[];
  };
  contact?: {
    phone?: string;
    email?: string;
    socialMedia?: {
      instagram?: string;
      twitter?: string;
      linkedin?: string;
      facebook?: string;
      youtube?: string;
    };
  };
  teamSize?: "1-10" | "11-50" | "51-200" | "201-500" | "501-1000" | "1000+";
  founded?: number;
  budget?: {
    monthlyInfluencerBudget?:
      | "under-1k"
      | "1k-5k"
      | "5k-10k"
      | "10k-25k"
      | "25k-50k"
      | "50k-100k"
      | "100k+";
    campaignBudgetRange?: {
      min?: number;
      max?: number;
    };
  };
  preferences?: {
    preferredInfluencerTypes?: ("nano" | "micro" | "macro" | "mega")[];
    preferredCategories?: string[];
    targetDemographics?: {
      ageGroups?: string[];
      genders?: string[];
      locations?: string[];
    };
  };
  subscription?: {
    plan?: "basic" | "premium" | "enterprise";
    startDate?: string;
    endDate?: string;
    features?: string[];
  };
}

export interface UpdateBrandData extends Partial<CreateBrandData> {}

export interface BrandsResponse {
  results: BrandProfile[];
  page: number;
  limit: number;
  totalPages: number;
  totalResults: number;
}

export interface BrandFilters {
  industry?: string;
  companyType?:
    | "startup"
    | "small-brand"
    | "medium-brand"
    | "enterprise"
    | "agency"
    | "nonprofit";
  verificationStatus?: "pending" | "verified" | "rejected";
  isActive?: boolean;
  page?: number;
  limit?: number;
  sortBy?: string;
}

const brandService = {
  // Create brand profile
  createBrand: async (data: CreateBrandData): Promise<BrandProfile> => {
    const response = await api.post("/brands", data);
    return response.data;
  },

  // Create brand profile for a specific user (admin only)
  createBrandForUser: async (
    userId: string,
    data: CreateBrandData
  ): Promise<BrandProfile> => {
    const response = await api.post("/brands/admin/create", {
      userId,
      ...data,
    });
    return response.data;
  },

  // Get brands with optional filters
  getBrands: async (filters?: BrandFilters): Promise<BrandsResponse> => {
    const params = new URLSearchParams();

    if (filters?.industry) params.append("industry", filters.industry);
    if (filters?.companyType) params.append("companyType", filters.companyType);
    if (filters?.verificationStatus)
      params.append("verificationStatus", filters.verificationStatus);
    if (filters?.isActive !== undefined)
      params.append("isActive", filters.isActive.toString());
    if (filters?.page) params.append("page", filters.page.toString());
    if (filters?.limit) params.append("limit", filters.limit.toString());
    if (filters?.sortBy) params.append("sortBy", filters.sortBy);

    const response = await api.get(`/brands?${params.toString()}`);
    console.log("brandService response:", response);
    // The API returns data directly, and the response is already typed correctly
    return response as BrandsResponse;
  },

  // Search brands
  searchBrands: async (query: string): Promise<BrandProfile[]> => {
    const response = await api.get(
      `/brands/search?q=${encodeURIComponent(query)}`
    );
    return response.data;
  },

  // Get current user's brand profile
  getMyProfile: async (): Promise<BrandProfile> => {
    const response = await api.get("/brands/me");
    return response.data || response;
  },

  // Update current user's brand profile
  updateMyProfile: async (data: UpdateBrandData): Promise<BrandProfile> => {
    const response = await api.patch("/brands/me", data);
    return response.data;
  },

  // Get brand profile by ID
  getBrand: async (brandId: string): Promise<BrandProfile> => {
    const response = await api.get(`/brands/${brandId}`);
    return response.data;
  },

  // Admin: Get brand profile by ID (same as getBrand, but for clarity)
  getBrandById: async (brandId: string): Promise<BrandProfile> => {
    const response = await api.get(`/brands/${brandId}`);
    return response.data || response;
  },

  // Update brand profile by ID
  updateBrand: async (
    brandId: string,
    data: UpdateBrandData
  ): Promise<BrandProfile> => {
    const response = await api.patch(`/brands/${brandId}`, data);
    return response.data;
  },

  // Delete brand profile
  deleteBrand: async (brandId: string): Promise<void> => {
    await api.delete(`/brands/${brandId}`);
  },

  // Get brand analytics
  getBrandAnalytics: async (): Promise<any> => {
    const response = await api.get("/brands/me/analytics");
    return response.data;
  },

  // Update brand metrics
  updateMetrics: async (metrics: any): Promise<BrandProfile> => {
    const response = await api.patch("/brands/me/metrics", metrics);
    return response.data;
  },

  // Get pending brands for admin review
  getPendingBrands: async (filters?: BrandFilters): Promise<BrandsResponse> => {
    const params = new URLSearchParams();

    if (filters?.page) params.append("page", filters.page.toString());
    if (filters?.limit) params.append("limit", filters.limit.toString());
    if (filters?.sortBy) params.append("sortBy", filters.sortBy);

    const response = await api.get(`/brands/pending?${params.toString()}`);
    return response as BrandsResponse;
  },

  // Approve brand profile (admin only)
  approveBrand: async (brandId: string): Promise<BrandProfile> => {
    const response = await api.patch(`/brands/${brandId}/approve`);
    return response.data;
  },

  // Reject brand profile (admin only)
  rejectBrand: async (brandId: string): Promise<BrandProfile> => {
    const response = await api.patch(`/brands/${brandId}/reject`);
    return response.data;
  },
};

export default brandService;
