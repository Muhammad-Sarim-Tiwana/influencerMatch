import api from "@/lib/api";
import { SocialPlatform } from "./authService";

export interface BackendUser {
  id: string;
  email: string;
  name: string;
  role: "superadmin" | "brand" | "influencer";
  isEmailVerified: boolean;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
  // Influencer-specific fields
  bio?: string;
  profileImage?: string;
  location?: {
    country?: string;
    city?: string;
  };
  socialPlatforms?: Array<{
    platform:
      | "instagram"
      | "tiktok"
      | "youtube"
      | "twitter"
      | "facebook"
      | "linkedin"
      | "twitch"
      | "snapchat";
    username: string;
    followerCount: number;
    engagementRate?: number;
    profileUrl?: string;
  }>;
  tags?: string[];
  categories?: string[];
  demographics?: {
    ageGroup?:
      | "13-17"
      | "18-24"
      | "25-34"
      | "35-44"
      | "45-54"
      | "55-64"
      | "65+";
    gender?: "male" | "female" | "non-binary" | "prefer-not-to-say";
    primaryAudience?: {
      ageGroup?:
        | "13-17"
        | "18-24"
        | "25-34"
        | "35-44"
        | "45-54"
        | "55-64"
        | "65+";
      gender?: "male" | "female" | "mixed" | "other";
      locations?: string[];
      interests?: string[];
      languages?: string[];
    };
  };
  languages?: string[];
  contentTypes?: (
    | "post"
    | "story"
    | "reel"
    | "video"
    | "article"
    | "review"
    | "unboxing"
    | "tutorial"
    | "other"
  )[];
  collaborationTypes?: (
    | "sponsored-post"
    | "product-review"
    | "brand-ambassador"
    | "event-coverage"
    | "giveaway"
    | "takeover"
    | "affiliate"
    | "other"
  )[];
  pastBrands?: Array<{
    name: string;
    category: string;
    collaborationType: string;
    year: number;
  }>;
  excludedBrands?: Array<{
    name: string;
    reason: string;
  }>;
  metrics?: {
    totalFollowers: number;
    averageEngagement: number;
    completedCampaigns: number;
    rating: number;
    responseRate: number;
  };
  pricing?: {
    postPrice?: number;
    storyPrice?: number;
    videoPrice?: number;
    reelPrice?: number;
    packageDeals?: Array<{
      name: string;
      description: string;
      price: number;
      deliverables: string[];
    }>;
    currency?: string;
    negotiable?: boolean;
  };
  portfolio?: Array<{
    title?: string;
    description?: string;
    imageUrl?: string;
    videoUrl?: string;
    platform?: string;
    metrics?: {
      views?: number;
      likes?: number;
      comments?: number;
      shares?: number;
    };
    brandName?: string;
    campaignType?: string;
    date?: string;
  }>;
  availability?: {
    status: "available" | "busy" | "unavailable";
    nextAvailable?: string;
  };
  verificationStatus: "pending" | "verified" | "rejected";
  brandAffinities?: Array<{
    brand: string;
    category: string;
    collaborationType: string;
    score: number;
    date: string;
  }>;
  personalityTraits?: {
    authenticity: number;
    creativity: number;
    professionalism: number;
    reliability: number;
  };
  contentStyle?: {
    visualAesthetic?:
      | "minimalist"
      | "colorful"
      | "dark"
      | "bright"
      | "vintage"
      | "modern"
      | "artistic"
      | "lifestyle";
    toneOfVoice?:
      | "professional"
      | "casual"
      | "humorous"
      | "inspirational"
      | "educational"
      | "friendly"
      | "authoritative";
    contentFrequency?:
      | "daily"
      | "multiple-daily"
      | "weekly"
      | "bi-weekly"
      | "irregular";
  };
  performanceMetrics?: {
    averageViewsPerPost: number;
    averageLikesPerPost: number;
    averageCommentsPerPost: number;
    averageSharesPerPost: number;
    bestPerformingContentType?: string;
    peakEngagementHours?: string[];
  };
  aiSummary?: {
    summary: string;
    tags: string[];
    contentTypes: string[];
    audienceCharacteristics: string[];
    specialties: string[];
    followerCount?: number;
    engagementRate?: number;
    audienceSize?: string;
    lastUpdated: string;
  };
}

export interface UserQueryOptions {
  sortBy?: string;
  limit?: number;
  page?: number;
  role?: string;
}

export interface UserQueryResult {
  results: BackendUser[];
  page: number;
  limit: number;
  totalPages: number;
  totalResults: number;
}

export interface UpdateUserData {
  name?: string;
  email?: string;
  // Influencer-specific fields
  bio?: string;
  profileImage?: string;
  location?: {
    country?: string;
    city?: string;
  };
  socialPlatforms?: SocialPlatform[];
  tags?: string[];
  categories?: string[];
  // New enhanced fields
  languages?: string[];
  contentTypes?: string[];
  collaborationTypes?: string[];
  pastBrands?: string[];
  excludedBrands?: string[];
  portfolio?: Array<{
    type: "image" | "video" | "link";
    url: string;
    title?: string;
    description?: string;
    metrics?: {
      views?: number;
      likes?: number;
      comments?: number;
      shares?: number;
    };
  }>;
  demographics?: {
    ageGroup?: string;
    gender?: string;
    primaryAudience?: {
      ageGroup?: string;
      gender?: string;
      locations?: string[];
    };
  };
  pricing?: {
    postPrice?: number;
    storyPrice?: number;
    videoPrice?: number;
    reelPrice?: number;
    packageDeals?: Array<{
      name: string;
      description: string;
      price: number;
      deliverables: string[];
    }>;
    // Enhanced pricing structure
    byPlatform?: {
      [platform: string]: {
        post?: number;
        story?: number;
        video?: number;
        reel?: number;
      };
    };
    byContentType?: {
      [contentType: string]: number;
    };
    byCollaborationType?: {
      [collaborationType: string]: number;
    };
  };
  availability?: {
    status?: "available" | "busy" | "unavailable";
    nextAvailable?: string;
  };
}

class UserService {
  async getUsers(options: UserQueryOptions = {}): Promise<UserQueryResult> {
    const params = new URLSearchParams();

    if (options.sortBy) params.append("sortBy", options.sortBy);
    if (options.limit) params.append("limit", options.limit.toString());
    if (options.page) params.append("page", options.page.toString());
    if (options.role) params.append("role", options.role);

    const response = await api.get(`/users?${params.toString()}`);
    console.log("userService response:", response);
    // The API returns data directly, not wrapped in response.data
    return response as UserQueryResult;
  }

  async getUserById(userId: string): Promise<BackendUser> {
    const response = await api.get(`/users/${userId}`);
    return response.data || response;
  }

  async getInfluencerById(influencerId: string): Promise<BackendUser> {
    if (!influencerId || influencerId === "undefined") {
      throw new Error(`Invalid influencer ID: "${influencerId}"`);
    }
    const response = await api.get(`/influencers/${influencerId}`);
    return response.data || response;
  }

  async updateUser(
    userId: string,
    userData: UpdateUserData
  ): Promise<BackendUser> {
    const response = await api.patch(`/users/${userId}`, userData);
    return response.data || response;
  }

  async deleteUser(userId: string): Promise<void> {
    await api.delete(`/users/${userId}`);
  }

  // Admin functions for influencer management
  async getPendingInfluencers(options?: {
    page?: number;
    limit?: number;
    sortBy?: string;
  }): Promise<{
    results: BackendUser[];
    page: number;
    limit: number;
    totalPages: number;
    totalResults: number;
  }> {
    const params = new URLSearchParams();
    if (options?.page) params.append("page", options.page.toString());
    if (options?.limit) params.append("limit", options.limit.toString());
    if (options?.sortBy) params.append("sortBy", options.sortBy);

    const response = await api.get(
      `/users/influencers/pending?${params.toString()}`
    );
    return response.data || response;
  }

  async getInfluencerStats(): Promise<{
    total: number;
    active: number;
    pending: number;
    rejected: number;
  }> {
    const response = await api.get("/users/influencers/stats");
    return response.data || response;
  }

  async activateInfluencer(userId: string): Promise<{
    message: string;
    user: BackendUser;
  }> {
    const response = await api.patch(`/users/influencers/${userId}/activate`);
    return response.data || response;
  }

  async deactivateInfluencer(
    userId: string,
    reason?: string
  ): Promise<{
    message: string;
    user: BackendUser;
  }> {
    const response = await api.patch(
      `/users/influencers/${userId}/deactivate`,
      {
        reason,
      }
    );
    return response.data || response;
  }

  async getCurrentUser(): Promise<BackendUser> {
    const response = await api.get("/users/me");
    return response.data || response;
  }

  async toggleUserStatus(userId: string): Promise<{
    message: string;
    user: BackendUser;
  }> {
    const response = await api.patch(`/users/${userId}/toggle-status`);
    return response.data || response;
  }

  async getAllInfluencers(): Promise<UserQueryResult> {
    const params = new URLSearchParams({
      role: "influencer",
      sortBy: "name:asc",
      limit: "999",
    });
    const response = await api.get(`/users?${params.toString()}`);
    return response.data || response;
  }
}

const userService = new UserService();
export default userService;
