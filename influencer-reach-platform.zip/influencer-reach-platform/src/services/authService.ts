import { apiClient, handleTokenRefresh, ApiError } from "@/lib/api";
import { UserRole } from "@/store/authStore";

export interface LoginCredentials {
  email: string;
  password: string;
}

export interface RegisterData {
  name: string;
  email: string;
  password: string;
  role?: UserRole;
  // Brand-specific fields
  company?: string;
  // Influencer-specific fields
  socialPlatforms?: SocialPlatform[];
  bio?: string;
  profileImage?: string;
  location?: {
    country?: string;
    city?: string;
  };
  categories?: string[];
  tags?: string[];
  demographics?: {
    ageGroup?: string;
    gender?: string;
    primaryAudience?: {
      ageGroup?: string;
      gender?: string;
      locations?: string[];
      interests?: string[];
      languages?: string[];
    };
  };
  languages?: string[];
  contentTypes?: string[];
  collaborationTypes?: string[];
  pricing?: {
    postPrice?: number;
    storyPrice?: number;
    videoPrice?: number;
    reelPrice?: number;
    currency?: string;
    negotiable?: boolean;
  };
  availability?: {
    status?: string;
    nextAvailable?: string;
  };
  contentStyle?: {
    visualAesthetic?: string;
    toneOfVoice?: string;
    contentFrequency?: string;
  };
}

export interface ForgotPasswordData {
  email: string;
}

export interface ResetPasswordData {
  password: string;
  token: string;
}

export interface AuthTokens {
  access: {
    token: string;
    expires: string;
  };
  refresh: {
    token: string;
    expires: string;
  };
}

export interface SocialPlatform {
  platform:
    | "instagram"
    | "tiktok"
    | "youtube"
    | "twitter"
    | "facebook"
    | "linkedin"
    | "twitch"
    | "snapchat";
  username: string;
  followerCount?: number;
  engagementRate?: number;
  profileUrl?: string;
}

export interface AuthUser {
  id: string;
  email: string;
  name: string;
  role: UserRole;
  isEmailVerified: boolean;
  createdAt: string;
  updatedAt: string;
  // Influencer-specific fields
  bio?: string;
  profileImage?: string;
  location?: {
    country?: string;
    city?: string;
  };
  socialPlatforms?: SocialPlatform[];
  tags?: string[];
  categories?: string[];
  demographics?: {
    ageGroup?: string;
    gender?: string;
    primaryAudience?: {
      ageGroup?: string;
      gender?: string;
      locations?: string[];
    };
  };
  metrics?: {
    totalFollowers?: number;
    averageEngagement?: number;
    completedCampaigns?: number;
    rating?: number;
    responseRate?: number;
  };
  pricing?: {
    postPrice?: number;
    storyPrice?: number;
    videoPrice?: number;
    packageDeals?: Array<{
      name: string;
      description: string;
      price: number;
      deliverables: string[];
    }>;
  };
  availability?: {
    status?: "available" | "busy" | "unavailable";
    nextAvailable?: string;
  };
  verificationStatus?: "pending" | "verified" | "rejected";
  isActive?: boolean;
}

export interface AuthResponse {
  user: AuthUser;
  tokens: AuthTokens;
  message?: string;
  status?: "active" | "pending_approval" | "deactivated";
}

class AuthService {
  /**
   * Register a new user
   */
  async register(userData: RegisterData): Promise<AuthResponse> {
    try {
      const response = await apiClient.post<AuthResponse>(
        "/auth/register",
        userData
      );

      if (response.tokens) {
        this.storeTokens(response.tokens);
      }

      return {
        user: response.user!,
        tokens: response.tokens!,
      };
    } catch (error) {
      throw this.handleAuthError(error as ApiError);
    }
  }

  /**
   * Login user
   */
  async login(credentials: LoginCredentials): Promise<AuthResponse> {
    try {
      const response = await apiClient.post<AuthResponse>(
        "/auth/login",
        credentials
      );

      console.log("response", response);
      if (response.tokens) {
        this.storeTokens(response.tokens);
      }

      return {
        user: response.user!,
        tokens: response.tokens!,
      };
    } catch (error) {
      throw this.handleAuthError(error as ApiError);
    }
  }

  /**
   * Logout user
   */
  async logout(): Promise<void> {
    try {
      const refreshToken = localStorage.getItem("refreshToken");
      if (refreshToken) {
        await apiClient.post("/auth/logout", { refreshToken });
      }
    } catch (error) {
      // Even if logout fails on backend, we still clear local tokens
      console.warn("Logout request failed:", error);
    } finally {
      this.clearTokens();
    }
  }

  /**
   * Refresh authentication tokens
   */
  async refreshTokens(): Promise<AuthTokens> {
    try {
      const refreshToken = localStorage.getItem("refreshToken");
      if (!refreshToken) {
        throw new Error("No refresh token available");
      }

      const response = await apiClient.post<{ tokens: AuthTokens }>(
        "/auth/refresh-tokens",
        {
          refreshToken,
        }
      );

      if (response.tokens) {
        this.storeTokens(response.tokens);
        return response.tokens;
      }

      throw new Error("No tokens received from refresh");
    } catch (error) {
      this.clearTokens();
      throw this.handleAuthError(error as ApiError);
    }
  }

  /**
   * Send forgot password email
   */
  async forgotPassword(data: ForgotPasswordData): Promise<void> {
    try {
      await apiClient.post("/auth/forgot-password", data);
    } catch (error) {
      throw this.handleAuthError(error as ApiError);
    }
  }

  /**
   * Reset password using token
   */
  async resetPassword(data: ResetPasswordData): Promise<void> {
    try {
      await apiClient.post(`/auth/reset-password?token=${data.token}`, {
        password: data.password,
      });
    } catch (error) {
      throw this.handleAuthError(error as ApiError);
    }
  }

  /**
   * Send email verification
   */
  async sendVerificationEmail(): Promise<void> {
    try {
      await apiClient.post("/auth/send-verification-email");
    } catch (error) {
      throw this.handleAuthError(error as ApiError);
    }
  }

  /**
   * Verify email using token
   */
  async verifyEmail(token: string): Promise<void> {
    try {
      await apiClient.post(`/auth/verify-email?token=${token}`);
    } catch (error) {
      throw this.handleAuthError(error as ApiError);
    }
  }

  /**
   * Get current user profile
   */
  async getCurrentUser(): Promise<AuthUser> {
    try {
      const response = await apiClient.get<any>("/users/me");
      // The backend returns the user directly, not wrapped in an object
      return response as AuthUser;
    } catch (error) {
      throw this.handleAuthError(error as ApiError);
    }
  }

  /**
   * Check if user is authenticated by verifying token
   */
  async checkAuth(): Promise<boolean> {
    try {
      const accessToken = apiClient.getAccessToken();
      if (!accessToken) {
        return false;
      }

      // Try to get current user to verify token is valid
      await this.getCurrentUser();
      return true;
    } catch (error) {
      // If token is invalid, try to refresh
      try {
        await this.refreshTokens();
        return true;
      } catch (refreshError) {
        // Both access and refresh failed
        this.clearTokens();
        return false;
      }
    }
  }

  /**
   * Store authentication tokens
   */
  private storeTokens(tokens: AuthTokens): void {
    apiClient.setAccessToken(tokens.access.token);
    localStorage.setItem("refreshToken", tokens.refresh.token);
    localStorage.setItem("accessTokenExpiry", tokens.access.expires);
    localStorage.setItem("refreshTokenExpiry", tokens.refresh.expires);
  }

  /**
   * Clear authentication tokens
   */
  private clearTokens(): void {
    apiClient.setAccessToken(null);
    localStorage.removeItem("refreshToken");
    localStorage.removeItem("accessTokenExpiry");
    localStorage.removeItem("refreshTokenExpiry");
  }

  /**
   * Handle authentication errors
   */
  private handleAuthError(error: ApiError): Error {
    let message = "An authentication error occurred";

    switch (error.code) {
      case 400:
        message = "Invalid request. Please check your input.";
        break;
      case 401:
        message = "Invalid credentials. Please check your email and password.";
        break;
      case 403:
        message =
          "Access denied. You do not have permission to perform this action.";
        break;
      case 404:
        message = "User not found.";
        break;
      case 409:
        message = "Email already exists. Please use a different email.";
        break;
      case 429:
        message = "Too many requests. Please try again later.";
        break;
      case 500:
        message = "Server error. Please try again later.";
        break;
      default:
        message = error.message || message;
    }

    return new Error(message);
  }

  /**
   * Get stored tokens info
   */
  getTokensInfo(): {
    hasAccessToken: boolean;
    hasRefreshToken: boolean;
    accessTokenExpiry: string | null;
    refreshTokenExpiry: string | null;
  } {
    return {
      hasAccessToken: !!apiClient.getAccessToken(),
      hasRefreshToken: !!localStorage.getItem("refreshToken"),
      accessTokenExpiry: localStorage.getItem("accessTokenExpiry"),
      refreshTokenExpiry: localStorage.getItem("refreshTokenExpiry"),
    };
  }

  /**
   * Check if access token is expired
   */
  isAccessTokenExpired(): boolean {
    const expiry = localStorage.getItem("accessTokenExpiry");
    if (!expiry) return true;

    return new Date() >= new Date(expiry);
  }

  /**
   * Check if refresh token is expired
   */
  isRefreshTokenExpired(): boolean {
    const expiry = localStorage.getItem("refreshTokenExpiry");
    if (!expiry) return true;

    return new Date() >= new Date(expiry);
  }
}

// Create and export singleton instance
export const authService = new AuthService();
export default authService;
