import api from "@/lib/api";

export interface ApplicationResponse {
  questionId: string;
  question: string;
  answer: string | string[] | File;
}

export interface PortfolioItem {
  platform: string;
  postUrl: string;
  description: string;
  metrics?: {
    views: number;
    likes: number;
    comments: number;
    shares: number;
    engagementRate: number;
  };
}

export interface Application {
  id: string;
  campaign: {
    id: string;
    title: string;
    status: string;
  };
  influencer: {
    id: string;
    username: string;
    profilePicture?: string;
  };
  brand: {
    id: string;
    companyName: string;
    logo?: string;
  };
  status: "pending" | "accepted" | "rejected" | "withdrawn";
  proposedBudget?: {
    amount: number;
    currency: string;
    justification?: string;
  };
  responses: ApplicationResponse[];
  portfolio: PortfolioItem[];
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

export interface CreateApplicationData {
  proposedBudget?: {
    amount: number;
    currency: string;
    justification?: string;
  };
  responses?: ApplicationResponse[];
  portfolio?: PortfolioItem[];
  notes?: string;
}

export interface UpdateApplicationData {
  status?: Application["status"];
  proposedBudget?: {
    amount: number;
    currency: string;
    justification?: string;
  };
  responses?: ApplicationResponse[];
  portfolio?: PortfolioItem[];
  notes?: string;
}

export interface ApplicationsResponse {
  results: Application[];
  page: number;
  limit: number;
  totalPages: number;
  totalResults: number;
}

export interface ApplicationFilters {
  status?: string;
  campaign?: string;
  page?: number;
  limit?: number;
  sortBy?: string;
}

const applicationService = {
  // Create an application for a campaign
  createApplication: async (
    campaignId: string,
    data: CreateApplicationData
  ): Promise<Application> => {
    const response = await api.post(
      `/applications/campaigns/${campaignId}`,
      data
    );
    return response.data;
  },

  // Get applications with optional filters
  getApplications: async (
    filters?: ApplicationFilters
  ): Promise<ApplicationsResponse> => {
    const params = new URLSearchParams();

    if (filters?.status) params.append("status", filters.status);
    if (filters?.campaign) params.append("campaign", filters.campaign);
    if (filters?.page) params.append("page", filters.page.toString());
    if (filters?.limit) params.append("limit", filters.limit.toString());
    if (filters?.sortBy) params.append("sortBy", filters.sortBy);

    const response = await api.get(`/applications?${params.toString()}`);
    return response.data;
  },

  // Get user's own applications
  getMyApplications: async (): Promise<Application[]> => {
    const response = await api.get("/applications/my-applications");
    return response.data;
  },

  // Get a specific application by ID
  getApplication: async (applicationId: string): Promise<Application> => {
    const response = await api.get(`/applications/${applicationId}`);
    return response.data;
  },

  // Update an application
  updateApplication: async (
    applicationId: string,
    data: UpdateApplicationData
  ): Promise<Application> => {
    const response = await api.patch(`/applications/${applicationId}`, data);
    return response.data;
  },

  // Update application status (for brands)
  updateApplicationStatus: async (
    applicationId: string,
    status: Application["status"],
    notes?: string
  ): Promise<Application> => {
    const response = await api.patch(`/applications/${applicationId}/status`, {
      status,
      notes,
    });
    return response.data;
  },

  // Get applications for a specific campaign (for brands)
  getCampaignApplications: async (
    campaignId: string
  ): Promise<Application[]> => {
    const response = await api.get(`/applications/campaigns/${campaignId}`);
    return response.data;
  },

  // Withdraw an application (for influencers)
  withdrawApplication: async (applicationId: string): Promise<Application> => {
    return applicationService.updateApplication(applicationId, {
      status: "withdrawn",
    });
  },

  // Accept an application (for brands)
  acceptApplication: async (
    applicationId: string,
    notes?: string
  ): Promise<Application> => {
    return applicationService.updateApplicationStatus(
      applicationId,
      "accepted",
      notes
    );
  },

  // Reject an application (for brands)
  rejectApplication: async (
    applicationId: string,
    notes?: string
  ): Promise<Application> => {
    return applicationService.updateApplicationStatus(
      applicationId,
      "rejected",
      notes
    );
  },
};

export default applicationService;
