import api from "@/lib/api";
import { BackendUser, UpdateUserData } from "./userService";

export interface InfluencerSearchOptions {
  categories?: string[];
  minFollowers?: number;
  maxFollowers?: number;
  platforms?: string[];
  location?: string;
  tags?: string[];
  minEngagement?: number;
  maxEngagement?: number;
  ageGroup?: string;
  gender?: string;
  languages?: string[];
  contentTypes?: string[];
  collaborationTypes?: string[];
  excludeCompetitors?: boolean;
  competitorBrands?: string[];
  audienceAgeGroups?: string[];
  audienceGenders?: string[];
  audienceLocations?: string[];
  verifiedOnly?: boolean;
  availableOnly?: boolean;
}

export interface InfluencerAnalytics {
  totalFollowers: number;
  averageEngagement: number;
  completedCampaigns: number;
  rating: number;
  responseRate: number;
  platformBreakdown: Array<{
    platform: string;
    followers: number;
    engagement: number;
  }>;
  categories: string[];
  verificationStatus: string;
  availabilityStatus: string;
}

class InfluencerService {
  // Get influencers list (now uses user service with role filter)
  async getInfluencers(options: any = {}): Promise<any> {
    const params = new URLSearchParams();

    // Always filter for influencers
    params.append("role", "influencer");

    if (options.categories) params.append("categories", options.categories);
    if (options.verificationStatus)
      params.append("verificationStatus", options.verificationStatus);
    if (options.isActive !== undefined)
      params.append("isActive", options.isActive.toString());
    if (options.sortBy) params.append("sortBy", options.sortBy);
    if (options.limit) params.append("limit", options.limit.toString());
    if (options.page) params.append("page", options.page.toString());

    const response = await api.get(`/users?${params.toString()}`);
    return response.data;
  }

  // Get single influencer (now uses user service)
  async getInfluencer(id: string): Promise<BackendUser> {
    const response = await api.get(`/users/${id}`);
    return response.data;
  }

  // Get my influencer profile
  async getMyProfile(): Promise<BackendUser> {
    const response = await api.get("/influencers/me");
    return response.data;
  }

  // Update influencer profile (now updates user directly)
  async updateProfile(data: UpdateUserData): Promise<BackendUser> {
    const response = await api.patch("/influencers/me", data);
    return response.data;
  }

  // Search influencers
  async searchInfluencers(
    criteria: InfluencerSearchOptions
  ): Promise<BackendUser[]> {
    const params = new URLSearchParams();

    Object.entries(criteria).forEach(([key, value]) => {
      if (value !== undefined && value !== null) {
        if (Array.isArray(value)) {
          value.forEach((v) => params.append(key, v.toString()));
        } else {
          params.append(key, value.toString());
        }
      }
    });

    const response = await api.get(`/influencers/search?${params.toString()}`);
    return response.data;
  }

  // Get influencer analytics
  async getAnalytics(id?: string): Promise<InfluencerAnalytics> {
    const url = id ? `/influencers/${id}/analytics` : "/influencers/analytics";
    const response = await api.get(url);
    return response.data;
  }

  // Get AI analysis
  async getAIAnalysis(id?: string): Promise<any> {
    const url = id
      ? `/influencers/${id}/ai-analysis`
      : "/influencers/ai-analysis";
    const response = await api.get(url);
    return response.data;
  }
}

const influencerService = new InfluencerService();
export default influencerService;
