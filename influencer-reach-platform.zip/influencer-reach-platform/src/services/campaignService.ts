import { apiClient, ApiResponse } from "@/lib/api";

export interface Campaign {
  id: string;
  brand: {
    id: string;
    user: {
      id: string;
      name: string;
      email: string;
    };
    companyName: string;
    industry: string;
    description?: string;
  };
  title: string;
  description: string;
  objectives?: (
    | "brand-awareness"
    | "lead-generation"
    | "sales-conversion"
    | "engagement"
    | "content-creation"
    | "event-promotion"
    | "product-launch"
    | "app-downloads"
    | "website-traffic"
    | "social-media-growth"
  )[];
  category:
    | "fashion"
    | "beauty"
    | "fitness"
    | "food"
    | "travel"
    | "lifestyle"
    | "technology"
    | "gaming"
    | "music"
    | "art"
    | "education"
    | "brand"
    | "health"
    | "parenting"
    | "pets"
    | "sports"
    | "entertainment"
    | "comedy"
    | "diy"
    | "automotive"
    | "home"
    | "finance"
    | "books"
    | "photography"
    | "other";
  productInfo?: {
    name?: string;
    description?: string;
    price?: number;
    urls?: string[];
    images?: string[];
  };
  deliverables?: Array<{
    type:
      | "post"
      | "story"
      | "reel"
      | "video"
      | "article"
      | "review"
      | "unboxing"
      | "tutorial"
      | "other";
    platform:
      | "instagram"
      | "tiktok"
      | "youtube"
      | "twitter"
      | "facebook"
      | "linkedin"
      | "twitch"
      | "snapchat";
    quantity: number;
    specifications?: {
      duration?: number;
      dimensions?: string;
      hashtags?: string[];
      mentions?: string[];
      guidelines?: string;
    };
  }>;
  timeline: {
    applicationDeadline: string;
    campaignStart: string;
    campaignEnd: string;
    contentDeadline?: string;
  };
  budget: {
    type: "fixed" | "negotiable" | "performance";
    amount?: {
      min?: number;
      max?: number;
    };
    currency: string;
    paymentTerms?: string;
  };
  requirements?: {
    influencerTypes?: ("nano" | "micro" | "macro" | "mega")[];
    followerRange?: {
      min?: number;
      max?: number;
    };
    demographics?: {
      ageGroups?: (
        | "13-17"
        | "18-24"
        | "25-34"
        | "35-44"
        | "45-54"
        | "55-64"
        | "65+"
      )[];
      genders?: ("male" | "female" | "mixed" | "other")[];
    };
    platforms?: (
      | "instagram"
      | "tiktok"
      | "youtube"
      | "twitter"
      | "facebook"
      | "linkedin"
      | "twitch"
      | "snapchat"
    )[];
    engagementRate?: {
      min?: number;
      max?: number;
    };
    languages?: string[];
    excludeCompetitors?: boolean;
  };
  status: "draft" | "active" | "paused" | "completed" | "cancelled";
  visibility: "public" | "private" | "invited-only";
  metrics: {
    views: number;
    applications: number;
    accepted: number;
    completed: number;
  };
  tags?: string[];
  attachments?: Array<{
    name: string;
    url: string;
    type: string;
  }>;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface CreateCampaignData {
  title: string;
  description: string;
  objectives?: (
    | "brand-awareness"
    | "lead-generation"
    | "sales-conversion"
    | "engagement"
    | "content-creation"
    | "event-promotion"
    | "product-launch"
    | "app-downloads"
    | "website-traffic"
    | "social-media-growth"
  )[];
  category:
    | "fashion"
    | "beauty"
    | "fitness"
    | "food"
    | "travel"
    | "lifestyle"
    | "technology"
    | "gaming"
    | "music"
    | "art"
    | "education"
    | "brand"
    | "health"
    | "parenting"
    | "pets"
    | "sports"
    | "entertainment"
    | "comedy"
    | "diy"
    | "automotive"
    | "home"
    | "finance"
    | "books"
    | "photography"
    | "other";
  productInfo?: {
    name?: string;
    description?: string;
    price?: number;
    urls?: string[];
    images?: string[];
  };
  deliverables?: Array<{
    type:
      | "post"
      | "story"
      | "reel"
      | "video"
      | "article"
      | "review"
      | "unboxing"
      | "tutorial"
      | "other";
    platform:
      | "instagram"
      | "tiktok"
      | "youtube"
      | "twitter"
      | "facebook"
      | "linkedin"
      | "twitch"
      | "snapchat";
    quantity: number;
    specifications?: {
      duration?: number;
      dimensions?: string;
      hashtags?: string[];
      mentions?: string[];
      guidelines?: string;
    };
  }>;
  timeline: {
    applicationDeadline: string;
    campaignStart: string;
    campaignEnd: string;
    contentDeadline?: string;
  };
  budget?: {
    type?: "fixed" | "negotiable" | "performance";
    amount?: {
      min?: number;
      max?: number;
    };
    currency?: string;
    paymentTerms?: string;
  };
  requirements?: {
    influencerTypes?: ("nano" | "micro" | "macro" | "mega")[];
    followerRange?: {
      min?: number;
      max?: number;
    };
    demographics?: {
      ageGroups?: (
        | "13-17"
        | "18-24"
        | "25-34"
        | "35-44"
        | "45-54"
        | "55-64"
        | "65+"
      )[];
      genders?: ("male" | "female" | "mixed" | "other")[];
    };
    platforms?: (
      | "instagram"
      | "tiktok"
      | "youtube"
      | "twitter"
      | "facebook"
      | "linkedin"
      | "twitch"
      | "snapchat"
    )[];
    engagementRate?: {
      min?: number;
      max?: number;
    };
    languages?: string[];
    excludeCompetitors?: boolean;
  };
  status?: "draft" | "active" | "paused" | "completed" | "cancelled";
  visibility?: "public" | "private" | "invited-only";
  tags?: string[];
  attachments?: Array<{
    name: string;
    url: string;
    type: string;
  }>;
}

export interface CampaignQueryParams {
  category?: string;
  status?: "draft" | "active" | "paused" | "completed" | "cancelled";
  visibility?: "public" | "private" | "invited-only";
  isActive?: boolean;
  sortBy?: string;
  limit?: number;
  page?: number;
}

export interface CampaignSearchParams {
  category?: string;
  minBudget?: number;
  maxBudget?: number;
  platforms?: string;
  influencerTypes?: string;
  location?: string;
  status?: "draft" | "active" | "paused" | "completed" | "cancelled";
  objectives?: string;
  deadlineAfter?: string;
  deadlineBefore?: string;
  keywords?: string;
}

export interface CampaignAnalytics {
  overview: {
    title: string;
    status: string;
    daysRemaining: number;
    budget: any;
  };
  applications: {
    total: number;
    pending: number;
    accepted: number;
    rejected: number;
  };
  influencerInsights: {
    averageFollowers: number;
    topPlatforms: string[];
    averageEngagement: number;
    topCategories: string[];
  };
  engagement: {
    views: number;
    applicationRate: number;
    acceptanceRate: number;
  };
  timeline: {
    phase: string;
    daysUntilDeadline: number;
    daysUntilStart: number;
    daysUntilEnd: number;
    totalDuration: number;
  };
  recommendations: Array<{
    type: string;
    priority: string;
    message: string;
  }>;
}

class CampaignService {
  async createCampaign(
    data: CreateCampaignData
  ): Promise<ApiResponse<Campaign>> {
    const response = await apiClient.post<Campaign>("/campaigns", data);
    return response;
  }

  async getCampaigns(params?: CampaignQueryParams): Promise<
    ApiResponse<{
      results: Campaign[];
      page: number;
      limit: number;
      totalPages: number;
      totalResults: number;
    }>
  > {
    const queryString = params
      ? "?" +
        new URLSearchParams(
          Object.entries(params).reduce((acc, [key, value]) => {
            if (value !== undefined) {
              acc[key] = String(value);
            }
            return acc;
          }, {} as Record<string, string>)
        ).toString()
      : "";

    const response = await apiClient.get<{
      results: Campaign[];
      page: number;
      limit: number;
      totalPages: number;
      totalResults: number;
    }>(`/campaigns${queryString}`);
    return response;
  }

  async getCampaign(id: string): Promise<ApiResponse<Campaign>> {
    const response = await apiClient.get<Campaign>(`/campaigns/${id}`);
    return response;
  }

  async updateCampaign(
    id: string,
    data: Partial<CreateCampaignData>
  ): Promise<ApiResponse<Campaign>> {
    const response = await apiClient.patch<Campaign>(`/campaigns/${id}`, data);
    return response;
  }

  async deleteCampaign(id: string): Promise<void> {
    await apiClient.delete(`/campaigns/${id}`);
  }

  async getMyCampaigns(params?: {
    sortBy?: string;
    limit?: number;
    page?: number;
  }): Promise<
    ApiResponse<{
      results: Campaign[];
      page: number;
      limit: number;
      totalPages: number;
      totalResults: number;
    }>
  > {
    const queryString = params
      ? "?" +
        new URLSearchParams(
          Object.entries(params).reduce((acc, [key, value]) => {
            if (value !== undefined) {
              acc[key] = String(value);
            }
            return acc;
          }, {} as Record<string, string>)
        ).toString()
      : "";

    const response = await apiClient.get<{
      results: Campaign[];
      page: number;
      limit: number;
      totalPages: number;
      totalResults: number;
    }>(`/campaigns/my-campaigns${queryString}`);
    return response;
  }

  async searchCampaigns(
    params: CampaignSearchParams
  ): Promise<ApiResponse<Campaign[]>> {
    const queryString = new URLSearchParams(
      Object.entries(params).reduce((acc, [key, value]) => {
        if (value !== undefined) {
          acc[key] = String(value);
        }
        return acc;
      }, {} as Record<string, string>)
    ).toString();

    const response = await apiClient.get<Campaign[]>(
      `/campaigns/search?${queryString}`
    );
    return response;
  }

  async getCampaignAnalytics(
    id: string
  ): Promise<ApiResponse<CampaignAnalytics>> {
    const response = await apiClient.get<CampaignAnalytics>(
      `/campaigns/${id}/analytics`
    );
    return response;
  }

  async getAIRecommendations(
    id: string
  ): Promise<
    ApiResponse<{ recommendations: any[]; totalInfluencers: number }>
  > {
    const response = await apiClient.get<{
      recommendations: any[];
      totalInfluencers: number;
    }>(`/campaigns/${id}/ai-recommendations`);
    return response;
  }

  async getEnhancedRecommendations(id: string): Promise<
    ApiResponse<{
      recommendations: any[];
      totalInfluencers: number;
      searchCriteria: any;
      campaignInfo: any;
      analytics: {
        averageScore: number;
        topScoreRange: number[];
        matchLevelDistribution: {
          excellent: number;
          good: number;
          fair: number;
          poor: number;
        };
        averageEstimatedROI: number;
      };
    }>
  > {
    const response = await apiClient.get<{
      recommendations: any[];
      totalInfluencers: number;
      searchCriteria: any;
      campaignInfo: any;
      analytics: {
        averageScore: number;
        topScoreRange: number[];
        matchLevelDistribution: {
          excellent: number;
          good: number;
          fair: number;
          poor: number;
        };
        averageEstimatedROI: number;
      };
    }>(`/campaigns/${id}/enhanced-recommendations`);
    return response;
  }

  async getCampaignSummary(id: string): Promise<ApiResponse<any>> {
    const response = await apiClient.get(`/campaigns/${id}/summary`);
    return response;
  }

  async getPublicRecommendations(
    id: string
  ): Promise<
    ApiResponse<{ recommendations: any[]; totalInfluencers: number }>
  > {
    const response = await apiClient.get<{
      recommendations: any[];
      totalInfluencers: number;
    }>(`/campaigns/${id}/recommendations`);
    return response;
  }
}

export const campaignService = new CampaignService();
